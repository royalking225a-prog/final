import { motion } from "framer-motion";
import { UserPlus, Sparkles, Heart, MessageCircle } from "lucide-react";

const STEPS = [
    {
        num: "01",
        icon: UserPlus,
        title: "Create Profile",
        text: "Sign up free, add photos and a 30-second voice intro. Verify your profile for the trusted badge.",
        color: "from-[#FF2A85] to-[#8B5CF6]",
    },
    {
        num: "02",
        icon: Sparkles,
        title: "AI Matches You",
        text: "Our AI analyzes interests, lifestyle, education, religion, and personality to surface your best matches.",
        color: "from-[#8B5CF6] to-[#FF7A00]",
    },
    {
        num: "03",
        icon: Heart,
        title: "Like & Match",
        text: "Swipe through curated profiles. When you both like each other, it's a match — start chatting instantly.",
        color: "from-[#FF7A00] to-[#FF2A85]",
    },
    {
        num: "04",
        icon: MessageCircle,
        title: "Connect Deeply",
        text: "Chat, exchange voice notes, schedule meetups. For Rishta mode, involve family and seek Wali approval.",
        color: "from-[#FF2A85] to-[#8B5CF6]",
    },
];

export default function HowItWorksSection() {
    return (
        <section data-testid="how-it-works" className="relative z-10 px-6 lg:px-8 py-20">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-16">
                    <div className="inline-block text-[10px] uppercase tracking-[0.25em] text-[#FF2A85] font-bold mb-3">How It Works</div>
                    <h2 className="font-['Outfit'] text-4xl lg:text-5xl font-bold mb-4">Find love in <span className="text-neon-gradient">4 simple steps</span></h2>
                    <p className="text-zinc-400 max-w-2xl mx-auto">From signup to soulmate. Our streamlined journey makes finding the right person effortless.</p>
                </div>

                <div className="relative">
                    {/* Connector line - desktop */}
                    <div className="hidden lg:block absolute top-[88px] left-[12%] right-[12%] h-px bg-gradient-to-r from-transparent via-[#FF2A85]/30 to-transparent" />

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-4 relative">
                        {STEPS.map((step, i) => (
                            <motion.div
                                key={step.num}
                                initial={{ opacity: 0, y: 30 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: i * 0.15 }}
                                data-testid={`step-${i}`}
                                className="relative"
                            >
                                <div className="glass rounded-3xl p-6 lg:p-8 h-full hover:-translate-y-2 transition-all duration-300 group relative overflow-hidden">
                                    {/* Step Number */}
                                    <div className="absolute top-4 right-5 font-['Outfit'] text-6xl font-black text-white/[0.04] group-hover:text-white/[0.08] transition-colors">
                                        {step.num}
                                    </div>
                                    {/* Icon */}
                                    <div className="relative">
                                        <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center mb-5 shadow-lg group-hover:scale-110 transition-transform`}>
                                            <step.icon className="w-6 h-6 text-white" />
                                        </div>
                                        <div className={`absolute inset-0 w-14 h-14 rounded-2xl bg-gradient-to-br ${step.color} blur-2xl opacity-40 -z-10`} />
                                    </div>
                                    {/* Content */}
                                    <div className="text-[10px] uppercase tracking-[0.2em] text-[#FF2A85] font-bold mb-2">Step {step.num}</div>
                                    <h3 className="font-['Outfit'] text-xl font-bold mb-2">{step.title}</h3>
                                    <p className="text-sm text-zinc-400 leading-relaxed">{step.text}</p>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
}
