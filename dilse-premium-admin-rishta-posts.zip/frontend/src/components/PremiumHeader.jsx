import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Menu, X, Globe, Heart } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useLang } from "@/context/LanguageContext";
import BrandLogo from "@/components/BrandLogo";

export default function PremiumHeader() {
    const { t, lang, toggleLang } = useLang();
    const [scrolled, setScrolled] = useState(false);
    const [menuOpen, setMenuOpen] = useState(false);

    const NAV_ITEMS = [
        { label: t("nav.home"), to: "/", key: "home" },
        { label: t("nav.discover"), to: "/discover", key: "discover" },
        { label: t("nav.aiMatch"), to: "/ai-match", key: "ai-match" },
        { label: t("nav.rishtaMode"), to: "/rishta-requests", key: "rishta-mode" },
        { label: t("nav.premium"), to: "/premium", key: "premium" },
        { label: t("nav.contact"), to: "#contact", key: "contact" },
    ];

    useEffect(() => {
        const handler = () => setScrolled(window.scrollY > 20);
        window.addEventListener("scroll", handler);
        return () => window.removeEventListener("scroll", handler);
    }, []);

    return (
        <>
            <motion.header
                data-testid="premium-header"
                initial={{ y: -20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5 }}
                className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
                    scrolled
                        ? "py-3 bg-[#09090b]/80 backdrop-blur-2xl border-b border-white/[0.06] shadow-[0_8px_32px_rgba(0,0,0,0.4)]"
                        : "py-5 bg-transparent"
                }`}
            >
                <div className="max-w-7xl mx-auto px-6 lg:px-8 flex items-center justify-between">
                    <Link to="/" data-testid="header-logo" className="group">
                        <BrandLogo size="md" />
                    </Link>

                    <nav className="hidden lg:flex items-center gap-1">
                        {NAV_ITEMS.map((item) => (
                            <NavLink key={item.key} item={item} />
                        ))}
                    </nav>

                    <div className="hidden md:flex items-center gap-2">
                        <button
                            data-testid="header-lang-toggle"
                            onClick={toggleLang}
                            className="flex items-center gap-1.5 px-3 py-2 rounded-full glass hover:bg-white/10 transition-all text-xs font-bold uppercase tracking-wider"
                            aria-label="Toggle language"
                        >
                            <Globe className="w-3.5 h-3.5" />
                            {lang === "en" ? "اردو" : "EN"}
                        </button>
                        <Link
                            to="/login"
                            data-testid="header-login-btn"
                            className="text-sm font-semibold text-zinc-300 hover:text-white px-4 py-2.5 rounded-full transition-colors"
                        >
                            {t("nav.login")}
                        </Link>
                        <Link
                            to="/register"
                            data-testid="header-join-btn"
                            className="relative group inline-flex items-center gap-2 px-5 py-2.5 rounded-full neon-gradient text-white text-sm font-semibold shadow-lg shadow-pink-500/30 hover:shadow-pink-500/50 transition-all"
                        >
                            <span>{t("nav.joinNow")}</span>
                            <Heart className="w-3.5 h-3.5" fill="white" />
                        </Link>
                    </div>

                    <button
                        data-testid="header-mobile-menu-btn"
                        onClick={() => setMenuOpen(!menuOpen)}
                        className="lg:hidden w-10 h-10 rounded-full glass flex items-center justify-center"
                    >
                        {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                    </button>
                </div>
            </motion.header>

            <AnimatePresence>
                {menuOpen && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={() => setMenuOpen(false)}
                        className="lg:hidden fixed inset-0 z-40 bg-black/80 backdrop-blur-md"
                    >
                        <motion.div
                            initial={{ x: "100%" }}
                            animate={{ x: 0 }}
                            exit={{ x: "100%" }}
                            transition={{ type: "spring", damping: 30 }}
                            onClick={(e) => e.stopPropagation()}
                            data-testid="mobile-menu-drawer"
                            className="absolute right-0 top-0 bottom-0 w-80 max-w-[85vw] bg-[#0f0f10] border-l border-white/5 p-6 pt-24 flex flex-col"
                        >
                            <nav className="flex flex-col gap-1">
                                {NAV_ITEMS.map((item) => (
                                    <Link
                                        key={item.key}
                                        to={item.to}
                                        onClick={() => setMenuOpen(false)}
                                        data-testid={`mobile-menu-${item.key}`}
                                        className="px-4 py-3 rounded-2xl text-zinc-300 hover:bg-white/5 hover:text-white transition-all font-medium"
                                    >
                                        {item.label}
                                    </Link>
                                ))}
                                <button
                                    data-testid="mobile-lang-toggle"
                                    onClick={() => { toggleLang(); }}
                                    className="px-4 py-3 rounded-2xl text-zinc-300 hover:bg-white/5 hover:text-white transition-all font-medium flex items-center gap-2"
                                >
                                    <Globe className="w-4 h-4" /> {lang === "en" ? "اردو" : "English"}
                                </button>
                            </nav>
                            <div className="mt-auto space-y-3">
                                <Link
                                    to="/login"
                                    onClick={() => setMenuOpen(false)}
                                    data-testid="mobile-menu-login"
                                    className="block btn-ghost w-full text-center text-sm"
                                >
                                    {t("nav.login")}
                                </Link>
                                <Link
                                    to="/register"
                                    onClick={() => setMenuOpen(false)}
                                    data-testid="mobile-menu-join"
                                    className="block btn-primary w-full text-center text-sm"
                                >
                                    {t("nav.joinNow")}
                                </Link>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
}

function NavLink({ item }) {
    return (
        <Link
            to={item.to}
            data-testid={`header-nav-${item.key}`}
            className="relative px-4 py-2 text-sm font-medium text-zinc-400 hover:text-white transition-colors group"
        >
            <span>{item.label}</span>
            <span className="absolute left-1/2 -translate-x-1/2 bottom-1 w-0 h-0.5 neon-gradient rounded-full group-hover:w-6 transition-all duration-300" />
        </Link>
    );
}
