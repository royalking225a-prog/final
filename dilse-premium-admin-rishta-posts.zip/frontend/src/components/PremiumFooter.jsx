import { useState } from "react";
import { Link } from "react-router-dom";
import { Heart, Mail, Send, Twitter, Instagram, Facebook, Youtube, Shield, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import BrandLogo from "@/components/BrandLogo";

const LINKS = {
    Product: [
        { label: "Dating Mode", to: "/register" },
        { label: "Rishta Mode", to: "/register" },
        { label: "AI Matchmaker", to: "/register" },
        { label: "Voice Intros", to: "/register" },
        { label: "Premium", to: "/premium" },
    ],
    Company: [
        { label: "About Us", to: "#" },
        { label: "Success Stories", to: "#" },
        { label: "Careers", to: "#" },
        { label: "Press", to: "#" },
        { label: "Contact", to: "#contact" },
    ],
    Support: [
        { label: "Help Center", to: "#" },
        { label: "Safety Tips", to: "#" },
        { label: "Community", to: "#" },
        { label: "Block & Report", to: "#" },
    ],
    Legal: [
        { label: "Privacy Policy", to: "#" },
        { label: "Terms of Service", to: "#" },
        { label: "Cookie Policy", to: "#" },
        { label: "Safety", to: "#" },
    ],
};

const SOCIAL = [
    { icon: Twitter, label: "Twitter", href: "#" },
    { icon: Instagram, label: "Instagram", href: "#" },
    { icon: Facebook, label: "Facebook", href: "#" },
    { icon: Youtube, label: "Youtube", href: "#" },
];

export default function PremiumFooter() {
    const [email, setEmail] = useState("");
    const [subscribing, setSubscribing] = useState(false);

    const handleSubscribe = (e) => {
        e.preventDefault();
        if (!email) return;
        setSubscribing(true);
        // For MVP — just visual confirmation
        setTimeout(() => {
            toast.success("Subscribed! Welcome to DilSe newsletter.");
            setEmail("");
            setSubscribing(false);
        }, 600);
    };

    return (
        <footer id="contact" data-testid="premium-footer" className="relative z-10 mt-20">
            {/* Top fade line */}
            <div className="h-px bg-gradient-to-r from-transparent via-[#FF2A85]/30 to-transparent" />

            <div className="relative">
                {/* Background glow */}
                <div className="absolute inset-0 -z-10 pointer-events-none">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-[#FF2A85]/10 blur-[150px] rounded-full" />
                </div>

                {/* Newsletter Section */}
                <div className="max-w-7xl mx-auto px-6 lg:px-8 pt-16 pb-12">
                    <div className="glass-strong rounded-[2rem] p-8 lg:p-12 grid lg:grid-cols-5 gap-8 items-center">
                        <div className="lg:col-span-3">
                            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass-pink mb-3">
                                <Mail className="w-3 h-3 text-[#FF2A85]" />
                                <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#FF2A85]">Newsletter</span>
                            </div>
                            <h3 className="font-['Outfit'] text-2xl lg:text-3xl font-bold mb-2">
                                Stay updated with <span className="text-neon-gradient">love stories</span>
                            </h3>
                            <p className="text-sm text-zinc-400 max-w-md">
                                Get monthly dating tips, success stories, and exclusive premium offers delivered to your inbox.
                            </p>
                        </div>
                        <form onSubmit={handleSubscribe} className="lg:col-span-2 flex items-center gap-2">
                            <div className="relative flex-1">
                                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                                <input
                                    data-testid="newsletter-email"
                                    type="email"
                                    required
                                    placeholder="you@email.com"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    className="input-dark pl-11"
                                />
                            </div>
                            <button
                                data-testid="newsletter-subscribe"
                                type="submit"
                                disabled={subscribing}
                                className="btn-primary px-5 py-3 inline-flex items-center gap-1.5 disabled:opacity-50"
                                aria-label="Subscribe"
                            >
                                <Send className="w-4 h-4" />
                            </button>
                        </form>
                    </div>
                </div>

                {/* Main Footer Grid */}
                <div className="max-w-7xl mx-auto px-6 lg:px-8 pb-10">
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
                        {/* Brand */}
                        <div className="col-span-2 lg:col-span-2">
                            <Link to="/" data-testid="footer-logo" className="inline-block mb-4">
                                <BrandLogo size="md" />
                            </Link>
                            <p className="text-sm text-zinc-400 leading-relaxed mb-5 max-w-sm">
                                The premium Rishta + Dating experience designed for modern South Asian singles. AI-powered, verified, and built with love.
                            </p>
                            <div className="flex items-center gap-2">
                                {SOCIAL.map((s) => (
                                    <a
                                        key={s.label}
                                        href={s.href}
                                        data-testid={`footer-social-${s.label.toLowerCase()}`}
                                        aria-label={s.label}
                                        className="w-9 h-9 rounded-full glass flex items-center justify-center text-zinc-400 hover:text-white hover:bg-[#FF2A85]/20 hover:border-[#FF2A85]/40 hover:scale-110 transition-all"
                                    >
                                        <s.icon className="w-4 h-4" />
                                    </a>
                                ))}
                            </div>
                            <div className="mt-5 inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass">
                                <Shield className="w-3 h-3 text-emerald-400" />
                                <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-emerald-400">SSL Secured</span>
                            </div>
                        </div>

                        {/* Link Columns */}
                        {Object.entries(LINKS).map(([title, items]) => (
                            <div key={title}>
                                <div className="text-[10px] uppercase tracking-[0.25em] font-bold text-zinc-500 mb-4">{title}</div>
                                <ul className="space-y-2.5">
                                    {items.map((l) => (
                                        <li key={l.label}>
                                            <Link
                                                to={l.to}
                                                data-testid={`footer-link-${l.label.toLowerCase().replace(/\s/g, "-")}`}
                                                className="text-sm text-zinc-400 hover:text-[#FF2A85] transition-colors inline-flex items-center gap-1.5 group"
                                            >
                                                {l.label}
                                                <ChevronRight className="w-3 h-3 opacity-0 -ml-1 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                                            </Link>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Bottom Bar */}
                <div className="border-t border-white/5">
                    <div className="max-w-7xl mx-auto px-6 lg:px-8 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
                        <div className="text-xs text-zinc-500 text-center md:text-left">
                            © 2026 <span className="text-white font-semibold">DilSe</span>. Made with <Heart className="w-3 h-3 inline text-[#FF2A85]" fill="#FF2A85" /> for love. All rights reserved.
                        </div>
                        <div className="flex items-center gap-5 text-xs text-zinc-500">
                            <Link to="#" className="hover:text-white transition-colors">Privacy</Link>
                            <Link to="#" className="hover:text-white transition-colors">Terms</Link>
                            <Link to="#" className="hover:text-white transition-colors">Cookies</Link>
                            <Link to="#" className="hover:text-white transition-colors">Sitemap</Link>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    );
}
