import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Check, X, Crown, Sparkles } from "lucide-react";

const FEATURES = [
    { label: "Daily likes", free: "20 / day", premium: "Unlimited" },
    { label: "See who liked you", free: false, premium: true },
    { label: "Advanced filters", free: false, premium: true },
    { label: "AI Matchmaker insights", free: "Basic", premium: "Advanced" },
    { label: "Voice intro upload", free: true, premium: true },
    { label: "Private photo gallery", free: false, premium: true },
    { label: "Profile boost (weekly)", free: false, premium: true },
    { label: "Invisible browsing", free: false, premium: true },
    { label: "Verified badge eligibility", free: true, premium: true },
    { label: "Priority customer support", free: false, premium: true },
];

function Cell({ value }) {
    if (value === true) return <Check className="w-5 h-5 text-emerald-400 mx-auto" />;
    if (value === false) return <X className="w-5 h-5 text-zinc-700 mx-auto" />;
    return <span className="text-sm text-zinc-300 font-semibold">{value}</span>;
}

export default function PricingTableSection() {
    return (
        <section data-testid="pricing-section" className="relative z-10 px-6 lg:px-8 py-20">
            <div className="max-w-5xl mx-auto">
                <div className="text-center mb-12">
                    <div className="inline-block text-[10px] uppercase tracking-[0.25em] text-[#FF2A85] font-bold mb-3">Pricing</div>
                    <h2 className="font-['Outfit'] text-4xl lg:text-5xl font-bold mb-4">Choose your <span className="text-neon-gradient">love journey</span></h2>
                    <p className="text-zinc-400 max-w-2xl mx-auto">Start free, upgrade when you're ready. Cancel anytime.</p>
                </div>

                {/* Mobile-friendly cards layout */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    {/* Free Plan */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        data-testid="plan-free"
                        className="glass rounded-3xl p-8 relative"
                    >
                        <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-bold mb-2">Free Forever</div>
                        <div className="font-['Outfit'] text-2xl font-bold mb-1">Starter</div>
                        <div className="flex items-baseline gap-1 mb-6">
                            <span className="text-5xl font-bold">$0</span>
                            <span className="text-zinc-500 text-sm">/month</span>
                        </div>
                        <Link to="/register" data-testid="pricing-free-cta" className="block text-center btn-ghost w-full text-sm mb-6">Get Started Free</Link>
                        <div className="text-xs text-zinc-500 leading-relaxed">Perfect for browsing, with 20 daily likes and basic AI insights.</div>
                    </motion.div>

                    {/* Premium Plan */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.1 }}
                        data-testid="plan-premium"
                        className="glass-pink rounded-3xl p-8 relative shadow-xl shadow-pink-500/20"
                    >
                        <div className="absolute -top-3 right-6 px-3 py-1 rounded-full neon-gradient text-[10px] font-bold uppercase tracking-[0.15em]">
                            Best Value
                        </div>
                        <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.2em] text-[#FF2A85] font-bold mb-2">
                            <Crown className="w-3 h-3" /> Premium
                        </div>
                        <div className="font-['Outfit'] text-2xl font-bold mb-1">Quarterly</div>
                        <div className="flex items-baseline gap-1 mb-1">
                            <span className="text-5xl font-bold">$8.33</span>
                            <span className="text-zinc-500 text-sm">/month</span>
                        </div>
                        <div className="text-[11px] text-zinc-500 mb-6">$24.99 billed every 3 months</div>
                        <Link to="/premium" data-testid="pricing-premium-cta" className="block text-center btn-primary w-full text-sm mb-6">Go Premium</Link>
                        <div className="text-xs text-zinc-400 leading-relaxed">Unlock everything: unlimited likes, see who liked you, advanced filters, boost, and more.</div>
                    </motion.div>
                </div>

                {/* Comparison Table */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.2 }}
                    className="glass-strong rounded-3xl overflow-hidden"
                >
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="border-b border-white/5 bg-white/[0.02]">
                                <tr>
                                    <th className="text-left p-5 text-[10px] uppercase tracking-[0.2em] font-bold text-zinc-500">Feature</th>
                                    <th className="p-5 text-[10px] uppercase tracking-[0.2em] font-bold text-zinc-500 text-center w-32">Free</th>
                                    <th className="p-5 text-center w-32">
                                        <div className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.2em] font-bold text-[#FF2A85]">
                                            <Crown className="w-3 h-3" /> Premium
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                {FEATURES.map((f, i) => (
                                    <tr key={f.label} className="border-b border-white/[0.04] last:border-0 hover:bg-white/[0.02]">
                                        <td className="p-4 text-sm text-zinc-200">{f.label}</td>
                                        <td className="p-4 text-center">
                                            <Cell value={f.free} />
                                        </td>
                                        <td className="p-4 text-center bg-[#FF2A85]/[0.03]">
                                            <Cell value={f.premium} />
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </motion.div>

                <div className="text-center mt-8 text-xs text-zinc-500 flex items-center justify-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-[#FF2A85]" />
                    All plans include verified profile system & SSL-encrypted privacy.
                </div>
            </div>
        </section>
    );
}
