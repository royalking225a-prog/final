// REPLACE the entire file: frontend/src/components/HeroSlider.jsx
// - Loads slides from /api/hero/slides (managed in Admin panel)
// - Falls back to the original hardcoded slides if API returns none
// - Desktop: text left / image right.  Mobile: text first, image below.
// - Lazy-loaded, decoded async images + preload of next slide.

import { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, ChevronLeft, ChevronRight, Star } from "lucide-react";
import api, { fileUrl } from "@/lib/api";

const FALLBACK_SLIDES = [
    {
        id: "fallback-1",
        badge: "AI Compatibility 96%",
        heading: "Find your soulmate with AI",
        description:
            "Premium rishta & dating built for South Asia. Verified profiles, voice intros, and Wali-approved matching.",
        cta_label: "Get Started Free",
        cta_url: "/register",
        image_url:
            "https://images.unsplash.com/photo-1761125135357-99cbe52a6271?w=1200&q=80",
    },
];

function resolveImg(slide) {
    if (!slide) return "";
    if (slide.image_url?.startsWith("/api/")) return fileUrl(slide.image_path) || slide.image_url;
    return slide.image_url || "";
}

export default function HeroSlider() {
    const [slides, setSlides] = useState(FALLBACK_SLIDES);
    const [index, setIndex] = useState(0);
    const [paused, setPaused] = useState(false);

    useEffect(() => {
        let cancelled = false;
        api.get("/hero/slides")
            .then(({ data }) => {
                if (cancelled) return;
                if (Array.isArray(data?.slides) && data.slides.length) setSlides(data.slides);
            })
            .catch(() => {/* keep fallback */});
        return () => { cancelled = true; };
    }, []);

    useEffect(() => {
        if (paused || slides.length < 2) return;
        const id = setInterval(() => setIndex((i) => (i + 1) % slides.length), 6000);
        return () => clearInterval(id);
    }, [paused, slides.length]);

    // Preload next image to avoid flicker
    useEffect(() => {
        const next = slides[(index + 1) % slides.length];
        const url = resolveImg(next);
        if (url) { const img = new Image(); img.src = url; }
    }, [index, slides]);

    const slide = slides[index] || FALLBACK_SLIDES[0];
    const imgUrl = useMemo(() => resolveImg(slide), [slide]);

    const goNext = () => setIndex((i) => (i + 1) % slides.length);
    const goPrev = () => setIndex((i) => (i - 1 + slides.length) % slides.length);

    return (
        <section
            data-testid="hero-slider"
            className="relative w-full overflow-hidden pt-24 lg:pt-32 pb-16 lg:pb-20"
            onMouseEnter={() => setPaused(true)}
            onMouseLeave={() => setPaused(false)}
        >
            <div className="absolute inset-0 -z-10 pointer-events-none">
                <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-[#FF2A85]/15 rounded-full blur-[120px]" />
                <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-[#8B5CF6]/15 rounded-full blur-[120px]" />
            </div>

            <div className="max-w-7xl mx-auto px-5 lg:px-8 grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
                {/* LEFT: text (always first in DOM → mobile stacks text on top) */}
                <div className="relative order-1">
                    <AnimatePresence mode="wait">
                        <motion.div
                            key={`text-${slide.id}`}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -20 }}
                            transition={{ duration: 0.5 }}
                        >
                            {slide.badge ? (
                                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-pink mb-6">
                                    <Sparkles className="w-3.5 h-3.5 text-[#FF2A85]" />
                                    <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#FF2A85]">
                                        {slide.badge}
                                    </span>
                                </div>
                            ) : null}

                            <h1 className="font-['Outfit'] text-4xl sm:text-5xl lg:text-7xl font-bold tracking-tight leading-[1.05] mb-5">
                                {slide.heading}
                            </h1>

                            {slide.description ? (
                                <p className="text-base lg:text-lg text-zinc-400 mb-7 max-w-xl leading-relaxed">
                                    {slide.description}
                                </p>
                            ) : null}

                            {slide.cta_label ? (
                                <div className="flex flex-wrap items-center gap-4 mb-6">
                                    <Link
                                        to={slide.cta_url || "/register"}
                                        data-testid={`slider-cta-${index}`}
                                        className="btn-primary inline-flex items-center gap-2"
                                    >
                                        {slide.cta_label}
                                        <ChevronRight className="w-4 h-4" />
                                    </Link>
                                    <Link to="/login" className="btn-ghost text-sm">
                                        I already have an account
                                    </Link>
                                </div>
                            ) : null}

                            <div className="flex items-center gap-2 text-amber-400">
                                {[...Array(5)].map((_, i) => (
                                    <Star key={i} className="w-3.5 h-3.5" fill="currentColor" />
                                ))}
                                <span className="text-[11px] text-zinc-500 ml-2">
                                    Trusted by 50,000+ singles
                                </span>
                            </div>
                        </motion.div>
                    </AnimatePresence>
                </div>

                {/* RIGHT: image (order-2 on desktop, comes after text on mobile) */}
                <div className="relative order-2">
                    <AnimatePresence mode="wait">
                        <motion.div
                            key={`img-${slide.id}`}
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            transition={{ duration: 0.6 }}
                            className="glass-strong rounded-[2rem] p-2 shadow-2xl shadow-pink-500/20"
                        >
                            <div className="aspect-[4/5] rounded-[1.75rem] overflow-hidden relative bg-zinc-900">
                                {imgUrl ? (
                                    <img
                                        src={imgUrl}
                                        alt={slide.heading}
                                        loading="lazy"
                                        decoding="async"
                                        className="absolute inset-0 w-full h-full object-cover"
                                    />
                                ) : null}
                                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                            </div>
                        </motion.div>
                    </AnimatePresence>
                </div>
            </div>

            {slides.length > 1 && (
                <>
                    <button
                        onClick={goPrev}
                        aria-label="Previous slide"
                        className="hidden lg:flex absolute left-6 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full glass items-center justify-center hover:bg-white/10"
                    >
                        <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                        onClick={goNext}
                        aria-label="Next slide"
                        className="hidden lg:flex absolute right-6 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full glass items-center justify-center hover:bg-white/10"
                    >
                        <ChevronRight className="w-5 h-5" />
                    </button>

                    <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex items-center gap-3">
                        {slides.map((_, i) => (
                            <button
                                key={i}
                                onClick={() => setIndex(i)}
                                aria-label={`Go to slide ${i + 1}`}
                                className={`h-1.5 rounded-full transition-all duration-500 ${
                                    i === index ? "w-10 neon-gradient" : "w-1.5 bg-white/20"
                                }`}
                            />
                        ))}
                    </div>
                </>
            )}
        </section>
    );
}
