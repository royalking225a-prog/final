import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Users, Heart, Globe, Sparkles } from "lucide-react";

const STATS = [
    { value: 12000, suffix: "+", label: "Happy Matches", icon: Heart, color: "from-[#FF2A85] to-[#8B5CF6]" },
    { value: 50000, suffix: "+", label: "Active Members", icon: Users, color: "from-[#8B5CF6] to-[#FF7A00]" },
    { value: 35, suffix: "+", label: "Cities Worldwide", icon: Globe, color: "from-[#FF7A00] to-[#FF2A85]" },
    { value: 96, suffix: "%", label: "Match Accuracy", icon: Sparkles, color: "from-emerald-400 to-cyan-500" },
];

function Counter({ end, suffix, duration = 2 }) {
    const [count, setCount] = useState(0);
    const ref = useRef(null);
    const inView = useInView(ref, { once: true, margin: "-50px" });

    useEffect(() => {
        if (!inView) return;
        const start = performance.now();
        let raf;
        const tick = (now) => {
            const progress = Math.min((now - start) / (duration * 1000), 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setCount(Math.floor(end * eased));
            if (progress < 1) raf = requestAnimationFrame(tick);
            else setCount(end);
        };
        raf = requestAnimationFrame(tick);
        return () => cancelAnimationFrame(raf);
    }, [inView, end, duration]);

    return (
        <span ref={ref}>{count.toLocaleString()}{suffix}</span>
    );
}

export default function StatsSection() {
    return (
        <section data-testid="stats-section" className="relative z-10 px-6 lg:px-8 py-20">
            <div className="absolute inset-0 -z-10 pointer-events-none">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[300px] bg-[#FF2A85]/10 blur-[120px] rounded-full" />
            </div>
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-12">
                    <div className="inline-block text-[10px] uppercase tracking-[0.25em] text-[#FF2A85] font-bold mb-3">By The Numbers</div>
                    <h2 className="font-['Outfit'] text-4xl lg:text-5xl font-bold">Trusted by <span className="text-neon-gradient">thousands</span> worldwide</h2>
                </div>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
                    {STATS.map((s, i) => (
                        <motion.div
                            key={s.label}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: i * 0.1 }}
                            data-testid={`stat-${i}`}
                            className="glass rounded-3xl p-6 lg:p-8 text-center relative overflow-hidden group hover:-translate-y-1 transition-transform duration-300"
                        >
                            <div className={`w-12 h-12 mx-auto rounded-2xl bg-gradient-to-br ${s.color} flex items-center justify-center mb-4 shadow-lg`}>
                                <s.icon className="w-6 h-6 text-white" />
                            </div>
                            <div className="font-['Outfit'] text-4xl lg:text-5xl font-bold mb-1 text-neon-gradient">
                                <Counter end={s.value} suffix={s.suffix} />
                            </div>
                            <div className="text-xs uppercase tracking-[0.15em] text-zinc-500 font-bold">{s.label}</div>
                            <div className={`absolute -inset-px rounded-3xl bg-gradient-to-br ${s.color} opacity-0 group-hover:opacity-10 transition-opacity -z-10`} />
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}
