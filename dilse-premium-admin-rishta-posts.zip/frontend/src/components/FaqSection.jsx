import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, HelpCircle } from "lucide-react";

const FAQS = [
    {
        q: "Is DilSe free to use?",
        a: "Yes! DilSe is free to sign up and use core features including 20 daily likes, basic AI matchmaking, voice intros, and chat with your matches. Premium ($8.33/mo on quarterly) unlocks unlimited likes, see who liked you, advanced filters, profile boost, and more.",
    },
    {
        q: "What's the difference between Dating Mode and Rishta Mode?",
        a: "Dating Mode is casual swipe-style: full-screen photos, quick stats, instant matches. Rishta Mode is family-involved with Wali approval, formal rishta request flow, family details visibility, and private photo handling — designed for marriage-minded users following traditional values.",
    },
    {
        q: "How does AI Matchmaking work?",
        a: "Our AI (powered by GPT-5) analyzes 5 dimensions: shared interests, education level, religious values, lifestyle/location, and personality (via bio + age compatibility). Each match gets an overall percentage and a written insight explaining strengths and shared values.",
    },
    {
        q: "Is my data and privacy protected?",
        a: "Absolutely. We use bcrypt-encrypted passwords, JWT auth tokens, SSL-only communication, and Emergent's secure object storage for photos/voice notes. You can enable Invisible Browsing (Premium) to view profiles without appearing in visitor lists, and block/report users anytime.",
    },
    {
        q: "Are the profiles verified?",
        a: "Every profile is manually reviewed by our team. Verified members receive a blue badge. We also support Wali approval badges for Rishta-mode users. Banned users are permanently removed and cannot rejoin with the same email.",
    },
    {
        q: "How do voice intros work?",
        a: "Record a 30-second voice intro from your profile page. Other users see a waveform on your card and can play it before deciding to like you. Voice intros increase match rates by 4x — they let your personality shine through before any photos.",
    },
    {
        q: "Can I cancel my Premium subscription anytime?",
        a: "Yes, cancel anytime from your profile settings. Your Premium benefits remain active until the end of your billing period. No hidden fees, no auto-renewal traps. Payments are securely processed by Stripe.",
    },
    {
        q: "Do you support international users?",
        a: "Yes, DilSe is available worldwide. We have active communities in 35+ cities across Pakistan, India, UK, USA, Canada, Australia, UAE, and Saudi Arabia — with the platform optimized for South Asian rishta and dating culture.",
    },
];

export default function FaqSection() {
    const [open, setOpen] = useState(0);

    return (
        <section data-testid="faq-section" className="relative z-10 px-6 lg:px-8 py-20">
            <div className="max-w-4xl mx-auto">
                <div className="text-center mb-12">
                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass-pink mb-3">
                        <HelpCircle className="w-3 h-3 text-[#FF2A85]" />
                        <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#FF2A85]">FAQ</span>
                    </div>
                    <h2 className="font-['Outfit'] text-4xl lg:text-5xl font-bold mb-4">Frequently asked <span className="text-neon-gradient">questions</span></h2>
                    <p className="text-zinc-400 max-w-2xl mx-auto">Everything you need to know about DilSe. Still have questions? Reach out to our support team.</p>
                </div>

                <div className="space-y-3">
                    {FAQS.map((faq, i) => {
                        const isOpen = open === i;
                        return (
                            <motion.div
                                key={i}
                                initial={{ opacity: 0, y: 10 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: i * 0.04 }}
                                data-testid={`faq-item-${i}`}
                                className={`rounded-2xl border transition-all duration-300 ${
                                    isOpen
                                        ? "glass-pink border-[#FF2A85]/40 shadow-lg shadow-pink-500/10"
                                        : "glass border-white/[0.06] hover:border-white/[0.12]"
                                }`}
                            >
                                <button
                                    data-testid={`faq-toggle-${i}`}
                                    onClick={() => setOpen(isOpen ? -1 : i)}
                                    className="w-full flex items-center justify-between gap-4 p-5 lg:p-6 text-left"
                                >
                                    <span className={`font-semibold text-sm lg:text-base ${isOpen ? "text-white" : "text-zinc-200"}`}>
                                        {faq.q}
                                    </span>
                                    <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                                        isOpen ? "neon-gradient rotate-45" : "bg-white/5"
                                    }`}>
                                        <Plus className="w-4 h-4" />
                                    </div>
                                </button>
                                <AnimatePresence initial={false}>
                                    {isOpen && (
                                        <motion.div
                                            initial={{ height: 0, opacity: 0 }}
                                            animate={{ height: "auto", opacity: 1 }}
                                            exit={{ height: 0, opacity: 0 }}
                                            transition={{ duration: 0.3, ease: "easeInOut" }}
                                            className="overflow-hidden"
                                        >
                                            <div className="px-5 lg:px-6 pb-5 lg:pb-6 text-sm text-zinc-400 leading-relaxed">
                                                {faq.a}
                                            </div>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </motion.div>
                        );
                    })}
                </div>

                <div className="text-center mt-10">
                    <p className="text-sm text-zinc-500 mb-3">Still have questions?</p>
                    <a href="#contact" data-testid="faq-contact-btn" className="btn-ghost inline-flex items-center gap-2 text-sm">
                        <HelpCircle className="w-4 h-4" /> Contact Support
                    </a>
                </div>
            </div>
        </section>
    );
}
