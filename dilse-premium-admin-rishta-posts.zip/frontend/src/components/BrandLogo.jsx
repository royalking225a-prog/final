import { useBranding, resolveLogoUrl } from "@/context/BrandingContext";
import DilSeLogoSvg from "@/components/DilSeLogoSvg";

const sizeMap = {
    sm: { px: 32, text: "text-base", tag: "text-[8px]" },
    md: { px: 44, text: "text-xl", tag: "text-[9px]" },
    lg: { px: 56, text: "text-2xl", tag: "text-[10px]" },
    xl: { px: 80, text: "text-3xl", tag: "text-[11px]" },
};

export default function BrandLogo({ size = "md", showText = true, className = "" }) {
    const { branding } = useBranding();
    const sz = sizeMap[size] || sizeMap.md;
    const useCustom = branding?.logo_url && !branding.logo_url.includes("8c0kbul1_WhatsApp");
    const customUrl = useCustom ? resolveLogoUrl(branding.logo_url) : null;

    return (
        <div className={`flex items-center gap-3 ${className}`} data-testid="brand-logo">
            {customUrl ? (
                <div className="rounded-2xl overflow-hidden relative" style={{ width: sz.px, height: sz.px }}>
                    <img src={customUrl} alt={branding?.brand_name || "DilSe"} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 rounded-2xl neon-gradient blur-xl opacity-30 -z-10" />
                </div>
            ) : (
                <DilSeLogoSvg size={sz.px} />
            )}
            {showText && (
                <div className="leading-tight">
                    <div className={`font-['Outfit'] ${sz.text} font-bold tracking-tight bg-gradient-to-r from-[#FF2A85] via-[#D946EF] to-[#8B5CF6] bg-clip-text text-transparent`}>
                        {branding?.brand_name || "DilSe"}
                    </div>
                    <div className={`${sz.tag} uppercase tracking-[0.25em] text-zinc-500`}>
                        {branding?.tagline || "Premium Rishta & Dating"}
                    </div>
                </div>
            )}
        </div>
    );
}
