import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Sparkles, AlertCircle, AlertTriangle, Check, Crown } from "lucide-react";
import api from "@/lib/api";

const TYPE_STYLES = {
    success: { icon: Check, color: "from-emerald-500 to-cyan-500", iconBg: "bg-emerald-500/20", iconColor: "text-emerald-400" },
    error: { icon: AlertCircle, color: "from-red-500 to-rose-500", iconBg: "bg-red-500/20", iconColor: "text-red-400" },
    warning: { icon: AlertTriangle, color: "from-amber-500 to-orange-500", iconBg: "bg-amber-500/20", iconColor: "text-amber-400" },
    promo: { icon: Crown, color: "from-[#FF2A85] to-[#8B5CF6]", iconBg: "bg-[#FF2A85]/20", iconColor: "text-[#FF2A85]" },
};

export default function PopupRenderer() {
    const [popup, setPopup] = useState(null);
    const [open, setOpen] = useState(false);

    useEffect(() => {
        api.get("/popup").then(({ data }) => {
            if (data.popup) {
                const dismissedKey = `dilse_popup_${data.popup.id}`;
                if (data.popup.show_once && localStorage.getItem(dismissedKey)) return;
                setPopup(data.popup);
                setTimeout(() => setOpen(true), 1500);
            }
        }).catch(() => {});
    }, []);

    const handleClose = () => {
        setOpen(false);
        if (popup?.show_once) localStorage.setItem(`dilse_popup_${popup.id}`, "1");
    };

    if (!popup) return null;
    const style = TYPE_STYLES[popup.type] || TYPE_STYLES.promo;
    const Icon = style.icon;

    return (
        <AnimatePresence>
            {open && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={handleClose}
                    className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
                    data-testid="popup-modal"
                >
                    <motion.div
                        initial={{ scale: 0.85, opacity: 0, y: 20 }}
                        animate={{ scale: 1, opacity: 1, y: 0 }}
                        exit={{ scale: 0.85, opacity: 0 }}
                        transition={{ type: "spring", damping: 20 }}
                        onClick={(e) => e.stopPropagation()}
                        className="glass-strong rounded-3xl p-8 max-w-md w-full relative overflow-hidden"
                    >
                        <div className={`absolute -top-12 -right-12 w-40 h-40 bg-gradient-to-br ${style.color} blur-3xl opacity-30 -z-10`} />
                        <button onClick={handleClose} className="absolute top-4 right-4 w-8 h-8 rounded-full glass flex items-center justify-center hover:bg-white/10" data-testid="popup-close">
                            <X className="w-4 h-4" />
                        </button>
                        <div className={`w-14 h-14 rounded-2xl ${style.iconBg} ${style.iconColor} flex items-center justify-center mb-5 mx-auto`}>
                            <Icon className="w-7 h-7" />
                        </div>
                        <h2 className="font-['Outfit'] text-2xl font-bold mb-2 text-center">{popup.title}</h2>
                        <p className="text-sm text-zinc-400 leading-relaxed text-center mb-6">{popup.body}</p>
                        {popup.cta_label && popup.cta_url && (
                            <a
                                href={popup.cta_url}
                                onClick={handleClose}
                                data-testid="popup-cta"
                                className={`block w-full text-center bg-gradient-to-r ${style.color} text-white py-3 rounded-full font-semibold shadow-lg hover:shadow-xl transition-all`}
                            >
                                {popup.cta_label}
                            </a>
                        )}
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
}
