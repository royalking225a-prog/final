/**
 * Custom DilSe Premium Romantic SVG Logo
 * Heart with couple silhouette inside, neon pink+purple gradient, gold accent sparkle
 */
export default function DilSeLogoSvg({ size = 48, showText = false, className = "" }) {
    const uid = "dilse-grad-" + Math.random().toString(36).slice(2, 8);
    return (
        <div className={`inline-flex items-center gap-3 ${className}`}>
            <svg width={size} height={size} viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0">
                <defs>
                    <linearGradient id={`${uid}-heart`} x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#FF2A85" />
                        <stop offset="55%" stopColor="#D946EF" />
                        <stop offset="100%" stopColor="#8B5CF6" />
                    </linearGradient>
                    <linearGradient id={`${uid}-couple`} x1="0%" y1="100%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#FF6FA8" />
                        <stop offset="100%" stopColor="#FFB3D1" />
                    </linearGradient>
                    <radialGradient id={`${uid}-glow`} cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#FF2A85" stopOpacity="0.5" />
                        <stop offset="100%" stopColor="#8B5CF6" stopOpacity="0" />
                    </radialGradient>
                    <filter id={`${uid}-blur`} x="-50%" y="-50%" width="200%" height="200%">
                        <feGaussianBlur stdDeviation="2" />
                    </filter>
                </defs>
                {/* Outer glow */}
                <circle cx="32" cy="32" r="30" fill={`url(#${uid}-glow)`} />
                {/* Heart shape */}
                <path
                    d="M32 56C32 56 8 42 8 24C8 16 14 10 22 10C26 10 30 12 32 16C34 12 38 10 42 10C50 10 56 16 56 24C56 42 32 56 32 56Z"
                    fill={`url(#${uid}-heart)`}
                    stroke="#FF2A85"
                    strokeWidth="0.5"
                />
                {/* Couple silhouettes inside heart */}
                <g fill={`url(#${uid}-couple)`} opacity="0.92">
                    {/* Woman silhouette - left */}
                    <ellipse cx="25" cy="24" rx="2.6" ry="3" />
                    <path d="M25 27.5 Q22 30 21.5 35 Q21 40 22 44 L24 44 Q23 39 23.5 35 Q24 32 25 30 Q26 32 26.5 35 Q27 39 26 44 L28 44 Q29 40 28.5 35 Q28 30 25 27.5 Z" />
                    {/* Hair flow */}
                    <path d="M22 22 Q19 26 19 32 Q20 28 22.5 26 Z" opacity="0.7" />
                    {/* Man silhouette - right */}
                    <ellipse cx="38" cy="24" rx="2.6" ry="3" />
                    <path d="M38 27.5 Q35 30 34.5 35 Q34 40 35 44 L37 44 Q36 39 36.5 35 Q37 32 38 30 Q39 32 39.5 35 Q40 39 39 44 L41 44 Q42 40 41.5 35 Q41 30 38 27.5 Z" />
                </g>
                {/* Gold sparkle accents */}
                <g fill="#FFD700">
                    <path d="M44 14 L44.8 16 L46.5 16.5 L44.8 17 L44 19 L43.2 17 L41.5 16.5 L43.2 16 Z" opacity="0.9" />
                    <path d="M18 17 L18.5 18 L19.5 18.3 L18.5 18.6 L18 19.6 L17.5 18.6 L16.5 18.3 L17.5 18 Z" opacity="0.7" />
                    <circle cx="49" cy="22" r="0.8" opacity="0.7" />
                    <circle cx="15" cy="30" r="0.6" opacity="0.6" />
                </g>
                {/* Heart highlight */}
                <path d="M14 22 Q14 18 18 14 Q20 14 21 16 Q19 17 17 19 Q15 21 14 22 Z" fill="#ffffff" opacity="0.15" />
            </svg>
            {showText && (
                <div className="leading-tight">
                    <div className="font-['Outfit'] text-xl font-bold tracking-tight bg-gradient-to-r from-[#FF2A85] via-[#D946EF] to-[#8B5CF6] bg-clip-text text-transparent">DilSe</div>
                    <div className="text-[9px] uppercase tracking-[0.25em] text-zinc-500 -mt-0.5">Premium Rishta & Dating</div>
                </div>
            )}
        </div>
    );
}
