import { useEffect, useState, useRef } from "react";
import AppShell from "@/components/AppShell";
import api, { fileUrl } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { motion } from "framer-motion";
import { Crown, Check, Heart, Copy, Upload, Sparkles, Shield, Star, Mic, Filter, Eye, Camera, AlertCircle } from "lucide-react";
import { toast } from "sonner";

const TIER_STYLES = {
    silver: { gradient: "from-zinc-400 to-zinc-200", border: "border-zinc-400/30", glow: "shadow-zinc-400/20" },
    gold: { gradient: "from-[#FFB800] via-[#FFD700] to-[#FF7A00]", border: "border-amber-400/40", glow: "shadow-amber-500/30" },
};

const FEATURE_ICONS = {
    "Unlimited Likes": Heart,
    "5 Daily Super Likes": Star,
    "See Who Liked You": Eye,
    "Profile Boost 1x Weekly": Sparkles,
    "Premium Badge": Shield,
    "Everything in Silver": Check,
    "Unlimited Super Likes": Star,
    "Unlimited Chat Access": Heart,
    "AI Match Priority": Sparkles,
    "Private Gallery": Camera,
    "Invisible Browsing": Eye,
    "Profile Boost 3x Weekly": Sparkles,
    "Gold Verified Badge": Shield,
};

export default function PremiumPage() {
    const { user, refreshUser } = useAuth();
    const [data, setData] = useState({ plans: [], payment_methods: [] });
    const [selectedPlan, setSelectedPlan] = useState("gold");
    const [selectedMethod, setSelectedMethod] = useState(null);
    const [txnId, setTxnId] = useState("");
    const [screenshotPath, setScreenshotPath] = useState(null);
    const [screenshotPreview, setScreenshotPreview] = useState(null);
    const [submitting, setSubmitting] = useState(false);
    const [submissions, setSubmissions] = useState([]);
    const fileRef = useRef();

    useEffect(() => {
        api.get("/premium/plans").then(({ data }) => {
            setData(data);
            if (data.payment_methods?.length) setSelectedMethod(data.payment_methods[0].id);
        });
        api.get("/premium/my-submissions").then(({ data }) => setSubmissions(data.submissions || []));
    }, []);

    const copyAccount = (acc) => {
        navigator.clipboard.writeText(acc);
        toast.success("Account number copied!");
    };

    const handleScreenshot = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const fd = new FormData();
        fd.append("file", file);
        try {
            const { data } = await api.post("/premium/upload-screenshot", fd, { headers: { "Content-Type": "multipart/form-data" } });
            setScreenshotPath(data.path);
            setScreenshotPreview(URL.createObjectURL(file));
            toast.success("Screenshot uploaded");
        } catch {
            toast.error("Upload failed");
        }
    };

    const submitPayment = async () => {
        if (!screenshotPath) { toast.error("Please upload payment screenshot"); return; }
        if (!txnId.trim()) { toast.error("Please enter transaction ID"); return; }
        setSubmitting(true);
        try {
            await api.post("/premium/submit-payment", {
                plan_id: selectedPlan,
                method_id: selectedMethod,
                transaction_id: txnId.trim(),
                screenshot_path: screenshotPath,
            });
            toast.success("Payment submitted! Admin will verify within 24 hours.");
            setTxnId("");
            setScreenshotPath(null);
            setScreenshotPreview(null);
            const { data } = await api.get("/premium/my-submissions");
            setSubmissions(data.submissions || []);
        } catch (e) {
            toast.error(e.response?.data?.detail || "Submission failed");
        } finally {
            setSubmitting(false);
        }
    };

    const activeMethod = data.payment_methods.find((m) => m.id === selectedMethod);
    const activePlan = data.plans.find((p) => p.id === selectedPlan);

    return (
        <AppShell>
            <div className="max-w-6xl mx-auto">
                <div className="text-center mb-10">
                    <Crown className="w-14 h-14 mx-auto text-[#FFB800] mb-4 animate-float" style={{ filter: "drop-shadow(0 0 20px rgba(255, 184, 0, 0.5))" }} />
                    <h1 className="font-['Outfit'] text-4xl lg:text-5xl font-bold mb-3">
                        Choose Your <span className="text-neon-gradient">VIP Status</span>
                    </h1>
                    <p className="text-zinc-400 max-w-xl mx-auto">Unlock premium features and find your perfect match faster. Manual bank transfer with quick verification.</p>
                </div>

                {user?.premium && (
                    <div className="glass-pink rounded-3xl p-6 mb-8 text-center" data-testid="already-premium">
                        <Crown className="w-8 h-8 text-[#FFB800] mx-auto mb-2" />
                        <div className="font-bold text-lg">You're already a {user.premium_tier?.toUpperCase() || "Premium"} member!</div>
                        <div className="text-xs text-zinc-400 mt-1">Enjoy all features unlocked.</div>
                    </div>
                )}

                {/* Plans */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                    {data.plans.map((plan, i) => {
                        const styles = TIER_STYLES[plan.id] || TIER_STYLES.silver;
                        const isActive = selectedPlan === plan.id;
                        const isGold = plan.id === "gold";
                        return (
                            <motion.button
                                key={plan.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.1 }}
                                data-testid={`plan-${plan.id}`}
                                onClick={() => setSelectedPlan(plan.id)}
                                className={`text-left rounded-3xl p-8 relative transition-all duration-500 group overflow-hidden ${
                                    isActive
                                        ? `glass-strong border-2 ${styles.border} shadow-2xl ${styles.glow}`
                                        : "glass border border-white/[0.06] hover:border-white/20"
                                }`}
                            >
                                {/* Gold ribbon */}
                                {isGold && (
                                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-[#FFB800] to-[#FF7A00] text-[10px] font-bold uppercase tracking-[0.15em] shadow-lg shadow-amber-500/40">
                                        ⭐ Most Popular
                                    </div>
                                )}
                                {/* Gradient overlay on hover */}
                                <div className={`absolute -inset-px rounded-3xl bg-gradient-to-br ${styles.gradient} opacity-0 group-hover:opacity-10 transition-opacity pointer-events-none`} />
                                {/* Header */}
                                <div className="flex items-center gap-3 mb-4">
                                    <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${styles.gradient} flex items-center justify-center shadow-lg`}>
                                        <Crown className={`w-6 h-6 ${isGold ? "text-white" : "text-zinc-900"}`} fill={isGold ? "white" : "currentColor"} />
                                    </div>
                                    <div>
                                        <div className="font-['Outfit'] text-2xl font-bold">{plan.name}</div>
                                        <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-bold">{plan.days} Days Access</div>
                                    </div>
                                </div>
                                {/* Price */}
                                <div className="flex items-baseline gap-2 mb-6">
                                    <span className="text-5xl font-bold">{plan.amount}</span>
                                    <span className="text-zinc-500 text-sm font-bold">PKR</span>
                                </div>
                                {/* Features */}
                                <ul className="space-y-2.5 mb-2">
                                    {plan.features.map((f) => {
                                        const Icon = FEATURE_ICONS[f] || Check;
                                        return (
                                            <li key={f} className="flex items-start gap-2.5 text-sm text-zinc-300">
                                                <Icon className={`w-4 h-4 flex-shrink-0 mt-0.5 ${isGold ? "text-[#FFB800]" : "text-[#FF2A85]"}`} />
                                                <span>{f}</span>
                                            </li>
                                        );
                                    })}
                                </ul>
                                {isActive && (
                                    <div className={`mt-5 pt-4 border-t border-white/5 flex items-center gap-2 text-xs font-bold ${isGold ? "text-[#FFB800]" : "text-[#FF2A85]"}`}>
                                        <Check className="w-4 h-4" /> Selected — see payment options below
                                    </div>
                                )}
                            </motion.button>
                        );
                    })}
                </div>

                {/* Payment Methods */}
                {!user?.premium && activePlan && (
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-strong rounded-3xl p-6 lg:p-8 mb-8">
                        <div className="flex items-center gap-2 mb-6">
                            <div className="w-10 h-10 rounded-xl neon-gradient flex items-center justify-center">
                                <span className="text-lg">💳</span>
                            </div>
                            <div>
                                <h2 className="font-['Outfit'] text-xl font-bold">Payment Methods</h2>
                                <p className="text-xs text-zinc-500">Send <span className="font-bold text-[#FF2A85]">{activePlan.amount} PKR</span> to any account below</p>
                            </div>
                        </div>
                        {/* Method picker tabs */}
                        <div className="grid grid-cols-2 gap-3 mb-6">
                            {data.payment_methods.map((m) => (
                                <button
                                    key={m.id}
                                    data-testid={`payment-method-${m.id}`}
                                    onClick={() => setSelectedMethod(m.id)}
                                    className={`p-4 rounded-2xl border transition-all text-left ${
                                        selectedMethod === m.id
                                            ? "glass-pink border-[#FF2A85]/40 shadow-lg shadow-pink-500/10"
                                            : "glass border-white/[0.06] hover:border-white/[0.12]"
                                    }`}
                                >
                                    <div className="flex items-center gap-2">
                                        <div className={`w-8 h-8 rounded-lg ${m.type === "wallet" ? "bg-gradient-to-br from-emerald-500 to-cyan-500" : "bg-gradient-to-br from-[#FF2A85] to-[#8B5CF6]"} flex items-center justify-center text-xs font-bold`}>
                                            {m.name[0]}
                                        </div>
                                        <div>
                                            <div className="font-bold text-sm">{m.name}</div>
                                            <div className="text-[10px] text-zinc-500 uppercase tracking-wider">{m.type}</div>
                                        </div>
                                    </div>
                                </button>
                            ))}
                        </div>

                        {/* Active method details */}
                        {activeMethod && (
                            <div className="glass-pink rounded-2xl p-5 mb-6 relative overflow-hidden">
                                <div className="absolute inset-0 -z-10 opacity-30">
                                    <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF2A85]/30 rounded-full blur-3xl" />
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                                    <div className="space-y-3">
                                        <div>
                                            <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-bold mb-1">Account Title</div>
                                            <div className="font-['Outfit'] text-lg font-bold">{activeMethod.title}</div>
                                        </div>
                                        <div>
                                            <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-bold mb-1">{activeMethod.name} {activeMethod.type === "wallet" ? "Number" : "Account Number"}</div>
                                            <div className="flex items-center gap-2">
                                                <code className="font-mono text-lg font-bold text-[#FF2A85] tracking-wide">{activeMethod.account}</code>
                                                <button data-testid="copy-account-btn" onClick={() => copyAccount(activeMethod.account)} className="w-9 h-9 rounded-full neon-gradient flex items-center justify-center shadow-lg shadow-pink-500/30 hover:scale-110 transition-transform" aria-label="Copy">
                                                    <Copy className="w-4 h-4" />
                                                </button>
                                            </div>
                                        </div>
                                        <div>
                                            <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-bold mb-1">Amount to Send</div>
                                            <div className="font-['Outfit'] text-3xl font-bold text-neon-gradient">{activePlan.amount} PKR</div>
                                        </div>
                                    </div>
                                    {/* QR Code Placeholder */}
                                    <div className="flex flex-col items-center justify-center">
                                        <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-bold mb-2">Scan to Pay</div>
                                        <div className="w-32 h-32 rounded-2xl bg-white p-2 shadow-lg shadow-pink-500/20">
                                            <div className="w-full h-full rounded-xl bg-[url('data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A//www.w3.org/2000/svg%27%20viewBox%3D%270%200%2010%2010%27%3E%3Cpath%20fill%3D%27%23000%27%20d%3D%27M0%200h3v3H0zm4%200h1v1H4zm2%200h1v1H6zm1%201h1v1H7zM0%204h1v1H0zm3%200h1v1H3zm2%200h1v1H5zm3%200h2v1H8zM0%206h2v1H0zm4%200h1v1H4zm3%200h1v1H7zm2%200h1v1H9zM2%207h1v1H2zm3%200h2v1H5zM0%208h1v1H0zm2%200h1v2H2zm4%200h1v2H6zm3%200h1v2H9zM4%209h1v1H4z%27/%3E%3C/svg%3E')] bg-no-repeat bg-center bg-contain" />
                                        </div>
                                        <div className="text-[9px] text-zinc-500 mt-2">QR code for {activeMethod.name}</div>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Upload Proof Form */}
                        <div className="space-y-4">
                            <h3 className="font-['Outfit'] text-lg font-bold flex items-center gap-2">
                                <Upload className="w-4 h-4 text-[#FF2A85]" /> Submit Payment Proof
                            </h3>
                            <div>
                                <label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">Transaction ID / Reference</label>
                                <input data-testid="txn-id-input" value={txnId} onChange={(e) => setTxnId(e.target.value)} placeholder="e.g. TX123456789" className="input-dark" />
                            </div>
                            <div>
                                <label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">Payment Screenshot</label>
                                <input ref={fileRef} type="file" accept="image/*" onChange={handleScreenshot} className="hidden" data-testid="screenshot-input" />
                                {screenshotPreview ? (
                                    <div className="relative rounded-2xl overflow-hidden glass-pink p-2 inline-block">
                                        <img src={screenshotPreview} alt="proof" className="max-h-40 rounded-xl" />
                                        <button onClick={() => { setScreenshotPath(null); setScreenshotPreview(null); }} className="absolute top-3 right-3 w-7 h-7 rounded-full bg-black/70 backdrop-blur-md flex items-center justify-center text-xs">×</button>
                                    </div>
                                ) : (
                                    <button data-testid="upload-screenshot-btn" type="button" onClick={() => fileRef.current?.click()} className="w-full rounded-2xl border-2 border-dashed border-white/10 hover:border-[#FF2A85]/50 py-8 flex flex-col items-center gap-2 text-zinc-500 hover:text-[#FF2A85] transition-all">
                                        <Upload className="w-6 h-6" />
                                        <span className="text-xs font-semibold">Click to upload payment screenshot</span>
                                    </button>
                                )}
                            </div>
                            <button
                                data-testid="submit-payment-btn"
                                onClick={submitPayment}
                                disabled={submitting || !screenshotPath || !txnId.trim()}
                                className="w-full btn-primary py-4 text-base inline-flex items-center justify-center gap-2 disabled:opacity-50"
                            >
                                <Crown className="w-5 h-5" /> {submitting ? "Submitting..." : `Submit & Activate ${activePlan.name}`}
                            </button>
                            <p className="text-[10px] text-zinc-500 text-center leading-relaxed flex items-center justify-center gap-1.5">
                                <AlertCircle className="w-3 h-3" /> Admin will verify within 24 hours. You'll receive an email when activated.
                            </p>
                        </div>
                    </motion.div>
                )}

                {/* My Submissions History */}
                {submissions.length > 0 && (
                    <div className="glass rounded-3xl p-6">
                        <h2 className="font-['Outfit'] text-lg font-bold mb-4">My Payment History</h2>
                        <div className="space-y-2">
                            {submissions.map((s) => (
                                <div key={s.id} data-testid={`submission-${s.id}`} className="flex items-center gap-3 p-3 rounded-2xl bg-white/[0.02]">
                                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${s.plan_id === "gold" ? "bg-gradient-to-br from-amber-500 to-orange-500" : "bg-gradient-to-br from-zinc-400 to-zinc-600"}`}>
                                        <Crown className="w-4 h-4 text-white" />
                                    </div>
                                    <div className="flex-1">
                                        <div className="font-bold text-sm capitalize">{s.plan_id} VIP — {s.amount} PKR</div>
                                        <div className="text-xs text-zinc-500">{new Date(s.created_at).toLocaleString()}</div>
                                    </div>
                                    <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                                        s.status === "approved" ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" :
                                        s.status === "rejected" ? "bg-red-500/10 text-red-400 border border-red-500/20" :
                                        "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                                    }`}>{s.status}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </AppShell>
    );
}
