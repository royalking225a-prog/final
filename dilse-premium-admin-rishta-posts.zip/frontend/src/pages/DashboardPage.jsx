import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import AppShell from "@/components/AppShell";
import { useAuth } from "@/context/AuthContext";
import api, { fileUrl } from "@/lib/api";
import { motion } from "framer-motion";
import { Sparkles, Mic, Shield, Users, Crown, Heart, MessageCircle, Eye, ChevronRight, Calendar, Play } from "lucide-react";

export default function DashboardPage() {
    const { user } = useAuth();
    const [recommendations, setRecommendations] = useState([]);
    const [stats, setStats] = useState({ likes: 0, messages: 0, visitors: 0 });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        Promise.all([
            api.get("/ai/recommendations").then(r => r.data).catch(() => ({ recommendations: [] })),
            api.get("/likes/received").then(r => r.data).catch(() => ({ count: 0 })),
            api.get("/matches").then(r => r.data).catch(() => ({ matches: [] })),
            api.get("/visitors").then(r => r.data).catch(() => ({ profiles: [] })),
        ]).then(([recs, likes, matches, visitors]) => {
            setRecommendations(recs.recommendations || []);
            setStats({
                likes: likes.count || 0,
                messages: (matches.matches || []).length,
                visitors: (visitors.profiles || []).length,
            });
            setLoading(false);
        });
    }, []);

    const profileFields = ["name", "age", "city", "profession", "education", "bio"];
    const filledCount = profileFields.filter(f => user?.[f] && String(user[f]).trim()).length;
    const photoCount = user?.photos?.length || 0;
    const hasVoice = !!user?.voice_intro;
    const completeness = Math.round(((filledCount + Math.min(photoCount, 3) + (hasVoice ? 1 : 0)) / (profileFields.length + 4)) * 100);

    return (
        <AppShell>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Hero / Main column */}
                <div className="lg:col-span-2 space-y-6">
                    {/* Hero Banner */}
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="relative rounded-[2rem] overflow-hidden glass-pink p-6 lg:p-8 grain">
                        <div className="absolute inset-0 -z-10">
                            <img src="https://images.unsplash.com/photo-1761125135357-99cbe52a6271?w=1200&q=85" alt="" className="absolute right-0 top-0 h-full w-1/2 object-cover opacity-25" />
                            <div className="absolute inset-0 bg-gradient-to-r from-[#09090b] via-[#09090b]/80 to-transparent" />
                        </div>
                        <div className="relative max-w-lg">
                            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#FF2A85]/20 border border-[#FF2A85]/30 mb-4">
                                <Mic className="w-3.5 h-3.5 text-[#FF2A85]" />
                                <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-[#FF2A85]">Voice Intro Profiles</span>
                            </div>
                            <h1 className="font-['Outfit'] text-3xl sm:text-4xl lg:text-5xl font-bold mb-3 leading-tight">
                                Hear Before You Match <span className="text-[#FF2A85]">♡</span>
                            </h1>
                            <p className="text-sm text-zinc-300 mb-5">
                                Connect deeper with <span className="text-white font-semibold">30 sec voice intro</span> profiles and find your perfect match.
                            </p>
                            <div className="flex items-center gap-3 mb-4">
                                <button data-testid="dashboard-play-intro" className="w-12 h-12 rounded-full neon-gradient flex items-center justify-center shadow-lg shadow-pink-500/50">
                                    <Play className="w-5 h-5 text-white ml-0.5" fill="white" />
                                </button>
                                <div className="flex-1 h-8 waveform" />
                            </div>
                            <Link to="/discover" data-testid="dashboard-discover-cta" className="btn-primary inline-flex items-center gap-2 text-sm">
                                Start Discovering <ChevronRight className="w-4 h-4" />
                            </Link>
                        </div>
                    </motion.div>

                    {/* Quick Actions */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {[
                            { to: "/ai-match", icon: Sparkles, label: "AI Matchmaker", sub: "Smart & Accurate", color: "from-[#FF2A85] to-[#8B5CF6]" },
                            { to: "/discover", icon: Mic, label: "Voice Intros", sub: "Hear 30 Sec Intro", color: "from-[#8B5CF6] to-[#FF7A00]" },
                            { to: "/rishta-requests", icon: Users, label: "Family Mode", sub: "Parents Involved", color: "from-[#FF7A00] to-[#FF2A85]" },
                            { to: "/discover", icon: Calendar, label: "Events", sub: "Join Near You", color: "from-[#8B5CF6] to-[#FF2A85]" },
                        ].map((item, i) => (
                            <Link key={item.label} to={item.to} data-testid={`quick-action-${i}`} className="glass rounded-2xl p-4 hover:bg-white/10 transition-all group">
                                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                                    <item.icon className="w-5 h-5 text-white" />
                                </div>
                                <div className="font-bold text-sm mb-0.5">{item.label}</div>
                                <div className="text-[11px] text-zinc-500">{item.sub}</div>
                            </Link>
                        ))}
                    </div>

                    {/* Recommended For You */}
                    <div>
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="font-['Outfit'] text-xl font-bold">Recommended For You</h2>
                            <Link to="/discover" data-testid="dashboard-view-all-recs" className="text-xs text-[#FF2A85] hover:underline">View All</Link>
                        </div>
                        {loading ? (
                            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                                {[...Array(4)].map((_, i) => <div key={i} className="h-72 rounded-3xl glass animate-pulse" />)}
                            </div>
                        ) : recommendations.length === 0 ? (
                            <div data-testid="no-recommendations" className="glass rounded-3xl p-8 text-center text-zinc-500">
                                <Heart className="w-10 h-10 mx-auto mb-3 text-zinc-700" />
                                No recommendations yet. Be the first to invite people to DilSe!
                            </div>
                        ) : (
                            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                                {recommendations.slice(0, 4).map((r) => (
                                    <RecommendCard key={r.profile.id} profile={r.profile} score={r.compatibility.overall} />
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                {/* Right Column */}
                <div className="space-y-6">
                    {/* Profile Completeness */}
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-6">
                        <h3 className="font-['Outfit'] font-bold mb-4">Profile Completeness</h3>
                        <div className="flex items-center gap-6 mb-5">
                            <div className="relative w-20 h-20">
                                <svg className="w-20 h-20 -rotate-90" viewBox="0 0 80 80">
                                    <circle cx="40" cy="40" r="34" stroke="#27272a" strokeWidth="6" fill="none" />
                                    <circle cx="40" cy="40" r="34" stroke="url(#grad)" strokeWidth="6" fill="none"
                                            strokeDasharray={`${(completeness / 100) * 213.6} 213.6`} strokeLinecap="round" />
                                    <defs>
                                        <linearGradient id="grad" x1="0" y1="0" x2="1" y2="1">
                                            <stop offset="0%" stopColor="#FF2A85" />
                                            <stop offset="100%" stopColor="#8B5CF6" />
                                        </linearGradient>
                                    </defs>
                                </svg>
                                <div className="absolute inset-0 flex items-center justify-center font-bold text-lg">{completeness}%</div>
                            </div>
                            <div>
                                <div className="font-bold text-[#FF2A85]">{completeness > 80 ? "Excellent!" : completeness > 50 ? "Very Good!" : "Get Started"}</div>
                                <div className="text-xs text-zinc-400">Complete your profile to get better matches.</div>
                            </div>
                        </div>
                        <ul className="space-y-2 mb-4">
                            {[
                                { label: "Basic Information", done: !!user?.name && !!user?.age },
                                { label: "About You", done: !!user?.bio },
                                { label: `Photos (${photoCount}/5)`, done: photoCount >= 1 },
                                { label: "Voice Intro", done: hasVoice },
                                { label: "Lifestyle", done: !!user?.interests?.length },
                            ].map((item) => (
                                <li key={item.label} className="flex items-center gap-2 text-xs">
                                    <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] ${item.done ? "bg-emerald-500/20 text-emerald-400" : "bg-white/5 text-zinc-600"}`}>
                                        {item.done ? "✓" : ""}
                                    </div>
                                    <span className={item.done ? "text-zinc-300" : "text-zinc-500"}>{item.label}</span>
                                </li>
                            ))}
                        </ul>
                        <Link to="/profile/me" data-testid="dashboard-complete-profile-btn" className="block text-center btn-primary text-sm py-2.5">
                            Complete Profile
                        </Link>
                    </motion.div>

                    {/* Premium Card */}
                    {!user?.premium && (
                        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-pink rounded-3xl p-6 relative overflow-hidden">
                            <div className="flex items-center gap-2 mb-4">
                                <Crown className="w-6 h-6 text-[#FFB800]" />
                                <h3 className="font-['Outfit'] font-bold text-lg">Premium Membership</h3>
                            </div>
                            <p className="text-xs text-zinc-400 mb-4">Unlock exclusive features</p>
                            <div className="grid grid-cols-4 gap-2 mb-5">
                                {[
                                    { icon: Heart, label: "Unlimited Likes" },
                                    { icon: Eye, label: "See Who Likes You" },
                                    { icon: Sparkles, label: "Advanced Filters" },
                                    { icon: Shield, label: "Private Photos" },
                                ].map((f) => (
                                    <div key={f.label} className="text-center">
                                        <div className="w-10 h-10 mx-auto rounded-xl bg-[#FF2A85]/10 border border-[#FF2A85]/20 flex items-center justify-center mb-1.5">
                                            <f.icon className="w-4 h-4 text-[#FF2A85]" />
                                        </div>
                                        <div className="text-[9px] text-zinc-500 leading-tight">{f.label}</div>
                                    </div>
                                ))}
                            </div>
                            <Link to="/premium" data-testid="dashboard-upgrade-btn" className="block text-center btn-primary text-sm py-2.5">Upgrade Now</Link>
                        </motion.div>
                    )}

                    {/* Stats / Recent Activity */}
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-6">
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="font-['Outfit'] font-bold">Recent Activity</h3>
                            <Link to="/likes" data-testid="dashboard-view-activity" className="text-xs text-[#FF2A85] hover:underline">View All</Link>
                        </div>
                        <div className="space-y-3">
                            <ActivityRow icon={Heart} label="Likes received" value={stats.likes} color="text-[#FF2A85]" />
                            <ActivityRow icon={MessageCircle} label="Active matches" value={stats.messages} color="text-[#8B5CF6]" />
                            <ActivityRow icon={Eye} label="Profile visitors" value={stats.visitors} color="text-[#FF7A00]" />
                        </div>
                    </motion.div>
                </div>
            </div>
        </AppShell>
    );
}

function ActivityRow({ icon: Icon, label, value, color }) {
    return (
        <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/[0.02] hover:bg-white/5 transition-colors">
            <div className={`w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center ${color}`}>
                <Icon className="w-4 h-4" />
            </div>
            <div className="flex-1">
                <div className="text-sm font-medium">{label}</div>
            </div>
            <div className="font-bold text-lg">{value}</div>
        </div>
    );
}

function RecommendCard({ profile, score }) {
    const photo = profile.photos?.[0]?.path;
    return (
        <Link to={`/profile/${profile.id}`} data-testid={`recommend-card-${profile.id}`} className="block group">
            <div className="relative aspect-[3/4] rounded-3xl overflow-hidden glass">
                {photo ? (
                    <img src={fileUrl(photo)} alt={profile.name} className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                ) : (
                    <div className="absolute inset-0 bg-gradient-to-br from-[#FF2A85]/30 to-[#8B5CF6]/30 flex items-center justify-center text-5xl font-bold">
                        {profile.name?.[0]?.toUpperCase()}
                    </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                {profile.online && (
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-black/60 backdrop-blur-md">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        <span className="text-[10px] font-semibold">Online</span>
                    </div>
                )}
                {profile.voice_intro && (
                    <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-[#FF2A85] flex items-center justify-center">
                        <Mic className="w-3.5 h-3.5 text-white" />
                    </div>
                )}
                <div className="absolute bottom-0 left-0 right-0 p-4">
                    <div className="flex items-center gap-1 mb-1">
                        <span className="text-base font-bold">{profile.name}</span>
                        {profile.verified && <Shield className="w-3.5 h-3.5 text-[#FF2A85]" fill="#FF2A85" />}
                    </div>
                    <div className="text-xs text-zinc-300 mb-1">{profile.age} • {profile.city || "—"}</div>
                    <div className="text-[10px] text-zinc-400">{profile.profession || "—"}</div>
                    <div className="text-xs font-bold text-[#FF2A85] mt-1.5">{score}% Match</div>
                </div>
            </div>
        </Link>
    );
}
