import { useState } from "react";
import { Link } from "react-router-dom";
import { Mail } from "lucide-react";
import api, { formatErrorDetail } from "@/lib/api";
import { toast } from "sonner";
import BrandLogo from "@/components/BrandLogo";

export default function ForgotPasswordPage() {
    const [email, setEmail] = useState("");
    const [done, setDone] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await api.post("/auth/forgot-password", { email });
            setDone(true);
            toast.success("Reset link sent if account exists");
        } catch (e) {
            toast.error(formatErrorDetail(e.response?.data?.detail) || "Request failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-[#09090b] text-white px-4 relative overflow-hidden">
            <div className="fixed inset-0 pointer-events-none">
                <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-[#FF2A85]/15 rounded-full blur-[120px]" />
            </div>
            <div className="relative z-10 w-full max-w-md">
                <Link to="/" className="flex justify-center mb-8">
                    <BrandLogo size="md" />
                </Link>
                <div className="glass-strong rounded-3xl p-8">
                    <h1 className="font-['Outfit'] text-3xl font-bold mb-2">Reset password</h1>
                    <p className="text-sm text-zinc-400 mb-6">We'll send you a reset link</p>
                    {done ? (
                        <div data-testid="forgot-success" className="glass-pink rounded-2xl p-5 text-sm text-zinc-200">
                            If an account exists for <strong>{email}</strong>, a password reset link has been sent. Check the backend logs for the reset link (during development).
                        </div>
                    ) : (
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="relative">
                                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                                <input data-testid="forgot-email-input" type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="input-dark pl-11" />
                            </div>
                            <button data-testid="forgot-submit-btn" type="submit" disabled={loading} className="w-full btn-primary disabled:opacity-50">
                                {loading ? "Sending..." : "Send reset link"}
                            </button>
                        </form>
                    )}
                    <div className="text-center mt-6 text-sm text-zinc-500">
                        <Link to="/login" className="text-[#FF2A85] font-semibold hover:underline">Back to login</Link>
                    </div>
                </div>
            </div>
        </div>
    );
}
