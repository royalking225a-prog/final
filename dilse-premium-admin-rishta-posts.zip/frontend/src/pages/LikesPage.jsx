import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import AppShell from "@/components/AppShell";
import api, { fileUrl } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Heart, Lock, Crown } from "lucide-react";

export default function LikesPage() {
    const { user } = useAuth();
    const [data, setData] = useState({ count: 0, profiles: [], blurred: true });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        api.get("/likes/received").then(({ data }) => {
            setData(data);
            setLoading(false);
        });
    }, []);

    return (
        <AppShell>
            <div className="max-w-5xl mx-auto">
                <div className="mb-6">
                    <h1 className="font-['Outfit'] text-3xl font-bold mb-1">Who Likes You</h1>
                    <p className="text-sm text-zinc-400">{data.count} {data.count === 1 ? "person" : "people"} liked your profile</p>
                </div>

                {loading ? (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{[...Array(4)].map((_, i) => <div key={i} className="aspect-[3/4] glass animate-pulse rounded-3xl" />)}</div>
                ) : data.blurred ? (
                    <div className="glass-pink rounded-3xl p-8 text-center" data-testid="likes-locked">
                        <Crown className="w-12 h-12 mx-auto mb-4 text-[#FFB800]" />
                        <h3 className="font-['Outfit'] text-2xl font-bold mb-2">{data.count} people liked you</h3>
                        <p className="text-sm text-zinc-400 mb-6">Upgrade to Premium to see who likes you and match instantly</p>
                        <Link to="/premium" className="btn-primary inline-flex items-center gap-2">
                            <Crown className="w-4 h-4" /> Upgrade to See
                        </Link>
                    </div>
                ) : data.profiles.length === 0 ? (
                    <div className="glass rounded-3xl p-12 text-center">
                        <Heart className="w-12 h-12 mx-auto mb-4 text-zinc-700" />
                        <h3 className="font-['Outfit'] text-xl font-bold mb-2">No likes yet</h3>
                        <p className="text-sm text-zinc-400">Keep being awesome — likes will come!</p>
                    </div>
                ) : (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {data.profiles.map((p) => (
                            <Link key={p.id} to={`/profile/${p.id}`} data-testid={`like-card-${p.id}`} className="block group">
                                <div className="relative aspect-[3/4] rounded-3xl overflow-hidden glass">
                                    {p.photos?.[0]?.path ? (
                                        <img src={fileUrl(p.photos[0].path)} className="w-full h-full object-cover group-hover:scale-105 transition" alt="" />
                                    ) : (
                                        <div className="w-full h-full bg-gradient-to-br from-[#FF2A85]/30 to-[#8B5CF6]/30 flex items-center justify-center text-4xl font-bold">{p.name?.[0]}</div>
                                    )}
                                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
                                    <div className="absolute bottom-3 left-3 right-3">
                                        <div className="font-bold">{p.name}, {p.age}</div>
                                        <div className="text-xs text-zinc-400">{p.city}</div>
                                    </div>
                                    <Heart className="absolute top-3 right-3 w-5 h-5 text-[#FF2A85]" fill="#FF2A85" />
                                </div>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
        </AppShell>
    );
}
