import { useState } from "react";
import { Link, useSearchParams, useNavigate } from "react-router-dom";
import { Lock } from "lucide-react";
import api, { formatErrorDetail } from "@/lib/api";
import { toast } from "sonner";
import BrandLogo from "@/components/BrandLogo";

export default function ResetPasswordPage() {
    const [params] = useSearchParams();
    const navigate = useNavigate();
    const token = params.get("token") || "";
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await api.post("/auth/reset-password", { token, new_password: password });
            toast.success("Password reset! You can login now.");
            navigate("/login");
        } catch (e) {
            toast.error(formatErrorDetail(e.response?.data?.detail) || "Reset failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-[#09090b] text-white px-4">
            <div className="relative z-10 w-full max-w-md">
                <Link to="/" className="flex justify-center mb-8">
                    <BrandLogo size="md" />
                </Link>
                <div className="glass-strong rounded-3xl p-8">
                    <h1 className="font-['Outfit'] text-3xl font-bold mb-2">New password</h1>
                    <p className="text-sm text-zinc-400 mb-6">Choose a strong new password</p>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="relative">
                            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                            <input data-testid="reset-password-input" type="password" required minLength={6} placeholder="New password" value={password} onChange={(e) => setPassword(e.target.value)} className="input-dark pl-11" />
                        </div>
                        <button data-testid="reset-submit-btn" type="submit" disabled={loading} className="w-full btn-primary disabled:opacity-50">
                            {loading ? "Resetting..." : "Reset password"}
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
}
