import { useEffect, useState, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import AppShell from "@/components/AppShell";
import { useAuth } from "@/context/AuthContext";
import api, { fileUrl, API } from "@/lib/api";
import { motion } from "framer-motion";
import { Send, Mic, ArrowLeft, Play, MicOff, Heart } from "lucide-react";
import { toast } from "sonner";

export default function ChatPage() {
    const { matchId } = useParams();
    const { user } = useAuth();
    const [messages, setMessages] = useState([]);
    const [matchUser, setMatchUser] = useState(null);
    const [text, setText] = useState("");
    const [loading, setLoading] = useState(true);
    const [recording, setRecording] = useState(false);
    const [typingFromOther, setTypingFromOther] = useState(false);
    const messagesEndRef = useRef();
    const wsRef = useRef(null);
    const mediaRecorderRef = useRef(null);
    const audioChunksRef = useRef([]);
    const typingTimeoutRef = useRef(null);

    const loadMessages = async () => {
        try {
            const { data } = await api.get(`/messages/${matchId}`);
            setMessages(data.messages || []);
        } catch (e) {}
    };

    // Connect WebSocket
    useEffect(() => {
        const token = localStorage.getItem("dilse_token");
        if (!token) return;
        const wsUrl = API.replace(/^http/, "ws") + `/ws/chat?token=${token}`;
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;
        ws.onmessage = (evt) => {
            try {
                const msg = JSON.parse(evt.data);
                if (msg.type === "message" && msg.data?.match_id === matchId) {
                    setMessages((prev) => {
                        if (prev.find((m) => m.id === msg.data.id)) return prev;
                        return [...prev, msg.data];
                    });
                } else if (msg.type === "typing" && msg.match_id === matchId && msg.user_id !== user.id) {
                    setTypingFromOther(true);
                    clearTimeout(typingTimeoutRef.current);
                    typingTimeoutRef.current = setTimeout(() => setTypingFromOther(false), 3000);
                }
            } catch (e) {}
        };
        // Keepalive ping
        const ping = setInterval(() => {
            if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: "ping" }));
        }, 30000);
        return () => {
            clearInterval(ping);
            ws.close();
        };
        // eslint-disable-next-line
    }, [matchId, user?.id]);

    useEffect(() => {
        api.get("/matches").then(({ data }) => {
            const m = (data.matches || []).find((x) => x.match_id === matchId);
            if (m) setMatchUser(m.user);
        });
        loadMessages().then(() => setLoading(false));
        // eslint-disable-next-line
    }, [matchId]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, typingFromOther]);

    const sendMessage = async (e) => {
        e?.preventDefault();
        if (!text.trim()) return;
        try {
            await api.post("/messages", { match_id: matchId, text: text.trim(), type: "text" });
            setText("");
            // WS broadcast will update UI
        } catch (e) {
            toast.error("Failed to send");
        }
    };

    const handleTyping = (e) => {
        setText(e.target.value);
        if (wsRef.current?.readyState === WebSocket.OPEN) {
            wsRef.current.send(JSON.stringify({ type: "typing", match_id: matchId }));
        }
    };

    const startVoice = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const recorder = new MediaRecorder(stream);
            audioChunksRef.current = [];
            recorder.ondataavailable = (e) => audioChunksRef.current.push(e.data);
            recorder.onstop = async () => {
                const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
                const fd = new FormData();
                fd.append("file", blob, "voice.webm");
                fd.append("match_id", matchId);
                try {
                    await api.post("/messages/voice", fd, { headers: { "Content-Type": "multipart/form-data" } });
                } catch {
                    toast.error("Failed to send voice note");
                }
                stream.getTracks().forEach((t) => t.stop());
            };
            recorder.start();
            mediaRecorderRef.current = recorder;
            setRecording(true);
            setTimeout(() => { if (mediaRecorderRef.current?.state === "recording") stopVoice(); }, 60000);
        } catch (e) {
            toast.error("Microphone access denied");
        }
    };

    const stopVoice = () => {
        mediaRecorderRef.current?.stop();
        setRecording(false);
    };

    return (
        <AppShell>
            <div className="max-w-3xl mx-auto h-[calc(100vh-180px)] lg:h-[calc(100vh-160px)] flex flex-col glass-strong rounded-3xl overflow-hidden">
                {/* Chat Header */}
                <div className="flex items-center gap-3 p-4 border-b border-white/5">
                    <Link to="/messages" data-testid="chat-back-btn" className="lg:hidden">
                        <ArrowLeft className="w-5 h-5" />
                    </Link>
                    {matchUser && (
                        <Link to={`/profile/${matchUser.id}`} className="flex items-center gap-3 flex-1">
                            <div className="relative">
                                {matchUser.photos?.[0]?.path ? (
                                    <img src={fileUrl(matchUser.photos[0].path)} className="w-11 h-11 rounded-2xl object-cover" alt="" />
                                ) : (
                                    <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#FF2A85] to-[#8B5CF6] flex items-center justify-center font-bold">{matchUser.name?.[0]}</div>
                                )}
                                {matchUser.online && <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#0f0f10]" />}
                            </div>
                            <div>
                                <div className="font-bold flex items-center gap-1">{matchUser.name} {matchUser.verified && <Heart className="w-3 h-3 text-[#FF2A85]" fill="#FF2A85" />}</div>
                                <div className="text-[10px] text-zinc-500">{matchUser.online ? "Online now" : "Last seen recently"}</div>
                            </div>
                        </Link>
                    )}
                    <div data-testid="chat-ws-status" className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-emerald-400 font-bold">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Live
                    </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    {loading ? (
                        <div className="text-center text-zinc-500 text-sm">Loading...</div>
                    ) : messages.length === 0 ? (
                        <div data-testid="chat-empty" className="text-center text-zinc-500 text-sm py-8">
                            <Heart className="w-10 h-10 mx-auto mb-3 text-[#FF2A85]" fill="#FF2A85" />
                            Say salaam to start the conversation!
                        </div>
                    ) : (
                        messages.map((m) => {
                            const mine = m.sender_id === user.id;
                            return (
                                <motion.div key={m.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                                    <div data-testid={`message-${m.id}`} className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm ${mine ? "neon-gradient text-white rounded-br-sm" : "glass text-zinc-100 rounded-bl-sm"}`}>
                                        {m.type === "voice" ? (
                                            <div className="flex items-center gap-2 min-w-[180px]">
                                                <button className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                                                    <Play className="w-3.5 h-3.5 ml-0.5" fill="white" />
                                                </button>
                                                <div className="flex-1 h-5 waveform opacity-90" />
                                                <span className="text-[10px] opacity-70">0:30</span>
                                            </div>
                                        ) : (
                                            m.text
                                        )}
                                        <div className="text-[9px] opacity-60 mt-1 text-right">{new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
                                    </div>
                                </motion.div>
                            );
                        })
                    )}
                    {typingFromOther && (
                        <motion.div data-testid="typing-indicator" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                            <div className="glass px-4 py-2.5 rounded-2xl rounded-bl-sm flex items-center gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#FF2A85] animate-bounce" style={{ animationDelay: "0ms" }} />
                                <span className="w-1.5 h-1.5 rounded-full bg-[#FF2A85] animate-bounce" style={{ animationDelay: "150ms" }} />
                                <span className="w-1.5 h-1.5 rounded-full bg-[#FF2A85] animate-bounce" style={{ animationDelay: "300ms" }} />
                            </div>
                        </motion.div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* Composer */}
                <form onSubmit={sendMessage} className="flex items-center gap-2 p-3 border-t border-white/5">
                    <button
                        type="button"
                        data-testid="chat-voice-btn"
                        onClick={recording ? stopVoice : startVoice}
                        className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${recording ? "bg-[#FF2A85] text-white animate-pulse" : "glass hover:bg-white/10"}`}
                    >
                        {recording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </button>
                    <input
                        data-testid="chat-input"
                        value={text}
                        onChange={handleTyping}
                        placeholder="Type a message..."
                        className="input-dark flex-1"
                    />
                    <button type="submit" data-testid="chat-send-btn" className="w-10 h-10 rounded-full neon-gradient flex items-center justify-center disabled:opacity-50" disabled={!text.trim()}>
                        <Send className="w-4 h-4" />
                    </button>
                </form>
            </div>
        </AppShell>
    );
}
