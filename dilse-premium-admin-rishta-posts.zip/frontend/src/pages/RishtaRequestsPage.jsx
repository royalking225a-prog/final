import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import api, { fileUrl } from "@/lib/api";
import { Users, Check, X } from "lucide-react";
import { toast } from "sonner";

export default function RishtaRequestsPage() {
    const [data, setData] = useState({ incoming: [], outgoing: [] });
    const [tab, setTab] = useState("incoming");
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    const load = () => api.get("/rishta/requests").then(({ data }) => { setData(data); setLoading(false); });

    useEffect(() => { load(); }, []);

    const respond = async (id, status) => {
        try {
            await api.put(`/rishta/request/${id}?status=${status}`);
            toast.success(`Request ${status}`);
            await load();
        } catch (e) {
            toast.error("Failed");
        }
    };

    const list = data[tab] || [];

    return (
        <AppShell>
            <div className="max-w-3xl mx-auto">
                <div className="mb-6">
                    <h1 className="font-['Outfit'] text-3xl font-bold mb-1">Rishta Requests</h1>
                    <p className="text-sm text-zinc-400">Family-involved match requests</p>
                </div>
                <div className="glass rounded-full p-1 flex items-center mb-6 w-fit">
                    {["incoming", "outgoing"].map((t) => (
                        <button key={t} onClick={() => setTab(t)} data-testid={`rishta-tab-${t}`} className={`px-5 py-2 rounded-full text-xs font-semibold capitalize transition ${tab === t ? "neon-gradient text-white" : "text-zinc-400"}`}>
                            {t} ({data[t]?.length || 0})
                        </button>
                    ))}
                </div>
                {loading ? (
                    <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="h-24 glass rounded-2xl animate-pulse" />)}</div>
                ) : list.length === 0 ? (
                    <div className="glass rounded-3xl p-12 text-center">
                        <Users className="w-12 h-12 mx-auto mb-4 text-zinc-700" />
                        <h3 className="font-['Outfit'] text-xl font-bold mb-2">No {tab} requests</h3>
                        <p className="text-sm text-zinc-400">{tab === "incoming" ? "When someone sends a rishta request, it will appear here." : "Send rishta requests from profile pages."}</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {list.map((r) => (
                            <div key={r.id} data-testid={`rishta-card-${r.id}`} className="glass rounded-2xl p-4 flex items-center gap-4">
                                <Link to={`/profile/${r.user?.id}`}>
                                    {r.user?.photos?.[0]?.path ? (
                                        <img src={fileUrl(r.user.photos[0].path)} className="w-14 h-14 rounded-2xl object-cover" alt="" />
                                    ) : (
                                        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#FF2A85] to-[#8B5CF6] flex items-center justify-center font-bold">{r.user?.name?.[0]}</div>
                                    )}
                                </Link>
                                <div className="flex-1 min-w-0">
                                    <Link to={`/profile/${r.user?.id}`} className="font-bold hover:underline">{r.user?.name}</Link>
                                    <div className="text-xs text-zinc-400">{r.user?.age} • {r.user?.city}</div>
                                    {r.message && <div className="text-xs text-zinc-500 mt-1 line-clamp-1">"{r.message}"</div>}
                                </div>
                                {tab === "incoming" && r.status === "pending" ? (
                                    <div className="flex items-center gap-2">
                                        <button data-testid={`rishta-accept-${r.id}`} onClick={() => respond(r.id, "accepted")} className="w-9 h-9 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center hover:bg-emerald-500/30">
                                            <Check className="w-4 h-4 text-emerald-400" />
                                        </button>
                                        <button data-testid={`rishta-reject-${r.id}`} onClick={() => respond(r.id, "rejected")} className="w-9 h-9 rounded-full bg-red-500/20 border border-red-500/40 flex items-center justify-center hover:bg-red-500/30">
                                            <X className="w-4 h-4 text-red-400" />
                                        </button>
                                    </div>
                                ) : (
                                    <div className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
                                        r.status === "accepted" ? "bg-emerald-500/10 text-emerald-400" :
                                        r.status === "rejected" ? "bg-red-500/10 text-red-400" : "bg-amber-500/10 text-amber-400"
                                    }`}>{r.status}</div>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </AppShell>
    );
}
