import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import AppShell from "@/components/AppShell";
import api, { fileUrl } from "@/lib/api";
import { motion } from "framer-motion";
import { MessageCircle, Heart } from "lucide-react";

export default function ChatListPage() {
    const [matches, setMatches] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        api.get("/matches").then(({ data }) => {
            setMatches(data.matches || []);
            setLoading(false);
        });
    }, []);

    return (
        <AppShell>
            <div className="max-w-3xl mx-auto">
                <div className="mb-6">
                    <h1 className="font-['Outfit'] text-3xl font-bold">Messages</h1>
                    <p className="text-sm text-zinc-400 mt-1">Your matches and conversations</p>
                </div>

                {loading ? (
                    <div className="space-y-2">{[...Array(5)].map((_, i) => <div key={i} className="h-20 glass rounded-2xl animate-pulse" />)}</div>
                ) : matches.length === 0 ? (
                    <div data-testid="no-matches" className="glass rounded-3xl p-12 text-center">
                        <MessageCircle className="w-12 h-12 mx-auto mb-4 text-zinc-700" />
                        <h3 className="font-['Outfit'] text-xl font-bold mb-2">No matches yet</h3>
                        <p className="text-sm text-zinc-400 mb-5">Start swiping to find your match</p>
                        <Link to="/discover" className="btn-primary text-sm">Start Discovering</Link>
                    </div>
                ) : (
                    <div className="space-y-2">
                        {matches.map((m, i) => (
                            <motion.div key={m.match_id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
                                <Link
                                    to={`/messages/${m.match_id}`}
                                    data-testid={`chat-row-${m.match_id}`}
                                    className="flex items-center gap-4 p-4 rounded-2xl glass hover:bg-white/10 transition-all group"
                                >
                                    <div className="relative">
                                        {m.user.photos?.[0]?.path ? (
                                            <img src={fileUrl(m.user.photos[0].path)} className="w-14 h-14 rounded-2xl object-cover" alt="" />
                                        ) : (
                                            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#FF2A85] to-[#8B5CF6] flex items-center justify-center text-xl font-bold">{m.user.name?.[0]}</div>
                                        )}
                                        {m.user.online && <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-[#09090b]" />}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-1.5">
                                            <span className="font-bold">{m.user.name}</span>
                                            {m.user.verified && <Heart className="w-3 h-3 text-[#FF2A85]" fill="#FF2A85" />}
                                        </div>
                                        <div className="text-xs text-zinc-400 truncate">{m.last_message || "Start the conversation..."}</div>
                                    </div>
                                </Link>
                            </motion.div>
                        ))}
                    </div>
                )}
            </div>
        </AppShell>
    );
}
