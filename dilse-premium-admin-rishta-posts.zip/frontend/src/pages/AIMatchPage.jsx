import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import AppShell from "@/components/AppShell";
import api, { fileUrl } from "@/lib/api";
import { motion } from "framer-motion";
import { Sparkles, Heart, MessageCircle, Shield, Mic, ChevronRight } from "lucide-react";
import { toast } from "sonner";

export default function AIMatchPage() {
    const [recommendations, setRecommendations] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selected, setSelected] = useState(null);
    const [insight, setInsight] = useState(null);
    const [loadingInsight, setLoadingInsight] = useState(false);

    useEffect(() => {
        api.get("/ai/recommendations").then(({ data }) => {
            setRecommendations(data.recommendations || []);
            setLoading(false);
        }).catch(() => setLoading(false));
    }, []);

    const handleCompatibility = async (profile) => {
        setSelected(profile);
        setLoadingInsight(true);
        try {
            const { data } = await api.post("/ai/compatibility", { target_user_id: profile.id });
            setInsight(data);
        } catch (e) {
            toast.error("Failed to get insight");
        } finally {
            setLoadingInsight(false);
        }
    };

    return (
        <AppShell>
            <div className="max-w-6xl mx-auto">
                <div className="mb-8">
                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass-pink mb-3">
                        <Sparkles className="w-3.5 h-3.5 text-[#FF2A85]" />
                        <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-[#FF2A85]">AI Matchmaker</span>
                    </div>
                    <h1 className="font-['Outfit'] text-4xl font-bold mb-2">Your <span className="text-neon-gradient">Smart Matches</span></h1>
                    <p className="text-sm text-zinc-400">Profiles ranked by AI compatibility scoring across interests, lifestyle, education & personality.</p>
                </div>

                {loading ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                        {[...Array(6)].map((_, i) => <div key={i} className="h-96 glass rounded-3xl animate-pulse" />)}
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                        {recommendations.map((r, i) => (
                            <motion.div
                                key={r.profile.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.05 }}
                                className="glass rounded-3xl overflow-hidden group hover:-translate-y-1 transition-all duration-300"
                            >
                                <div className="relative aspect-[4/5]">
                                    {r.profile.photos?.[0]?.path ? (
                                        <img src={fileUrl(r.profile.photos[0].path)} alt={r.profile.name} className="absolute inset-0 w-full h-full object-cover" />
                                    ) : (
                                        <div className="absolute inset-0 bg-gradient-to-br from-[#FF2A85]/30 to-[#8B5CF6]/30 flex items-center justify-center text-7xl font-bold">
                                            {r.profile.name?.[0]?.toUpperCase()}
                                        </div>
                                    )}
                                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
                                    <div className="absolute top-3 right-3 px-3 py-1.5 rounded-full neon-gradient text-white text-xs font-bold">
                                        {r.compatibility.overall}% Match
                                    </div>
                                    <div className="absolute bottom-0 left-0 right-0 p-5">
                                        <div className="flex items-center gap-2 mb-1">
                                            <h3 className="text-xl font-bold">{r.profile.name}, {r.profile.age}</h3>
                                            {r.profile.verified && <Shield className="w-4 h-4 text-[#FF2A85]" fill="#FF2A85" />}
                                        </div>
                                        <div className="text-xs text-zinc-400 mb-3">{r.profile.profession} • {r.profile.city}</div>
                                        <div className="grid grid-cols-3 gap-1.5 mb-3">
                                            {Object.entries(r.compatibility.breakdown).slice(0, 3).map(([k, v]) => (
                                                <div key={k} className="text-center">
                                                    <div className="text-xs font-bold text-[#FF2A85]">{v}%</div>
                                                    <div className="text-[9px] text-zinc-500 capitalize">{k}</div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <div className="p-4 flex items-center gap-2">
                                    <button
                                        data-testid={`ai-insight-${r.profile.id}`}
                                        onClick={() => handleCompatibility(r.profile)}
                                        className="flex-1 btn-primary text-xs py-2.5 inline-flex items-center justify-center gap-1.5"
                                    >
                                        <Sparkles className="w-3.5 h-3.5" /> AI Insight
                                    </button>
                                    <Link to={`/profile/${r.profile.id}`} data-testid={`ai-view-${r.profile.id}`} className="btn-ghost text-xs py-2.5 px-4">
                                        View
                                    </Link>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                )}

                {/* Insight Modal */}
                {selected && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        onClick={() => { setSelected(null); setInsight(null); }}
                        className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
                    >
                        <motion.div
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            onClick={(e) => e.stopPropagation()}
                            data-testid="ai-insight-modal"
                            className="glass-strong rounded-3xl p-8 max-w-lg w-full"
                        >
                            <div className="flex items-center gap-4 mb-6">
                                {selected.photos?.[0]?.path ? (
                                    <img src={fileUrl(selected.photos[0].path)} className="w-16 h-16 rounded-2xl object-cover" alt="" />
                                ) : (
                                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF2A85] to-[#8B5CF6] flex items-center justify-center text-2xl font-bold">{selected.name?.[0]}</div>
                                )}
                                <div>
                                    <h3 className="font-['Outfit'] text-2xl font-bold">{selected.name}</h3>
                                    <div className="text-xs text-zinc-500">{selected.profession} • {selected.city}</div>
                                </div>
                            </div>
                            {loadingInsight ? (
                                <div className="text-center py-8">
                                    <div className="w-10 h-10 mx-auto rounded-full border-2 border-[#FF2A85] border-t-transparent animate-spin mb-3" />
                                    <p className="text-sm text-zinc-400">Analyzing compatibility...</p>
                                </div>
                            ) : insight && (
                                <>
                                    <div className="text-center mb-6">
                                        <div className="text-5xl font-bold text-neon-gradient mb-1">{insight.compatibility.overall}%</div>
                                        <div className="text-xs uppercase tracking-[0.2em] text-zinc-500">Overall Compatibility</div>
                                    </div>
                                    <div className="grid grid-cols-5 gap-2 mb-6">
                                        {Object.entries(insight.compatibility.breakdown).map(([k, v]) => (
                                            <div key={k} className="text-center">
                                                <div className="text-base font-bold text-[#FF2A85]">{v}%</div>
                                                <div className="text-[9px] text-zinc-500 capitalize">{k}</div>
                                            </div>
                                        ))}
                                    </div>
                                    <div className="glass-pink rounded-2xl p-4 mb-6">
                                        <div className="flex items-center gap-2 mb-2">
                                            <Sparkles className="w-4 h-4 text-[#FF2A85]" />
                                            <span className="text-xs uppercase tracking-[0.15em] font-bold text-[#FF2A85]">AI Insight</span>
                                        </div>
                                        <p className="text-sm text-zinc-200 leading-relaxed">{insight.insight}</p>
                                    </div>
                                    <Link to={`/profile/${selected.id}`} data-testid="ai-view-full-profile" className="block text-center btn-primary text-sm">
                                        View Full Profile
                                    </Link>
                                </>
                            )}
                        </motion.div>
                    </motion.div>
                )}
            </div>
        </AppShell>
    );
}
