// NEW FILE: frontend/src/pages/AdminHeroTab.jsx
// Drop-in tab component for AdminPage.jsx — keeps your dark premium UI.

import { useEffect, useRef, useState } from "react";
import api, { fileUrl } from "@/lib/api";
import { toast } from "sonner";
import { Plus, Trash2, Upload, Eye, EyeOff, Save, ArrowUp, ArrowDown, Image as ImageIcon } from "lucide-react";

const EMPTY = {
    badge: "",
    heading: "",
    description: "",
    cta_label: "Get Started",
    cta_url: "/register",
    image_url: "",
    image_path: "",
    order: 0,
    enabled: true,
};

export default function AdminHeroTab() {
    const [slides, setSlides] = useState([]);
    const [editing, setEditing] = useState(null); // slide being edited or null
    const [form, setForm] = useState(EMPTY);
    const [preview, setPreview] = useState(false);
    const [busy, setBusy] = useState(false);
    const fileRef = useRef();

    const load = async () => {
        try {
            const { data } = await api.get("/admin/hero/slides");
            setSlides(data.slides || []);
        } catch {
            toast.error("Failed to load slides");
        }
    };
    useEffect(() => { load(); }, []);

    const startNew = () => { setEditing("new"); setForm({ ...EMPTY, order: slides.length }); setPreview(false); };
    const startEdit = (s) => { setEditing(s.id); setForm({ ...EMPTY, ...s }); setPreview(false); };
    const cancel = () => { setEditing(null); setForm(EMPTY); setPreview(false); };

    const save = async () => {
        if (!form.heading.trim()) { toast.error("Heading is required"); return; }
        setBusy(true);
        try {
            if (editing === "new") {
                await api.post("/admin/hero/slides", form);
                toast.success("Slide created");
            } else {
                await api.put(`/admin/hero/slides/${editing}`, form);
                toast.success("Slide updated");
            }
            await load(); cancel();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Save failed");
        } finally { setBusy(false); }
    };

    const remove = async (id) => {
        if (!confirm("Delete this slide?")) return;
        try { await api.delete(`/admin/hero/slides/${id}`); toast.success("Deleted"); await load(); }
        catch { toast.error("Delete failed"); }
    };

    const toggle = async (id) => {
        try { await api.post(`/admin/hero/slides/${id}/toggle`); await load(); }
        catch { toast.error("Toggle failed"); }
    };

    const move = async (idx, dir) => {
        const next = [...slides];
        const j = idx + dir;
        if (j < 0 || j >= next.length) return;
        [next[idx], next[j]] = [next[j], next[idx]];
        setSlides(next);
        try { await api.post("/admin/hero/slides/reorder", next.map((s) => s.id)); }
        catch { toast.error("Reorder failed"); load(); }
    };

    const uploadImage = async (e) => {
        const file = e.target.files?.[0]; if (!file) return;
        const fd = new FormData(); fd.append("file", file);
        try {
            const { data } = await api.post("/admin/hero/upload", fd, {
                headers: { "Content-Type": "multipart/form-data" },
            });
            setForm((f) => ({ ...f, image_url: data.image_url, image_path: data.image_path }));
            toast.success("Image uploaded");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Upload failed");
        }
    };

    const imgFor = (s) => (s.image_path ? fileUrl(s.image_path) : s.image_url);

    return (
        <div className="space-y-6" data-testid="admin-hero-tab">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="font-['Outfit'] text-xl font-bold">Hero Slider</h2>
                    <p className="text-xs text-zinc-500">Manage slides shown on the landing page hero section.</p>
                </div>
                {!editing && (
                    <button onClick={startNew} className="btn-primary text-sm py-2 px-4 inline-flex items-center gap-2">
                        <Plus className="w-4 h-4" /> New Slide
                    </button>
                )}
            </div>

            {/* Editor */}
            {editing && (
                <div className="glass-strong rounded-3xl p-6 space-y-4">
                    <div className="flex items-center justify-between">
                        <h3 className="font-bold text-sm">{editing === "new" ? "Create slide" : "Edit slide"}</h3>
                        <button onClick={() => setPreview((p) => !p)}
                                className="text-xs px-3 py-1.5 rounded-full glass inline-flex items-center gap-1.5">
                            {preview ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                            {preview ? "Hide preview" : "Preview"}
                        </button>
                    </div>

                    {preview ? (
                        <div className="grid lg:grid-cols-2 gap-6 rounded-2xl border border-white/5 p-5 bg-black/40">
                            <div>
                                {form.badge && (
                                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass-pink mb-4">
                                        <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-[#FF2A85]">{form.badge}</span>
                                    </div>
                                )}
                                <h1 className="font-['Outfit'] text-3xl lg:text-5xl font-bold leading-tight mb-3">{form.heading || "Heading"}</h1>
                                <p className="text-zinc-400 mb-5">{form.description}</p>
                                {form.cta_label && <span className="btn-primary inline-block">{form.cta_label}</span>}
                            </div>
                            <div className="aspect-[4/5] rounded-2xl overflow-hidden bg-zinc-900">
                                {imgFor(form) ? <img src={imgFor(form)} alt="" className="w-full h-full object-cover" /> :
                                    <div className="w-full h-full flex items-center justify-center text-zinc-600"><ImageIcon className="w-10 h-10" /></div>}
                            </div>
                        </div>
                    ) : (
                        <div className="grid lg:grid-cols-2 gap-4">
                            <Field label="Badge (small chip)">
                                <input className="input-dark" value={form.badge} onChange={(e) => setForm({ ...form, badge: e.target.value })} />
                            </Field>
                            <Field label="CTA Label">
                                <input className="input-dark" value={form.cta_label} onChange={(e) => setForm({ ...form, cta_label: e.target.value })} />
                            </Field>
                            <Field label="Heading" full>
                                <input className="input-dark" value={form.heading} onChange={(e) => setForm({ ...form, heading: e.target.value })} />
                            </Field>
                            <Field label="Description" full>
                                <textarea rows={3} className="input-dark" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                            </Field>
                            <Field label="CTA URL">
                                <input className="input-dark" value={form.cta_url} onChange={(e) => setForm({ ...form, cta_url: e.target.value })} placeholder="/register" />
                            </Field>
                            <Field label="Enabled">
                                <label className="flex items-center gap-2 text-sm mt-2">
                                    <input type="checkbox" checked={form.enabled} onChange={(e) => setForm({ ...form, enabled: e.target.checked })} />
                                    Show on landing page
                                </label>
                            </Field>
                            <Field label="Hero Image (right side)" full>
                                <div className="flex items-center gap-3">
                                    <div className="w-24 h-24 rounded-xl overflow-hidden bg-black border border-white/10 flex items-center justify-center">
                                        {imgFor(form) ? <img src={imgFor(form)} alt="" className="w-full h-full object-cover" /> :
                                            <ImageIcon className="w-6 h-6 text-zinc-600" />}
                                    </div>
                                    <input ref={fileRef} type="file" accept="image/*" hidden onChange={uploadImage} />
                                    <button onClick={() => fileRef.current?.click()} className="btn-ghost text-sm inline-flex items-center gap-2">
                                        <Upload className="w-4 h-4" /> Upload image
                                    </button>
                                    <input className="input-dark flex-1" placeholder="…or paste image URL"
                                           value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value, image_path: "" })} />
                                </div>
                            </Field>
                        </div>
                    )}

                    <div className="flex items-center gap-2 pt-2">
                        <button disabled={busy} onClick={save} className="btn-primary text-sm py-2 px-5 inline-flex items-center gap-2 disabled:opacity-50">
                            <Save className="w-4 h-4" /> {busy ? "Saving…" : "Save slide"}
                        </button>
                        <button onClick={cancel} className="btn-ghost text-sm">Cancel</button>
                    </div>
                </div>
            )}

            {/* List */}
            <div className="glass rounded-3xl overflow-hidden">
                {slides.length === 0 ? (
                    <div className="p-10 text-center text-zinc-500 text-sm">No slides yet. Click <b>New Slide</b> to add one.</div>
                ) : (
                    <div className="divide-y divide-white/5">
                        {slides.map((s, i) => (
                            <div key={s.id} className="flex items-center gap-4 p-4">
                                <div className="w-16 h-16 rounded-xl overflow-hidden bg-black border border-white/10 flex items-center justify-center shrink-0">
                                    {imgFor(s) ? <img src={imgFor(s)} alt="" className="w-full h-full object-cover" /> :
                                        <ImageIcon className="w-5 h-5 text-zinc-600" />}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="font-bold truncate">{s.heading}</div>
                                    <div className="text-xs text-zinc-500 truncate">{s.description}</div>
                                    <div className="text-[10px] mt-1">
                                        <span className={`px-2 py-0.5 rounded-full ${s.enabled ? "bg-emerald-500/15 text-emerald-400" : "bg-zinc-500/15 text-zinc-400"}`}>
                                            {s.enabled ? "Enabled" : "Disabled"}
                                        </span>
                                    </div>
                                </div>
                                <div className="flex items-center gap-1.5">
                                    <button onClick={() => move(i, -1)} disabled={i === 0} className="w-8 h-8 rounded-full glass disabled:opacity-30"><ArrowUp className="w-3.5 h-3.5 mx-auto" /></button>
                                    <button onClick={() => move(i, 1)} disabled={i === slides.length - 1} className="w-8 h-8 rounded-full glass disabled:opacity-30"><ArrowDown className="w-3.5 h-3.5 mx-auto" /></button>
                                    <button onClick={() => toggle(s.id)} className="w-8 h-8 rounded-full glass">{s.enabled ? <EyeOff className="w-3.5 h-3.5 mx-auto" /> : <Eye className="w-3.5 h-3.5 mx-auto" />}</button>
                                    <button onClick={() => startEdit(s)} className="px-3 py-1.5 rounded-full glass text-xs">Edit</button>
                                    <button onClick={() => remove(s.id)} className="w-8 h-8 rounded-full bg-red-500/15 text-red-400"><Trash2 className="w-3.5 h-3.5 mx-auto" /></button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

function Field({ label, children, full }) {
    return (
        <div className={full ? "lg:col-span-2" : ""}>
            <label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">{label}</label>
            {children}
        </div>
    );
}
