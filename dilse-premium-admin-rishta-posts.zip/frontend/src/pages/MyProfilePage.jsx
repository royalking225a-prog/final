import { useState, useRef } from "react";
import AppShell from "@/components/AppShell";
import { useAuth } from "@/context/AuthContext";
import api, { fileUrl } from "@/lib/api";
import { motion } from "framer-motion";
import { Camera, Mic, X, Save, Shield, Plus, MicOff, Play, Trash2 } from "lucide-react";
import { toast } from "sonner";

const INTEREST_OPTIONS = ["Travel", "Cooking", "Reading", "Sports", "Music", "Movies", "Art", "Tech", "Fitness", "Faith", "Family", "Photography", "Outdoors", "Food", "Fashion"];

export default function MyProfilePage() {
    const { user, refreshUser } = useAuth();
    const [form, setForm] = useState({
        name: user?.name || "",
        age: user?.age || 25,
        gender: user?.gender || "male",
        city: user?.city || "",
        country: user?.country || "",
        profession: user?.profession || "",
        education: user?.education || "",
        religion: user?.religion || "",
        sect: user?.sect || "",
        height: user?.height || "",
        marital_status: user?.marital_status || "Single",
        bio: user?.bio || "",
        interests: user?.interests || [],
        mode: user?.mode || "dating",
        looking_for: user?.looking_for || "both",
        wali_required: user?.wali_required || false,
        invisible_browsing: user?.invisible_browsing || false,
    });
    const [saving, setSaving] = useState(false);
    const [recording, setRecording] = useState(false);
    const photoRef = useRef();
    const mediaRecorderRef = useRef(null);
    const audioChunksRef = useRef([]);

    const toggleInterest = (interest) => {
        if (form.interests.includes(interest)) {
            setForm({ ...form, interests: form.interests.filter((i) => i !== interest) });
        } else if (form.interests.length < 8) {
            setForm({ ...form, interests: [...form.interests, interest] });
        }
    };

    const handleSave = async () => {
        setSaving(true);
        try {
            await api.put("/profile", form);
            await refreshUser();
            toast.success("Profile updated!");
        } catch (e) {
            toast.error("Failed to save");
        } finally {
            setSaving(false);
        }
    };

    const handlePhotoUpload = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const fd = new FormData();
        fd.append("file", file);
        try {
            await api.post("/upload/photo", fd, { headers: { "Content-Type": "multipart/form-data" } });
            await refreshUser();
            toast.success("Photo uploaded");
        } catch (e) {
            toast.error("Upload failed");
        }
    };

    const deletePhoto = async (id) => {
        try {
            await api.delete(`/upload/photo/${id}`);
            await refreshUser();
            toast.success("Photo removed");
        } catch (e) {}
    };

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const recorder = new MediaRecorder(stream);
            audioChunksRef.current = [];
            recorder.ondataavailable = (e) => audioChunksRef.current.push(e.data);
            recorder.onstop = async () => {
                const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
                const fd = new FormData();
                fd.append("file", blob, "voice-intro.webm");
                try {
                    await api.post("/upload/voice", fd, { headers: { "Content-Type": "multipart/form-data" } });
                    await refreshUser();
                    toast.success("Voice intro saved!");
                } catch {
                    toast.error("Upload failed");
                }
                stream.getTracks().forEach((t) => t.stop());
            };
            recorder.start();
            mediaRecorderRef.current = recorder;
            setRecording(true);
            setTimeout(() => { if (mediaRecorderRef.current?.state === "recording") stopRecording(); }, 30000);
        } catch (e) {
            toast.error("Microphone access denied");
        }
    };

    const stopRecording = () => {
        mediaRecorderRef.current?.stop();
        setRecording(false);
    };

    return (
        <AppShell>
            <div className="max-w-4xl mx-auto">
                <div className="flex items-center justify-between mb-6">
                    <div>
                        <h1 className="font-['Outfit'] text-3xl font-bold">My Profile</h1>
                        <p className="text-sm text-zinc-400 mt-1">Manage your information & photos</p>
                    </div>
                    <button data-testid="profile-save-btn" onClick={handleSave} disabled={saving} className="btn-primary text-sm inline-flex items-center gap-2 disabled:opacity-50">
                        <Save className="w-4 h-4" /> {saving ? "Saving..." : "Save"}
                    </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Photos */}
                    <div className="glass rounded-3xl p-6">
                        <h2 className="font-['Outfit'] font-bold mb-4">Photos</h2>
                        <div className="grid grid-cols-3 gap-2">
                            {(user?.photos || []).map((photo) => (
                                <div key={photo.id} className="relative aspect-square rounded-2xl overflow-hidden group">
                                    <img src={fileUrl(photo.path)} className="w-full h-full object-cover" alt="" />
                                    <button data-testid={`delete-photo-${photo.id}`} onClick={() => deletePhoto(photo.id)} className="absolute top-1.5 right-1.5 w-7 h-7 rounded-full bg-black/70 backdrop-blur-md flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                                        <X className="w-3.5 h-3.5" />
                                    </button>
                                </div>
                            ))}
                            {(user?.photos?.length || 0) < 6 && (
                                <button data-testid="upload-photo-btn" onClick={() => photoRef.current?.click()} className="aspect-square rounded-2xl border-2 border-dashed border-white/10 hover:border-[#FF2A85]/50 flex items-center justify-center text-zinc-500 hover:text-[#FF2A85] transition-all">
                                    <Plus className="w-6 h-6" />
                                </button>
                            )}
                        </div>
                        <input ref={photoRef} type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />

                        {/* Voice Intro */}
                        <div className="mt-6">
                            <h2 className="font-['Outfit'] font-bold mb-3">Voice Intro</h2>
                            {user?.voice_intro ? (
                                <div className="glass-pink rounded-2xl p-4 flex items-center gap-3">
                                    <button className="w-10 h-10 rounded-full neon-gradient flex items-center justify-center">
                                        <Play className="w-4 h-4 text-white ml-0.5" fill="white" />
                                    </button>
                                    <div className="flex-1 h-6 waveform" />
                                </div>
                            ) : (
                                <button
                                    data-testid="voice-record-btn"
                                    onClick={recording ? stopRecording : startRecording}
                                    className={`w-full rounded-2xl border-2 border-dashed py-6 flex flex-col items-center gap-2 transition-all ${recording ? "border-[#FF2A85] bg-[#FF2A85]/10 text-[#FF2A85] animate-pulse" : "border-white/10 hover:border-[#FF2A85]/50 text-zinc-400"}`}
                                >
                                    {recording ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                                    <span className="text-xs font-semibold">{recording ? "Stop recording" : "Record 30s intro"}</span>
                                </button>
                            )}
                        </div>
                    </div>

                    {/* Info */}
                    <div className="lg:col-span-2 space-y-6">
                        <div className="glass rounded-3xl p-6 space-y-4">
                            <h2 className="font-['Outfit'] font-bold">Basic Info</h2>
                            <div className="grid grid-cols-2 gap-3">
                                <Field label="Name"><input data-testid="profile-name-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-dark" /></Field>
                                <Field label="Age"><input data-testid="profile-age-input" type="number" min="18" max="99" value={form.age} onChange={(e) => setForm({ ...form, age: parseInt(e.target.value) || 18 })} className="input-dark" /></Field>
                                <Field label="City"><input data-testid="profile-city-input" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="input-dark" /></Field>
                                <Field label="Country"><input data-testid="profile-country-input" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} className="input-dark" /></Field>
                                <Field label="Profession"><input data-testid="profile-profession-input" value={form.profession} onChange={(e) => setForm({ ...form, profession: e.target.value })} className="input-dark" /></Field>
                                <Field label="Education"><input data-testid="profile-education-input" value={form.education} onChange={(e) => setForm({ ...form, education: e.target.value })} className="input-dark" /></Field>
                                <Field label="Religion"><input data-testid="profile-religion-input" value={form.religion} onChange={(e) => setForm({ ...form, religion: e.target.value })} className="input-dark" /></Field>
                                <Field label="Marital Status">
                                    <select value={form.marital_status} onChange={(e) => setForm({ ...form, marital_status: e.target.value })} className="input-dark">
                                        <option>Single</option><option>Divorced</option><option>Widowed</option>
                                    </select>
                                </Field>
                            </div>
                            <Field label="Bio">
                                <textarea data-testid="profile-bio-input" rows={3} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} className="input-dark" placeholder="Tell us about yourself..." />
                            </Field>
                        </div>

                        <div className="glass rounded-3xl p-6">
                            <h2 className="font-['Outfit'] font-bold mb-3">Interests</h2>
                            <p className="text-xs text-zinc-500 mb-3">Pick up to 8 ({form.interests.length}/8)</p>
                            <div className="flex flex-wrap gap-2">
                                {INTEREST_OPTIONS.map((int) => (
                                    <button
                                        key={int}
                                        data-testid={`interest-${int}`}
                                        onClick={() => toggleInterest(int)}
                                        className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${form.interests.includes(int) ? "neon-gradient text-white" : "glass text-zinc-400 hover:text-white"}`}
                                    >
                                        {int}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="glass rounded-3xl p-6">
                            <h2 className="font-['Outfit'] font-bold mb-4">Preferences</h2>
                            <div className="space-y-4">
                                <Field label="Looking for">
                                    <div className="flex gap-2">
                                        {["dating", "rishta", "both"].map((opt) => (
                                            <button key={opt} onClick={() => setForm({ ...form, looking_for: opt })} className={`flex-1 py-2.5 rounded-xl text-xs font-semibold transition-all capitalize ${form.looking_for === opt ? "neon-gradient text-white" : "glass text-zinc-400"}`}>{opt}</button>
                                        ))}
                                    </div>
                                </Field>
                                <Field label="Mode">
                                    <div className="flex gap-2">
                                        {["dating", "rishta"].map((opt) => (
                                            <button key={opt} onClick={() => setForm({ ...form, mode: opt })} className={`flex-1 py-2.5 rounded-xl text-xs font-semibold transition-all capitalize ${form.mode === opt ? "neon-gradient text-white" : "glass text-zinc-400"}`}>{opt}</button>
                                        ))}
                                    </div>
                                </Field>
                                <ToggleField label="Wali approval required" desc="For traditional rishta proceedings" value={form.wali_required} onChange={(v) => setForm({ ...form, wali_required: v })} />
                                <ToggleField label="Invisible browsing (Premium)" desc="Browse profiles without showing in visitors" value={form.invisible_browsing} onChange={(v) => setForm({ ...form, invisible_browsing: v })} disabled={!user?.premium} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AppShell>
    );
}

function Field({ label, children }) {
    return (
        <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-[0.15em] font-bold text-zinc-500">{label}</label>
            {children}
        </div>
    );
}

function ToggleField({ label, desc, value, onChange, disabled }) {
    return (
        <div className={`flex items-center justify-between gap-4 ${disabled ? "opacity-50" : ""}`}>
            <div>
                <div className="text-sm font-medium">{label}</div>
                <div className="text-xs text-zinc-500">{desc}</div>
            </div>
            <button
                disabled={disabled}
                data-testid={`toggle-${label.toLowerCase().replace(/\s/g, "-")}`}
                onClick={() => onChange(!value)}
                className={`w-12 h-6 rounded-full p-0.5 transition-colors ${value ? "neon-gradient" : "bg-white/10"}`}
            >
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${value ? "translate-x-6" : ""}`} />
            </button>
        </div>
    );
}
