import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, User, Calendar, Eye, EyeOff } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { formatErrorDetail } from "@/lib/api";
import { motion } from "framer-motion";
import { toast } from "sonner";
import BrandLogo from "@/components/BrandLogo";

export default function RegisterPage() {
    const { register } = useAuth();
    const navigate = useNavigate();
    const [form, setForm] = useState({ email: "", password: "", name: "", age: 25, gender: "male" });
    const [showPwd, setShowPwd] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            const user = await register({ ...form, age: parseInt(form.age) });
            toast.success(`Welcome, ${user.name}!`);
            navigate("/profile/me");
        } catch (e) {
            toast.error(formatErrorDetail(e.response?.data?.detail) || "Registration failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-[#09090b] text-white px-4 py-12 relative overflow-hidden">
            <div className="fixed inset-0 pointer-events-none">
                <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-[#FF2A85]/15 rounded-full blur-[120px]" />
                <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-[#8B5CF6]/15 rounded-full blur-[120px]" />
            </div>

            <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="relative z-10 w-full max-w-md"
            >
                <Link to="/" data-testid="register-logo" className="flex justify-center mb-8">
                    <BrandLogo size="md" />
                </Link>

                <div className="glass-strong rounded-3xl p-8 shadow-2xl">
                    <h1 className="font-['Outfit'] text-3xl font-bold mb-2">Create account</h1>
                    <p className="text-sm text-zinc-400 mb-6">Start your journey to find love</p>

                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="relative">
                            <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                            <input data-testid="register-name-input" required placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-dark pl-11" />
                        </div>
                        <div className="relative">
                            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                            <input data-testid="register-email-input" type="email" required placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input-dark pl-11" />
                        </div>
                        <div className="relative">
                            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                            <input data-testid="register-password-input" type={showPwd ? "text" : "password"} required minLength={6} placeholder="Password (min 6 chars)" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className="input-dark pl-11 pr-11" />
                            <button type="button" onClick={() => setShowPwd(!showPwd)} className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white">
                                {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            <div className="relative">
                                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                                <input data-testid="register-age-input" type="number" required min={18} max={99} placeholder="Age" value={form.age} onChange={(e) => setForm({ ...form, age: e.target.value })} className="input-dark pl-11" />
                            </div>
                            <select data-testid="register-gender-select" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })} className="input-dark">
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <p className="text-[10px] text-zinc-500 leading-relaxed">By signing up, you agree to our Terms of Service and Privacy Policy. You must be 18+ to use DilSe.</p>
                        <button data-testid="register-submit-btn" type="submit" disabled={loading} className="w-full btn-primary disabled:opacity-50">
                            {loading ? "Creating account..." : "Create Account"}
                        </button>
                    </form>

                    <div className="text-center mt-6 text-sm text-zinc-500">
                        Already have an account?{" "}
                        <Link to="/login" data-testid="register-login-link" className="text-[#FF2A85] font-semibold hover:underline">Sign in</Link>
                    </div>
                </div>
            </motion.div>
        </div>
    );
}
