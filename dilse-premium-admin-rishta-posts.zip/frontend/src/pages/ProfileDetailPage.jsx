import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import AppShell from "@/components/AppShell";
import api, { fileUrl } from "@/lib/api";
import { motion } from "framer-motion";
import { Heart, MessageCircle, Shield, Mic, MapPin, Briefcase, GraduationCap, Users, Sparkles, ArrowLeft, Play } from "lucide-react";
import { toast } from "sonner";

export default function ProfileDetailPage() {
    const { userId } = useParams();
    const navigate = useNavigate();
    const [profile, setProfile] = useState(null);
    const [loading, setLoading] = useState(true);
    const [photoIndex, setPhotoIndex] = useState(0);

    useEffect(() => {
        api.get(`/profile/${userId}`).then(({ data }) => {
            setProfile(data);
            setLoading(false);
        }).catch(() => {
            toast.error("Profile not found");
            navigate("/discover");
        });
    }, [userId, navigate]);

    const handleLike = async () => {
        try {
            const { data } = await api.post("/swipe", { target_user_id: userId, action: "like" });
            if (data.is_match) {
                toast.success(`It's a match! 💖`);
                navigate(`/messages/${data.match_id}`);
            } else {
                toast.success("Liked!");
            }
        } catch (e) {
            toast.error(e.response?.data?.detail || "Failed");
        }
    };

    const handleRishtaRequest = async () => {
        try {
            await api.post("/rishta/request", { target_user_id: userId, message: "Salaam, I'd like to know you better through proper channels." });
            toast.success("Rishta request sent!");
        } catch (e) {
            toast.error(e.response?.data?.detail || "Failed");
        }
    };

    const handleMessage = async () => {
        if (profile.match_id) {
            navigate(`/messages/${profile.match_id}`);
        } else {
            toast.info("You need to match first to chat");
        }
    };

    if (loading) {
        return <AppShell><div className="max-w-4xl mx-auto h-96 glass rounded-3xl animate-pulse" /></AppShell>;
    }
    if (!profile) return null;

    const photos = profile.photos || [];
    const activePhoto = photos[photoIndex];

    return (
        <AppShell>
            <div className="max-w-5xl mx-auto">
                <button data-testid="profile-back-btn" onClick={() => navigate(-1)} className="flex items-center gap-2 text-zinc-400 hover:text-white mb-6">
                    <ArrowLeft className="w-4 h-4" /> Back
                </button>

                <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                    {/* Photos */}
                    <div className="lg:col-span-3">
                        <div className="aspect-[4/5] rounded-3xl overflow-hidden glass relative">
                            {activePhoto?.path ? (
                                <img src={fileUrl(activePhoto.path)} alt={profile.name} className="absolute inset-0 w-full h-full object-cover" />
                            ) : (
                                <div className="absolute inset-0 bg-gradient-to-br from-[#FF2A85]/30 to-[#8B5CF6]/30 flex items-center justify-center text-8xl font-bold">
                                    {profile.name?.[0]?.toUpperCase()}
                                </div>
                            )}
                            {photos.length > 1 && (
                                <div className="absolute top-3 left-3 right-3 flex gap-1">
                                    {photos.map((_, i) => (
                                        <button
                                            key={i}
                                            onClick={() => setPhotoIndex(i)}
                                            className={`flex-1 h-1 rounded-full transition-colors ${i === photoIndex ? "bg-white" : "bg-white/30"}`}
                                        />
                                    ))}
                                </div>
                            )}
                        </div>
                        {photos.length > 1 && (
                            <div className="flex gap-2 mt-3 overflow-x-auto">
                                {photos.map((p, i) => (
                                    <button key={i} onClick={() => setPhotoIndex(i)} data-testid={`photo-thumb-${i}`} className={`flex-shrink-0 w-20 h-20 rounded-xl overflow-hidden border-2 ${i === photoIndex ? "border-[#FF2A85]" : "border-transparent"}`}>
                                        <img src={fileUrl(p.path)} alt="" className="w-full h-full object-cover" />
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Info */}
                    <div className="lg:col-span-2 space-y-5">
                        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="glass rounded-3xl p-6">
                            <div className="flex items-start justify-between mb-2">
                                <div>
                                    <div className="flex items-center gap-2 mb-1">
                                        <h1 className="font-['Outfit'] text-3xl font-bold">{profile.name}, {profile.age}</h1>
                                        {profile.verified && <Shield className="w-5 h-5 text-[#FF2A85]" fill="#FF2A85" />}
                                    </div>
                                    {profile.online && (
                                        <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold">
                                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                                            ONLINE
                                        </div>
                                    )}
                                </div>
                                {profile.premium && (
                                    <span className="text-[10px] px-2 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 font-bold">PREMIUM</span>
                                )}
                            </div>
                            <div className="space-y-2.5 text-sm text-zinc-300 mt-4">
                                {profile.city && <div className="flex items-center gap-2"><MapPin className="w-4 h-4 text-zinc-500" /> {profile.city}{profile.country ? `, ${profile.country}` : ""}</div>}
                                {profile.profession && <div className="flex items-center gap-2"><Briefcase className="w-4 h-4 text-zinc-500" /> {profile.profession}</div>}
                                {profile.education && <div className="flex items-center gap-2"><GraduationCap className="w-4 h-4 text-zinc-500" /> {profile.education}</div>}
                                {profile.religion && <div className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-zinc-500" /> {profile.religion}{profile.sect ? ` (${profile.sect})` : ""}</div>}
                            </div>
                            {profile.bio && (
                                <div className="mt-4 pt-4 border-t border-white/5">
                                    <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-2 font-bold">About</div>
                                    <p className="text-sm text-zinc-300 leading-relaxed">{profile.bio}</p>
                                </div>
                            )}
                            {profile.interests?.length > 0 && (
                                <div className="mt-4 pt-4 border-t border-white/5">
                                    <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-2 font-bold">Interests</div>
                                    <div className="flex flex-wrap gap-1.5">
                                        {profile.interests.map((int, i) => (
                                            <span key={i} className="text-xs px-3 py-1 rounded-full glass-pink text-[#FF2A85]">{int}</span>
                                        ))}
                                    </div>
                                </div>
                            )}
                            {profile.voice_intro && (
                                <div className="mt-4 pt-4 border-t border-white/5">
                                    <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-2 font-bold">Voice Intro</div>
                                    <div className="flex items-center gap-3 glass-pink rounded-2xl p-3">
                                        <button className="w-10 h-10 rounded-full neon-gradient flex items-center justify-center">
                                            <Play className="w-4 h-4 text-white ml-0.5" fill="white" />
                                        </button>
                                        <div className="flex-1 h-6 waveform" />
                                        <span className="text-xs text-zinc-400">0:30</span>
                                    </div>
                                </div>
                            )}
                            {profile.wali_required && (
                                <div className="mt-4 pt-4 border-t border-white/5">
                                    <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold">
                                        <Shield className="w-3.5 h-3.5" /> Wali Approval Required
                                    </div>
                                </div>
                            )}
                        </motion.div>

                        {/* AI Compatibility */}
                        <Link to="/ai-match" data-testid="profile-ai-match-link" className="block glass-pink rounded-3xl p-5 hover:shadow-lg hover:shadow-pink-500/20 transition-all">
                            <div className="flex items-center gap-3">
                                <Sparkles className="w-6 h-6 text-[#FF2A85]" />
                                <div className="flex-1">
                                    <div className="font-bold">AI Compatibility</div>
                                    <div className="text-xs text-zinc-400">Check your match score with AI insights</div>
                                </div>
                                <ChevronRightIcon />
                            </div>
                        </Link>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-2">
                            <button data-testid="profile-like-btn" onClick={handleLike} className="flex-1 btn-primary flex items-center justify-center gap-2 text-sm">
                                <Heart className="w-4 h-4" fill="white" /> Like
                            </button>
                            {profile.is_matched ? (
                                <button data-testid="profile-message-btn" onClick={handleMessage} className="flex-1 btn-ghost flex items-center justify-center gap-2 text-sm">
                                    <MessageCircle className="w-4 h-4" /> Message
                                </button>
                            ) : (
                                <button data-testid="profile-rishta-btn" onClick={handleRishtaRequest} className="flex-1 btn-ghost flex items-center justify-center gap-2 text-sm">
                                    <Users className="w-4 h-4" /> Rishta
                                </button>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </AppShell>
    );
}

function ChevronRightIcon() {
    return <svg className="w-4 h-4 text-zinc-500" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>;
}
