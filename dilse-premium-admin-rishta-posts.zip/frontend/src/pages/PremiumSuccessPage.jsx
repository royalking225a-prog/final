import { Link } from "react-router-dom";
import AppShell from "@/components/AppShell";
import { Crown } from "lucide-react";

export default function PremiumSuccessPage() {
    return (
        <AppShell>
            <div className="max-w-lg mx-auto text-center py-16">
                <div className="w-20 h-20 mx-auto rounded-full neon-gradient flex items-center justify-center mb-6 glow-pink">
                    <Crown className="w-10 h-10 text-white" />
                </div>
                <h1 className="font-['Outfit'] text-3xl font-bold mb-3">Payment Submitted!</h1>
                <p className="text-zinc-400 mb-8">Admin will verify your payment within 24 hours. You'll receive an email when your Premium is activated.</p>
                <Link to="/dashboard" className="btn-primary">Back to Dashboard</Link>
            </div>
        </AppShell>
    );
}
