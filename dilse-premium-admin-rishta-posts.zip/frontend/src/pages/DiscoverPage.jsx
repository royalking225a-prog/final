import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "@/components/AppShell";
import api, { fileUrl } from "@/lib/api";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, X, Star, Mic, Shield, MapPin, Briefcase, GraduationCap, Sparkles, Filter } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";

export default function DiscoverPage() {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [profiles, setProfiles] = useState([]);
    const [index, setIndex] = useState(0);
    const [loading, setLoading] = useState(true);
    const [mode, setMode] = useState(user?.mode || "dating");
    const [showFilters, setShowFilters] = useState(false);
    const [filters, setFilters] = useState({ min_age: 18, max_age: 60, city: "", religion: "" });

    const loadProfiles = async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            params.set("mode", mode);
            params.set("min_age", filters.min_age);
            params.set("max_age", filters.max_age);
            if (filters.city) params.set("city", filters.city);
            if (filters.religion) params.set("religion", filters.religion);
            const { data } = await api.get(`/discover?${params}`);
            setProfiles(data.profiles || []);
            setIndex(0);
        } catch (e) {
            toast.error("Failed to load profiles");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadProfiles();
        // eslint-disable-next-line
    }, [mode]);

    const current = profiles[index];

    const handleSwipe = async (action) => {
        if (!current) return;
        try {
            const { data } = await api.post("/swipe", { target_user_id: current.id, action });
            if (data.is_match) {
                toast.success(`It's a match with ${current.name}! 💖`, { duration: 4000 });
            }
            setIndex(index + 1);
        } catch (e) {
            const msg = e.response?.data?.detail || "Action failed";
            toast.error(msg);
            if (msg.includes("limit")) {
                navigate("/premium");
            }
        }
    };

    return (
        <AppShell>
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                    <div>
                        <h1 className="font-['Outfit'] text-3xl font-bold mb-1">Discover</h1>
                        <p className="text-sm text-zinc-400">Swipe right to like, left to pass</p>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="glass rounded-full p-1 flex items-center">
                            <button
                                data-testid="mode-dating"
                                onClick={() => setMode("dating")}
                                className={`px-4 py-2 rounded-full text-xs font-semibold transition-all ${mode === "dating" ? "neon-gradient text-white" : "text-zinc-400"}`}
                            >
                                Dating
                            </button>
                            <button
                                data-testid="mode-rishta"
                                onClick={() => setMode("rishta")}
                                className={`px-4 py-2 rounded-full text-xs font-semibold transition-all ${mode === "rishta" ? "neon-gradient text-white" : "text-zinc-400"}`}
                            >
                                Rishta
                            </button>
                        </div>
                        <button data-testid="discover-filters-btn" onClick={() => setShowFilters(!showFilters)} className="w-10 h-10 rounded-full glass flex items-center justify-center">
                            <Filter className="w-4 h-4" />
                        </button>
                    </div>
                </div>

                {/* Filters */}
                <AnimatePresence>
                    {showFilters && (
                        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden mb-6">
                            <div className="glass rounded-3xl p-6 grid grid-cols-1 sm:grid-cols-4 gap-4">
                                <div>
                                    <label className="text-xs text-zinc-500 mb-1 block">Min Age</label>
                                    <input data-testid="filter-min-age" type="number" min="18" max="99" value={filters.min_age} onChange={(e) => setFilters({ ...filters, min_age: parseInt(e.target.value) || 18 })} className="input-dark" />
                                </div>
                                <div>
                                    <label className="text-xs text-zinc-500 mb-1 block">Max Age</label>
                                    <input data-testid="filter-max-age" type="number" min="18" max="99" value={filters.max_age} onChange={(e) => setFilters({ ...filters, max_age: parseInt(e.target.value) || 60 })} className="input-dark" />
                                </div>
                                <div>
                                    <label className="text-xs text-zinc-500 mb-1 block">City</label>
                                    <input data-testid="filter-city" placeholder="Any city" value={filters.city} onChange={(e) => setFilters({ ...filters, city: e.target.value })} className="input-dark" />
                                </div>
                                <div className="flex items-end">
                                    <button data-testid="filter-apply-btn" onClick={loadProfiles} className="btn-primary w-full text-sm py-2.5">Apply</button>
                                </div>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>

                {/* Card Stack */}
                <div className="relative">
                    {loading ? (
                        <div className="aspect-[3/4] rounded-3xl glass animate-pulse max-w-md mx-auto" />
                    ) : !current ? (
                        <div data-testid="no-more-profiles" className="glass rounded-3xl p-12 text-center max-w-md mx-auto">
                            <Heart className="w-12 h-12 mx-auto mb-4 text-zinc-700" />
                            <h3 className="font-['Outfit'] text-xl font-bold mb-2">No more profiles</h3>
                            <p className="text-sm text-zinc-400 mb-5">Check back soon for new members</p>
                            <button onClick={loadProfiles} className="btn-primary text-sm">Refresh</button>
                        </div>
                    ) : (
                        <div className="max-w-md mx-auto">
                            <AnimatePresence mode="wait">
                                <SwipeCard key={current.id} profile={current} onSwipe={handleSwipe} mode={mode} />
                            </AnimatePresence>
                            <div className="flex items-center justify-center gap-4 mt-6">
                                <button
                                    data-testid="swipe-pass-btn"
                                    onClick={() => handleSwipe("pass")}
                                    className="w-16 h-16 rounded-full glass flex items-center justify-center hover:bg-white/10 hover:border-zinc-500 transition-all"
                                >
                                    <X className="w-7 h-7 text-zinc-400" strokeWidth={3} />
                                </button>
                                <button
                                    data-testid="swipe-superlike-btn"
                                    onClick={() => handleSwipe("superlike")}
                                    className="w-14 h-14 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center shadow-lg shadow-cyan-500/30 hover:scale-110 transition-transform"
                                >
                                    <Star className="w-6 h-6 text-white" fill="white" />
                                </button>
                                <button
                                    data-testid="swipe-like-btn"
                                    onClick={() => handleSwipe("like")}
                                    className="w-16 h-16 rounded-full neon-gradient flex items-center justify-center shadow-lg shadow-pink-500/50 hover:scale-110 transition-transform animate-pulse-pink"
                                >
                                    <Heart className="w-7 h-7 text-white" fill="white" />
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </AppShell>
    );
}

function SwipeCard({ profile, onSwipe, mode }) {
    const photo = profile.photos?.[0]?.path;
    const isRishta = mode === "rishta";
    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9, x: 0 }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            onDragEnd={(e, info) => {
                if (info.offset.x > 100) onSwipe("like");
                else if (info.offset.x < -100) onSwipe("pass");
            }}
            className="relative aspect-[3/4] rounded-3xl overflow-hidden cursor-grab active:cursor-grabbing"
        >
            {photo ? (
                <img src={fileUrl(photo)} alt={profile.name} className={`absolute inset-0 w-full h-full object-cover ${isRishta && profile.photos?.[0]?.private ? "blur-2xl" : ""}`} />
            ) : (
                <div className="absolute inset-0 bg-gradient-to-br from-[#FF2A85]/30 to-[#8B5CF6]/30 flex items-center justify-center text-8xl font-bold">
                    {profile.name?.[0]?.toUpperCase()}
                </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-transparent" />

            {/* Top badges */}
            <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                {profile.online && (
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md">
                        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        <span className="text-[11px] font-semibold">Online</span>
                    </div>
                )}
                {profile.verified && (
                    <div className="ml-auto flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#FF2A85]/90 backdrop-blur-md">
                        <Shield className="w-3 h-3" fill="white" />
                        <span className="text-[11px] font-bold">Verified</span>
                    </div>
                )}
            </div>

            {/* Bottom Content */}
            <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="flex items-center gap-2 mb-2">
                    <h2 className="text-3xl font-bold">{profile.name}, {profile.age}</h2>
                </div>
                <div className="space-y-1.5 mb-3">
                    {profile.city && <div className="flex items-center gap-1.5 text-sm text-zinc-300"><MapPin className="w-3.5 h-3.5" /> {profile.city}</div>}
                    {profile.profession && <div className="flex items-center gap-1.5 text-sm text-zinc-300"><Briefcase className="w-3.5 h-3.5" /> {profile.profession}</div>}
                    {profile.education && <div className="flex items-center gap-1.5 text-sm text-zinc-300"><GraduationCap className="w-3.5 h-3.5" /> {profile.education}</div>}
                </div>
                {profile.bio && <p className="text-xs text-zinc-400 leading-relaxed mb-3 line-clamp-2">{profile.bio}</p>}
                {profile.voice_intro && (
                    <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-black/40 backdrop-blur-md mb-3">
                        <Mic className="w-3.5 h-3.5 text-[#FF2A85]" />
                        <div className="flex-1 h-4 waveform" />
                        <span className="text-[10px] text-zinc-400">0:30</span>
                    </div>
                )}
                {isRishta && profile.wali_required && (
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-bold text-emerald-400">
                        <Shield className="w-3 h-3" /> Wali Approval Required
                    </div>
                )}
                {profile.interests && profile.interests.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                        {profile.interests.slice(0, 4).map((int, i) => (
                            <span key={i} className="text-[10px] px-2 py-0.5 rounded-full glass">{int}</span>
                        ))}
                    </div>
                )}
            </div>
        </motion.div>
    );
}
