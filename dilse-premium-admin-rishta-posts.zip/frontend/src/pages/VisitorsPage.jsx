import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import AppShell from "@/components/AppShell";
import api, { fileUrl } from "@/lib/api";
import { Eye } from "lucide-react";

export default function VisitorsPage() {
    const [profiles, setProfiles] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        api.get("/visitors").then(({ data }) => {
            setProfiles(data.profiles || []);
            setLoading(false);
        });
    }, []);

    return (
        <AppShell>
            <div className="max-w-5xl mx-auto">
                <div className="mb-6">
                    <h1 className="font-['Outfit'] text-3xl font-bold mb-1">Visitors</h1>
                    <p className="text-sm text-zinc-400">{profiles.length} people viewed your profile recently</p>
                </div>
                {loading ? (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{[...Array(4)].map((_, i) => <div key={i} className="aspect-[3/4] glass animate-pulse rounded-3xl" />)}</div>
                ) : profiles.length === 0 ? (
                    <div className="glass rounded-3xl p-12 text-center">
                        <Eye className="w-12 h-12 mx-auto mb-4 text-zinc-700" />
                        <h3 className="font-['Outfit'] text-xl font-bold mb-2">No visitors yet</h3>
                        <p className="text-sm text-zinc-400">Make your profile more attractive to get visitors!</p>
                    </div>
                ) : (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {profiles.map((p) => (
                            <Link key={p.id} to={`/profile/${p.id}`} data-testid={`visitor-card-${p.id}`} className="block group">
                                <div className="relative aspect-[3/4] rounded-3xl overflow-hidden glass">
                                    {p.photos?.[0]?.path ? (
                                        <img src={fileUrl(p.photos[0].path)} className="w-full h-full object-cover" alt="" />
                                    ) : (
                                        <div className="w-full h-full bg-gradient-to-br from-[#FF2A85]/30 to-[#8B5CF6]/30 flex items-center justify-center text-4xl font-bold">{p.name?.[0]}</div>
                                    )}
                                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
                                    <div className="absolute bottom-3 left-3 right-3">
                                        <div className="font-bold text-sm">{p.name}, {p.age}</div>
                                        <div className="text-xs text-zinc-400">{p.city}</div>
                                    </div>
                                </div>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
        </AppShell>
    );
}
