import { motion } from "framer-motion";
import { Heart, Sparkles, Shield, Mic, Crown, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { useLang } from "@/context/LanguageContext";

import PremiumHeader from "@/components/PremiumHeader";
import HeroSlider from "@/components/HeroSlider";
import PremiumFooter from "@/components/PremiumFooter";
import StatsSection from "@/components/StatsSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import PricingTableSection from "@/components/PricingTableSection";
import FaqSection from "@/components/FaqSection";

const testimonialImgs = [
    "https://images.unsplash.com/photo-1761125135357-99cbe52a6271?w=200&q=80",
    "https://images.unsplash.com/photo-1771507213365-c6047b40e2e1?w=200&q=80",
    "https://images.unsplash.com/photo-1759840278471-462cf3fcebd3?w=200&q=80",
];

const testimonialNames = [
    { name: "Usman & Sara", text: "Alhamdulillah! We found each other on DilSe and are now happily married." },
    { name: "Ali & Ayesha", text: "A perfect platform for finding a life partner. The AI matchmaker is incredible." },
    { name: "Hamza & Iqra", text: "Thanks to DilSe for helping us connect. May Allah bless you all!" },
];

export default function LandingPage() {
    const { t } = useLang();
    const features = [
        { icon: Sparkles, ...t("features.aiMatchmaker"), color: "from-[#FF2A85] to-[#8B5CF6]" },
        { icon: Mic, ...t("features.voiceIntros"), color: "from-[#8B5CF6] to-[#FF7A00]" },
        { icon: Shield, ...t("features.verified"), color: "from-[#FF7A00] to-[#FF2A85]" },
        { icon: Heart, ...t("features.dualModes"), color: "from-[#FF2A85] to-[#8B5CF6]" },
    ];
    return (
        <div className="min-h-screen bg-[#09090b] text-white overflow-x-hidden">
            <PremiumHeader />

            {/* Hero Slider */}
            <HeroSlider />

            {/* Stats Counter */}
            <StatsSection />

            {/* Features */}
            <section className="relative z-10 px-6 lg:px-8 py-20">
                <div className="max-w-7xl mx-auto">
                    <div className="text-center mb-16">
                        <div className="inline-block text-[10px] uppercase tracking-[0.25em] text-[#FF2A85] font-bold mb-3">{t("features.eyebrow")}</div>
                        <h2 className="font-['Outfit'] text-4xl lg:text-5xl font-bold mb-4">{t("features.heading")}</h2>
                        <p className="text-zinc-400 max-w-2xl mx-auto">{t("features.subtitle")}</p>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        {features.map((f, i) => (
                            <motion.div
                                key={f.title}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: i * 0.1 }}
                                data-testid={`feature-${i}`}
                                className="glass rounded-3xl p-6 hover:-translate-y-1 transition-all duration-300 hover:shadow-xl hover:shadow-pink-500/10"
                            >
                                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${f.color} flex items-center justify-center mb-5`}>
                                    <f.icon className="w-6 h-6 text-white" />
                                </div>
                                <h3 className="font-['Outfit'] text-lg font-bold mb-2">{f.title}</h3>
                                <p className="text-sm text-zinc-400 leading-relaxed">{f.desc}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Success Stories */}
            <section className="relative z-10 px-6 lg:px-8 py-20">
                <div className="max-w-7xl mx-auto">
                    <div className="text-center mb-16">
                        <div className="inline-block text-[10px] uppercase tracking-[0.25em] text-[#FF2A85] font-bold mb-3">{t("stories.eyebrow")}</div>
                        <h2 className="font-['Outfit'] text-4xl lg:text-5xl font-bold">{t("stories.heading")}</h2>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {testimonialNames.map((tt, i) => (
                            <motion.div
                                key={tt.name}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: i * 0.1 }}
                                className="glass rounded-3xl p-6"
                            >
                                <div className="flex items-center gap-3 mb-4">
                                    <img src={testimonialImgs[i]} alt={tt.name} className="w-12 h-12 rounded-2xl object-cover" />
                                    <div>
                                        <div className="font-bold flex items-center gap-1">{tt.name} <Heart className="w-3.5 h-3.5 text-[#FF2A85]" fill="currentColor" /></div>
                                        <div className="text-xs text-zinc-500">{t("stories.married")}</div>
                                    </div>
                                </div>
                                <p className="text-sm text-zinc-300 leading-relaxed">"{tt.text}"</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* How It Works */}
            <HowItWorksSection />

            {/* Pricing */}
            <PricingTableSection />

            {/* FAQ */}
            <FaqSection />

            {/* CTA */}
            <section className="relative z-10 px-6 lg:px-8 py-24">
                <div className="max-w-4xl mx-auto text-center glass-pink rounded-[2.5rem] p-12 lg:p-16">
                    <Crown className="w-12 h-12 text-[#FFB800] mx-auto mb-6" />
                    <h2 className="font-['Outfit'] text-4xl lg:text-5xl font-bold mb-4">{t("cta.heading")}</h2>
                    <p className="text-zinc-400 mb-8 max-w-xl mx-auto">{t("cta.subtitle")}</p>
                    <Link to="/register" data-testid="cta-register-btn" className="btn-primary inline-flex items-center gap-2 text-base">
                        {t("cta.button")}
                        <ChevronRight className="w-5 h-5" />
                    </Link>
                </div>
            </section>

            <PremiumFooter />
        </div>
    );
}
