import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, Eye, EyeOff } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { formatErrorDetail } from "@/lib/api";
import { motion } from "framer-motion";
import { toast } from "sonner";
import BrandLogo from "@/components/BrandLogo";

export default function LoginPage() {
    const { login } = useAuth();
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPwd, setShowPwd] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            const user = await login(email, password);
            toast.success(`Welcome back, ${user.name}!`);
            navigate(user.role === "admin" ? "/admin" : "/dashboard");
        } catch (e) {
            toast.error(formatErrorDetail(e.response?.data?.detail) || "Login failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-[#09090b] text-white px-4 relative overflow-hidden">
            <div className="fixed inset-0 pointer-events-none">
                <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-[#FF2A85]/15 rounded-full blur-[120px]" />
                <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-[#8B5CF6]/15 rounded-full blur-[120px]" />
            </div>

            <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="relative z-10 w-full max-w-md"
            >
                <Link to="/" data-testid="login-logo" className="flex justify-center mb-8">
                    <BrandLogo size="md" />
                </Link>

                <div className="glass-strong rounded-3xl p-8 shadow-2xl">
                    <h1 className="font-['Outfit'] text-3xl font-bold mb-2">Welcome back</h1>
                    <p className="text-sm text-zinc-400 mb-6">Continue your journey to find love</p>

                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="relative">
                            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                            <input
                                data-testid="login-email-input"
                                type="email"
                                required
                                placeholder="Email address"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="input-dark pl-11"
                            />
                        </div>
                        <div className="relative">
                            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                            <input
                                data-testid="login-password-input"
                                type={showPwd ? "text" : "password"}
                                required
                                placeholder="Password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="input-dark pl-11 pr-11"
                            />
                            <button type="button" onClick={() => setShowPwd(!showPwd)} className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white">
                                {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                        </div>
                        <div className="flex justify-end">
                            <Link to="/forgot-password" data-testid="login-forgot-link" className="text-xs text-[#FF2A85] hover:underline">Forgot password?</Link>
                        </div>
                        <button
                            data-testid="login-submit-btn"
                            type="submit"
                            disabled={loading}
                            className="w-full btn-primary disabled:opacity-50"
                        >
                            {loading ? "Signing in..." : "Sign In"}
                        </button>
                    </form>

                    <div className="text-center mt-6 text-sm text-zinc-500">
                        Don't have an account?{" "}
                        <Link to="/register" data-testid="login-register-link" className="text-[#FF2A85] font-semibold hover:underline">Sign up</Link>
                    </div>
                </div>
            </motion.div>
        </div>
    );
}
