import { useEffect, useState } from "react";
import AppShell from "@/components/AppShell";
import api from "@/lib/api";
import { motion } from "framer-motion";
import { FileText, Plus, Trash2, Save, MapPin, Users, Heart, Edit3 } from "lucide-react";
import { toast } from "sonner";

const emptyForm = {
    title: "",
    description: "",
    city: "",
    age_range: "",
    looking_for: "marriage",
    education_preference: "",
    family_details: "",
    contact_note: "",
    active: true,
};

export default function RishtaPostsPage() {
    const [posts, setPosts] = useState([]);
    const [mine, setMine] = useState([]);
    const [tab, setTab] = useState("browse");
    const [form, setForm] = useState(emptyForm);
    const [editing, setEditing] = useState(null);
    const [loading, setLoading] = useState(true);

    const load = async () => {
        const [all, my] = await Promise.all([
            api.get("/rishta/posts").catch(() => ({ data: { posts: [] } })),
            api.get("/rishta/posts/mine").catch(() => ({ data: { posts: [] } })),
        ]);
        setPosts(all.data.posts || []);
        setMine(my.data.posts || []);
        setLoading(false);
    };

    useEffect(() => { load(); }, []);

    const save = async () => {
        if (!form.title.trim() || !form.description.trim()) return toast.error("Title and description required");
        try {
            if (editing) await api.put(`/rishta/posts/${editing}`, form);
            else await api.post("/rishta/posts", form);
            toast.success(editing ? "Rishta post updated" : "Rishta post added");
            setForm(emptyForm);
            setEditing(null);
            setTab("mine");
            await load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Failed to save");
        }
    };

    const edit = (post) => {
        setEditing(post.id);
        setForm({ ...emptyForm, ...post });
        setTab("create");
    };

    const remove = async (id) => {
        if (!window.confirm("Delete this rishta post?")) return;
        try { await api.delete(`/rishta/posts/${id}`); toast.success("Deleted"); await load(); } catch { toast.error("Failed"); }
    };

    const list = tab === "mine" ? mine : posts;

    return (
        <AppShell>
            <div className="max-w-6xl mx-auto space-y-6">
                <div className="relative overflow-hidden rounded-[2rem] glass-pink p-6 lg:p-8">
                    <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full bg-[#FF2A85]/25 blur-3xl" />
                    <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div>
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/10 text-xs font-bold text-[#FF2A85] mb-3">
                                <Heart className="w-3.5 h-3.5" /> Family Rishta Board
                            </div>
                            <h1 className="text-3xl lg:text-5xl font-black">Post & Browse Rishta</h1>
                            <p className="text-zinc-400 mt-2 max-w-2xl">Create a serious marriage proposal post and browse active rishta posts from other users.</p>
                        </div>
                        <button onClick={() => setTab("create")} className="btn-primary inline-flex items-center gap-2"><Plus className="w-4 h-4" /> Add Rishta Post</button>
                    </div>
                </div>

                <div className="glass rounded-full p-1 flex items-center w-fit">
                    {[
                        ["browse", "Browse Posts"],
                        ["mine", "My Posts"],
                        ["create", editing ? "Edit Post" : "Add Post"],
                    ].map(([id, label]) => (
                        <button key={id} onClick={() => setTab(id)} className={`px-5 py-2 rounded-full text-xs font-bold transition ${tab === id ? "neon-gradient text-white" : "text-zinc-400 hover:text-white"}`}>{label}</button>
                    ))}
                </div>

                {tab === "create" ? (
                    <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="glass-strong rounded-[2rem] p-6">
                        <div className="flex items-center gap-3 mb-6">
                            <div className="w-11 h-11 rounded-2xl neon-gradient flex items-center justify-center"><FileText className="w-5 h-5" /></div>
                            <div>
                                <h2 className="text-2xl font-black">{editing ? "Edit Rishta Post" : "Create Rishta Post"}</h2>
                                <p className="text-sm text-zinc-500">Keep it respectful, serious, and family-friendly.</p>
                            </div>
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                            <Input label="Post Title" value={form.title} onChange={v => setForm({ ...form, title: v })} placeholder="Looking for serious rishta" />
                            <Input label="City" value={form.city} onChange={v => setForm({ ...form, city: v })} placeholder="Lahore / Karachi / Islamabad" />
                            <Input label="Age Range" value={form.age_range} onChange={v => setForm({ ...form, age_range: v })} placeholder="24-30" />
                            <Select label="Looking For" value={form.looking_for} onChange={v => setForm({ ...form, looking_for: v })} options={["marriage", "rishta", "family proposal"]} />
                            <Input label="Education Preference" value={form.education_preference} onChange={v => setForm({ ...form, education_preference: v })} placeholder="Graduate / Doctor / Engineer" />
                            <Input label="Contact Note" value={form.contact_note} onChange={v => setForm({ ...form, contact_note: v })} placeholder="Contact after admin/profile approval" />
                            <div className="md:col-span-2"><Input textarea label="Description" value={form.description} onChange={v => setForm({ ...form, description: v })} placeholder="Write proposal details..." /></div>
                            <div className="md:col-span-2"><Input textarea label="Family Details" value={form.family_details} onChange={v => setForm({ ...form, family_details: v })} placeholder="Family background, values, preferences..." /></div>
                        </div>
                        <div className="mt-5 flex flex-wrap gap-3">
                            <button onClick={save} className="btn-primary inline-flex items-center gap-2"><Save className="w-4 h-4" /> {editing ? "Update Post" : "Publish Post"}</button>
                            {editing && <button onClick={() => { setEditing(null); setForm(emptyForm); }} className="btn-ghost">Cancel</button>}
                        </div>
                    </motion.div>
                ) : loading ? (
                    <div className="grid md:grid-cols-2 gap-4">{[...Array(4)].map((_, i) => <div key={i} className="h-52 glass rounded-3xl animate-pulse" />)}</div>
                ) : list.length === 0 ? (
                    <div className="glass rounded-[2rem] p-12 text-center">
                        <Users className="w-14 h-14 mx-auto mb-4 text-zinc-700" />
                        <h3 className="text-2xl font-black mb-2">No rishta posts yet</h3>
                        <p className="text-zinc-400">Create the first serious proposal post.</p>
                    </div>
                ) : (
                    <div className="grid md:grid-cols-2 gap-4">
                        {list.map((post) => (
                            <motion.div key={post.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="glass-strong rounded-[2rem] p-5 hover:-translate-y-1 transition-all">
                                <div className="flex items-start justify-between gap-3 mb-3">
                                    <div>
                                        <h3 className="text-xl font-black">{post.title}</h3>
                                        <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500 mt-1">
                                            <span className="inline-flex items-center gap-1"><MapPin className="w-3 h-3" /> {post.city || "Any city"}</span>
                                            {post.age_range && <span>• Age {post.age_range}</span>}
                                            <span>• {post.looking_for}</span>
                                        </div>
                                    </div>
                                    {tab === "mine" && <div className="flex gap-2"><IconBtn onClick={() => edit(post)} icon={Edit3} /><IconBtn onClick={() => remove(post.id)} icon={Trash2} danger /></div>}
                                </div>
                                <p className="text-sm text-zinc-300 leading-relaxed">{post.description}</p>
                                {post.family_details && <div className="mt-4 rounded-2xl bg-white/[0.03] border border-white/10 p-3"><div className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1">Family Details</div><p className="text-xs text-zinc-400">{post.family_details}</p></div>}
                                {post.education_preference && <div className="mt-3 text-xs text-zinc-500">Education: {post.education_preference}</div>}
                                {post.contact_note && <div className="mt-2 text-xs text-[#FF2A85]">{post.contact_note}</div>}
                            </motion.div>
                        ))}
                    </div>
                )}
            </div>
        </AppShell>
    );
}

function Input({ label, value, onChange, placeholder, textarea = false }) {
    return <div><label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">{label}</label>{textarea ? <textarea rows={4} value={value || ""} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="input-dark" /> : <input value={value || ""} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="input-dark" />}</div>;
}

function Select({ label, value, onChange, options }) {
    return <div><label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">{label}</label><select value={value} onChange={e => onChange(e.target.value)} className="input-dark">{options.map(o => <option className="bg-zinc-900" key={o} value={o}>{o}</option>)}</select></div>;
}

function IconBtn({ icon: Icon, onClick, danger }) {
    return <button onClick={onClick} className={`w-9 h-9 rounded-full border flex items-center justify-center transition hover:scale-105 ${danger ? "bg-red-500/10 border-red-500/30 text-red-400" : "bg-white/[0.04] border-white/10 text-zinc-300 hover:text-white"}`}><Icon className="w-4 h-4" /></button>;
}
