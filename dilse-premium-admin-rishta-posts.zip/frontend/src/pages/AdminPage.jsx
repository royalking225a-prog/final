import AdminHeroTab from "@/pages/AdminHeroTab";
import { useEffect, useRef, useState } from "react";
import AppShell from "@/components/AppShell";
import api, { fileUrl } from "@/lib/api";
import {
    Users, Crown, Shield, Ban, MessageCircle, DollarSign, Heart, Search, Upload,
    Image as ImageIcon, Save, Palette, Bell, CreditCard, Check, X, Trash2, Plus,
    AlertCircle, AlertTriangle, Sparkles, Wallet, FileText, Edit3, Eye, ToggleLeft,
    ToggleRight, BarChart3, Settings, Gift, Megaphone
} from "lucide-react";
import { toast } from "sonner";
import { useBranding, resolveLogoUrl } from "@/context/BrandingContext";
import { useTheme, THEMES } from "@/context/ThemeContext";

const TABS = [
    { id: "overview", label: "Overview", icon: BarChart3 },
    { id: "users", label: "Users", icon: Shield },
    { id: "plans", label: "Plans", icon: Crown },
    { id: "methods", label: "Payment Methods", icon: Wallet },
    { id: "payments", label: "Payments", icon: CreditCard },
    { id: "rishtaPosts", label: "Rishta Posts", icon: FileText },
    { id: "hero", label: "Hero Slider", icon: ImageIcon },
    { id: "branding", label: "Branding", icon: ImageIcon },
    { id: "theme", label: "Theme", icon: Palette },
    { id: "popups", label: "Popups", icon: Bell },
];

const emptyPlan = { id: "", name: "", type: "monthly", amount: 0, discount_amount: "", currency: "pkr", days: 30, features: "", active: true, popular: false, badge: true };
const emptyMethod = { id: "", name: "", title: "", account: "", type: "wallet", active: true, instructions: "", qr_path: "" };

export default function AdminPage() {
    const { branding, refreshBranding } = useBranding();
    const { themeKey, setThemeKey } = useTheme();
    const [tab, setTab] = useState("overview");
    const [stats, setStats] = useState(null);
    const [users, setUsers] = useState([]);
    const [payments, setPayments] = useState([]);
    const [popups, setPopups] = useState([]);
    const [plans, setPlans] = useState([]);
    const [methods, setMethods] = useState([]);
    const [rishtaPosts, setRishtaPosts] = useState([]);
    const [q, setQ] = useState("");
    const [brandForm, setBrandForm] = useState({ brand_name: "", tagline: "" });
    const [popupForm, setPopupForm] = useState({ type: "promo", title: "", body: "", cta_label: "", cta_url: "", active: true, show_once: true });
    const [planForm, setPlanForm] = useState(emptyPlan);
    const [methodForm, setMethodForm] = useState(emptyMethod);
    const [editingPlan, setEditingPlan] = useState(null);
    const [editingMethod, setEditingMethod] = useState(null);
    const logoFileRef = useRef();
    const qrFileRef = useRef();

    const safeLoad = async (fn) => { try { await fn(); } catch (e) { console.warn(e); } };

    const loadOverview = async () => { const { data } = await api.get("/admin/stats"); setStats(data); };
    const loadUsers = async () => { const { data } = await api.get(`/admin/users${q ? `?q=${encodeURIComponent(q)}` : ""}`); setUsers(data.users || []); };
    const loadPayments = async () => { const { data } = await api.get("/admin/payments"); setPayments(data.submissions || []); };
    const loadPopups = async () => { const { data } = await api.get("/admin/popups"); setPopups(data.popups || []); };
    const loadPlans = async () => { const { data } = await api.get("/admin/plans"); setPlans(data.plans || []); };
    const loadMethods = async () => { const { data } = await api.get("/admin/payment-methods"); setMethods(data.payment_methods || []); };
    const loadRishtaPosts = async () => { const { data } = await api.get("/admin/rishta-posts"); setRishtaPosts(data.posts || []); };

    useEffect(() => {
        safeLoad(loadOverview); safeLoad(loadUsers); safeLoad(loadPayments); safeLoad(loadPopups);
        safeLoad(loadPlans); safeLoad(loadMethods); safeLoad(loadRishtaPosts);
        // eslint-disable-next-line
    }, []);

    useEffect(() => {
        if (branding) setBrandForm({ brand_name: branding.brand_name || "", tagline: branding.tagline || "" });
    }, [branding]);

    const refreshAll = () => {
        safeLoad(loadOverview); safeLoad(loadUsers); safeLoad(loadPayments); safeLoad(loadPlans); safeLoad(loadMethods); safeLoad(loadRishtaPosts);
    };

    const userAction = async (userId, act) => {
        try { await api.put(`/admin/users/${userId}?action=${act}`); toast.success("User updated"); await loadUsers(); await loadOverview(); } catch { toast.error("Failed"); }
    };

    const reviewPayment = async (id, act) => {
        try { await api.put(`/admin/payments/${id}?action=${act}`); toast.success(act === "approve" ? "Payment approved" : "Payment rejected"); await loadPayments(); await loadOverview(); } catch { toast.error("Failed"); }
    };

    const saveBrandText = async () => {
        try { await api.put("/admin/branding", brandForm); await refreshBranding(); toast.success("Branding saved"); } catch { toast.error("Failed"); }
    };

    const uploadLogo = async (e) => {
        const file = e.target.files?.[0]; if (!file) return;
        const fd = new FormData(); fd.append("file", file);
        try { await api.post("/admin/branding/upload", fd, { headers: { "Content-Type": "multipart/form-data" } }); await refreshBranding(); toast.success("Logo updated"); } catch { toast.error("Upload failed"); }
    };

    const createPopup = async () => {
        if (!popupForm.title || !popupForm.body) return toast.error("Title and body required");
        try { await api.post("/admin/popups", popupForm); toast.success("Popup created"); setPopupForm({ type: "promo", title: "", body: "", cta_label: "", cta_url: "", active: true, show_once: true }); await loadPopups(); } catch { toast.error("Failed"); }
    };

    const deletePopup = async (id) => { try { await api.delete(`/admin/popups/${id}`); toast.success("Deleted"); await loadPopups(); } catch { toast.error("Failed"); } };

    const editPlan = (plan) => {
        setEditingPlan(plan.id);
        setPlanForm({
            ...emptyPlan,
            ...plan,
            discount_amount: plan.discount_amount ?? "",
            features: Array.isArray(plan.features) ? plan.features.join("\n") : (plan.features || ""),
        });
        setTab("plans");
    };

    const savePlan = async () => {
        if (!planForm.name || !planForm.amount) return toast.error("Plan name and price required");
        const payload = {
            ...planForm,
            amount: Number(planForm.amount),
            discount_amount: planForm.discount_amount === "" ? null : Number(planForm.discount_amount),
            days: Number(planForm.days || 30),
            features: String(planForm.features || "").split("\n").map(f => f.trim()).filter(Boolean),
        };
        try {
            if (editingPlan) await api.put(`/admin/plans/${editingPlan}`, payload);
            else await api.post("/admin/plans", payload);
            toast.success(editingPlan ? "Plan updated" : "Plan added");
            setPlanForm(emptyPlan); setEditingPlan(null); await loadPlans(); await loadOverview();
        } catch (e) { toast.error(e?.response?.data?.detail || "Failed to save plan"); }
    };

    const deletePlan = async (id) => {
        if (!window.confirm("Delete this plan?")) return;
        try { await api.delete(`/admin/plans/${id}`); toast.success("Plan deleted"); await loadPlans(); } catch { toast.error("Failed"); }
    };

    const editMethod = (method) => {
        setEditingMethod(method.id);
        setMethodForm({ ...emptyMethod, ...method });
        setTab("methods");
    };

    const uploadQr = async (e) => {
        const file = e.target.files?.[0]; if (!file) return;
        const fd = new FormData(); fd.append("file", file);
        try {
            const { data } = await api.post("/admin/payment-methods/upload-qr", fd, { headers: { "Content-Type": "multipart/form-data" } });
            setMethodForm({ ...methodForm, qr_path: data.path });
            toast.success("QR uploaded");
        } catch { toast.error("QR upload failed"); }
    };

    const saveMethod = async () => {
        if (!methodForm.name || !methodForm.account) return toast.error("Method name and account required");
        try {
            if (editingMethod) await api.put(`/admin/payment-methods/${editingMethod}`, methodForm);
            else await api.post("/admin/payment-methods", methodForm);
            toast.success(editingMethod ? "Payment method updated" : "Payment method added");
            setMethodForm(emptyMethod); setEditingMethod(null); await loadMethods();
        } catch (e) { toast.error(e?.response?.data?.detail || "Failed to save payment method"); }
    };

    const deleteMethod = async (id) => {
        if (!window.confirm("Delete this payment method?")) return;
        try { await api.delete(`/admin/payment-methods/${id}`); toast.success("Payment method deleted"); await loadMethods(); } catch { toast.error("Failed"); }
    };

    const updatePost = async (id, active) => {
        try { await api.put(`/admin/rishta-posts/${id}?active=${active}`); toast.success("Post updated"); await loadRishtaPosts(); } catch { toast.error("Failed"); }
    };

    const deletePost = async (id) => {
        if (!window.confirm("Delete this rishta post?")) return;
        try { await api.delete(`/admin/rishta-posts/${id}`); toast.success("Post deleted"); await loadRishtaPosts(); } catch { toast.error("Failed"); }
    };

    const pendingPayments = payments.filter(p => p.status === "pending").length;
    const revenue = stats?.total_revenue || payments.filter(p => p.status === "approved").reduce((sum, p) => sum + Number(p.amount || 0), 0);

    return (
        <AppShell>
            <div className="max-w-7xl mx-auto space-y-6">
                <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-gradient-to-br from-white/[0.08] via-white/[0.03] to-[#FF2A85]/10 p-6 lg:p-8 shadow-2xl">
                    <div className="absolute -right-20 -top-20 h-56 w-56 rounded-full bg-[#FF2A85]/20 blur-3xl" />
                    <div className="absolute right-32 bottom-0 h-40 w-40 rounded-full bg-[#8B5CF6]/20 blur-3xl" />
                    <div className="relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
                        <div>
                            <div className="inline-flex items-center gap-2 rounded-full border border-[#FF2A85]/30 bg-[#FF2A85]/10 px-3 py-1 text-xs font-bold text-[#ff7bb8] mb-3">
                                <Sparkles className="w-3.5 h-3.5" /> Premium Control Center
                            </div>
                            <h1 className="text-3xl lg:text-5xl font-black tracking-tight">Admin Dashboard</h1>
                            <p className="text-sm text-zinc-400 mt-2 max-w-2xl">Manage users, plans, payment methods, rishta posts, branding and platform growth from one luxury dashboard.</p>
                        </div>
                        <button onClick={refreshAll} className="btn-primary inline-flex items-center justify-center gap-2 text-sm px-6">
                            <BarChart3 className="w-4 h-4" /> Refresh Data
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6">
                    <aside className="glass-strong rounded-[2rem] p-3 h-fit sticky top-4">
                        <div className="px-3 py-4 border-b border-white/10 mb-2">
                            <div className="text-xs text-zinc-500 uppercase tracking-[0.2em]">Admin Menu</div>
                        </div>
                        <nav className="space-y-1">
                            {TABS.map((t) => (
                                <button
                                    key={t.id}
                                    data-testid={`admin-tab-${t.id}`}
                                    onClick={() => setTab(t.id)}
                                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold transition-all ${
                                        tab === t.id
                                            ? "neon-gradient text-white shadow-lg shadow-pink-500/20"
                                            : "text-zinc-400 hover:text-white hover:bg-white/[0.06]"
                                    }`}
                                >
                                    <t.icon className="w-4 h-4" /> <span className="truncate">{t.label}</span>
                                </button>
                            ))}
                        </nav>
                    </aside>

                    <main className="min-w-0">
                        {tab === "overview" && (
                            <div className="space-y-6">
                                <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3">
                                    {[
                                        { label: "Users", value: stats?.total_users || users.length, icon: Users, color: "from-[#FF2A85] to-[#8B5CF6]" },
                                        { label: "Verified", value: stats?.verified_users || users.filter(u => u.verified).length, icon: Shield, color: "from-emerald-500 to-cyan-500" },
                                        { label: "Premium", value: stats?.premium_users || users.filter(u => u.premium).length, icon: Crown, color: "from-amber-500 to-orange-500" },
                                        { label: "Banned", value: stats?.banned_users || users.filter(u => u.banned).length, icon: Ban, color: "from-red-500 to-rose-500" },
                                        { label: "Matches", value: stats?.total_matches || 0, icon: Heart, color: "from-pink-500 to-fuchsia-500" },
                                        { label: "Pending", value: pendingPayments, icon: CreditCard, color: "from-blue-500 to-indigo-500" },
                                        { label: "Revenue", value: `${revenue} PKR`, icon: DollarSign, color: "from-emerald-400 to-green-500" },
                                    ].map((s) => <StatCard key={s.label} {...s} />)}
                                </div>

                                <div className="grid lg:grid-cols-2 gap-6">
                                    <Panel title="Revenue Overview" icon={BarChart3}>
                                        <div className="h-56 rounded-3xl bg-gradient-to-br from-[#FF2A85]/15 to-[#8B5CF6]/10 border border-white/10 p-5 flex items-end gap-3">
                                            {[35, 55, 42, 70, 60, 88, 74, 96].map((h, i) => (
                                                <div key={i} className="flex-1 rounded-t-2xl neon-gradient opacity-80" style={{ height: `${h}%` }} />
                                            ))}
                                        </div>
                                    </Panel>
                                    <Panel title="Quick Actions" icon={Settings}>
                                        <div className="grid sm:grid-cols-2 gap-3">
                                            <QuickAction icon={Crown} label="Manage Plans" onClick={() => setTab("plans")} />
                                            <QuickAction icon={Wallet} label="Payment Methods" onClick={() => setTab("methods")} />
                                            <QuickAction icon={FileText} label="Rishta Posts" onClick={() => setTab("rishtaPosts")} />
                                            <QuickAction icon={Megaphone} label="Popups" onClick={() => setTab("popups")} />
                                        </div>
                                    </Panel>
                                </div>
                            </div>
                        )}

                        {tab === "users" && (
                            <Panel title="User Management" icon={Users}>
                                <div className="flex flex-col sm:flex-row gap-3 mb-5">
                                    <div className="relative flex-1">
                                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                                        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or email..." className="input-dark pl-11" />
                                    </div>
                                    <button onClick={loadUsers} className="btn-primary text-sm">Search</button>
                                </div>
                                <DataTable headers={["User", "Email", "Age", "Status", "Actions"]}>
                                    {users.map((u) => (
                                        <tr key={u.id} className="border-b border-white/5 hover:bg-white/[0.03]">
                                            <td className="p-4"><div className="flex items-center gap-3"><Avatar name={u.name} /><div><div className="font-bold">{u.name}</div><div className="text-xs text-zinc-500">{u.city || "—"}</div></div></div></td>
                                            <td className="p-4 text-zinc-400">{u.email}</td>
                                            <td className="p-4 text-zinc-400">{u.age}</td>
                                            <td className="p-4"><div className="flex flex-wrap gap-1">{u.role === "admin" && <Badge color="amber">Admin</Badge>}{u.verified && <Badge color="emerald">Verified</Badge>}{u.premium && <Badge color="pink">{u.premium_tier?.toUpperCase() || "Premium"}</Badge>}{u.banned && <Badge color="red">Banned</Badge>}</div></td>
                                            <td className="p-4"><div className="flex flex-wrap justify-end gap-2">
                                                <MiniBtn onClick={() => userAction(u.id, u.verified ? "unverify" : "verify")} color="emerald">{u.verified ? "Unverify" : "Verify"}</MiniBtn>
                                                {!u.premium && <MiniBtn onClick={() => userAction(u.id, "grant_premium")} color="amber">+VIP</MiniBtn>}
                                                <MiniBtn onClick={() => userAction(u.id, u.banned ? "unban" : "ban")} color={u.banned ? "emerald" : "red"}>{u.banned ? "Unban" : "Ban"}</MiniBtn>
                                            </div></td>
                                        </tr>
                                    ))}
                                </DataTable>
                            </Panel>
                        )}

                        {tab === "plans" && (
                            <div className="space-y-6">
                                <Panel title={editingPlan ? "Edit Premium Plan" : "Add Premium Plan"} icon={Crown}>
                                    <div className="grid md:grid-cols-2 gap-4">
                                        <Input label="Plan ID" value={planForm.id} disabled={!!editingPlan} onChange={v => setPlanForm({ ...planForm, id: v })} placeholder="silver / gold" />
                                        <Input label="Plan Name" value={planForm.name} onChange={v => setPlanForm({ ...planForm, name: v })} placeholder="Gold VIP" />
                                        <Select label="Type" value={planForm.type} onChange={v => setPlanForm({ ...planForm, type: v })} options={["monthly", "yearly", "lifetime"]} />
                                        <Input label="Price" type="number" value={planForm.amount} onChange={v => setPlanForm({ ...planForm, amount: v })} />
                                        <Input label="Discount Price" type="number" value={planForm.discount_amount} onChange={v => setPlanForm({ ...planForm, discount_amount: v })} />
                                        <Input label="Duration Days" type="number" value={planForm.days} onChange={v => setPlanForm({ ...planForm, days: v })} />
                                        <div className="md:col-span-2"><Input textarea label="Features (one per line)" value={planForm.features} onChange={v => setPlanForm({ ...planForm, features: v })} /></div>
                                        <div className="md:col-span-2 flex flex-wrap gap-3">
                                            <Toggle label="Active" checked={planForm.active} onChange={v => setPlanForm({ ...planForm, active: v })} />
                                            <Toggle label="Popular" checked={planForm.popular} onChange={v => setPlanForm({ ...planForm, popular: v })} />
                                            <Toggle label="Premium Badge" checked={planForm.badge} onChange={v => setPlanForm({ ...planForm, badge: v })} />
                                        </div>
                                    </div>
                                    <div className="mt-5 flex gap-3">
                                        <button onClick={savePlan} className="btn-primary text-sm inline-flex items-center gap-2"><Save className="w-4 h-4" /> Save Plan</button>
                                        {editingPlan && <button onClick={() => { setEditingPlan(null); setPlanForm(emptyPlan); }} className="btn-ghost text-sm">Cancel</button>}
                                    </div>
                                </Panel>

                                <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
                                    {plans.map((p) => (
                                        <div key={p.id} className={`relative overflow-hidden glass-strong rounded-[2rem] p-5 border ${p.popular ? "border-amber-400/40" : "border-white/10"}`}>
                                            {p.popular && <div className="absolute top-4 right-4 text-[10px] font-black px-3 py-1 rounded-full bg-amber-400 text-black">POPULAR</div>}
                                            <div className="flex items-center gap-3 mb-4">
                                                <div className="w-12 h-12 rounded-2xl neon-gradient flex items-center justify-center"><Crown className="w-6 h-6" /></div>
                                                <div><h3 className="text-xl font-black">{p.name}</h3><p className="text-xs text-zinc-500 uppercase">{p.type} · {p.days} days</p></div>
                                            </div>
                                            <div className="text-3xl font-black mb-3">{p.discount_amount || p.amount} <span className="text-sm text-zinc-500 uppercase">{p.currency}</span></div>
                                            <ul className="space-y-2 min-h-[100px]">{(p.features || []).slice(0, 6).map(f => <li key={f} className="flex gap-2 text-sm text-zinc-300"><Check className="w-4 h-4 text-emerald-400 shrink-0" /> {f}</li>)}</ul>
                                            <div className="flex items-center justify-between mt-5">
                                                <Badge color={p.active ? "emerald" : "red"}>{p.active ? "Active" : "Inactive"}</Badge>
                                                <div className="flex gap-2">
                                                    <IconBtn onClick={() => editPlan(p)} icon={Edit3} />
                                                    <IconBtn onClick={() => deletePlan(p.id)} icon={Trash2} danger />
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {tab === "methods" && (
                            <div className="space-y-6">
                                <Panel title={editingMethod ? "Edit Payment Method" : "Add Payment Method"} icon={Wallet}>
                                    <div className="grid md:grid-cols-2 gap-4">
                                        <Input label="Method ID" value={methodForm.id} disabled={!!editingMethod} onChange={v => setMethodForm({ ...methodForm, id: v })} placeholder="nayapay / hbl" />
                                        <Input label="Method Name" value={methodForm.name} onChange={v => setMethodForm({ ...methodForm, name: v })} placeholder="NayaPay" />
                                        <Input label="Account Title" value={methodForm.title} onChange={v => setMethodForm({ ...methodForm, title: v })} placeholder="Sadam Hussain" />
                                        <Input label="Account / Wallet Number" value={methodForm.account} onChange={v => setMethodForm({ ...methodForm, account: v })} />
                                        <Select label="Type" value={methodForm.type} onChange={v => setMethodForm({ ...methodForm, type: v })} options={["wallet", "bank", "card", "crypto"]} />
                                        <Toggle label="Active" checked={methodForm.active} onChange={v => setMethodForm({ ...methodForm, active: v })} />
                                        <div className="md:col-span-2"><Input textarea label="Payment Instructions" value={methodForm.instructions} onChange={v => setMethodForm({ ...methodForm, instructions: v })} /></div>
                                    </div>
                                    <div className="mt-5 flex flex-wrap gap-3">
                                        <input ref={qrFileRef} type="file" accept="image/*" onChange={uploadQr} className="hidden" />
                                        <button onClick={() => qrFileRef.current?.click()} className="btn-ghost text-sm inline-flex items-center gap-2"><Upload className="w-4 h-4" /> Upload QR</button>
                                        <button onClick={saveMethod} className="btn-primary text-sm inline-flex items-center gap-2"><Save className="w-4 h-4" /> Save Method</button>
                                        {editingMethod && <button onClick={() => { setEditingMethod(null); setMethodForm(emptyMethod); }} className="btn-ghost text-sm">Cancel</button>}
                                    </div>
                                </Panel>
                                <div className="grid md:grid-cols-2 gap-4">
                                    {methods.map((m) => (
                                        <div key={m.id} className="glass-strong rounded-[2rem] p-5">
                                            <div className="flex items-start gap-4">
                                                <div className="w-14 h-14 rounded-2xl bg-[#FF2A85]/15 border border-[#FF2A85]/20 flex items-center justify-center"><Wallet className="w-7 h-7 text-[#FF2A85]" /></div>
                                                <div className="flex-1">
                                                    <div className="flex items-center gap-2"><h3 className="text-xl font-black">{m.name}</h3><Badge color={m.active ? "emerald" : "red"}>{m.active ? "Active" : "Off"}</Badge></div>
                                                    <p className="text-sm text-zinc-400">{m.title}</p>
                                                    <p className="font-mono text-lg mt-2">{m.account}</p>
                                                    <p className="text-xs text-zinc-500 mt-2">{m.instructions}</p>
                                                </div>
                                            </div>
                                            {m.qr_path && <img src={fileUrl(m.qr_path)} alt="QR" className="mt-4 w-28 h-28 rounded-2xl object-cover border border-white/10" />}
                                            <div className="flex justify-end gap-2 mt-4"><IconBtn onClick={() => editMethod(m)} icon={Edit3} /><IconBtn onClick={() => deleteMethod(m.id)} icon={Trash2} danger /></div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {tab === "payments" && (
                            <Panel title={`Payment Verifications (${pendingPayments} pending)`} icon={CreditCard}>
                                <DataTable headers={["User", "Plan", "Amount", "Method", "Txn ID", "Proof", "Status", "Actions"]}>
                                    {payments.length === 0 ? <tr><td colSpan={8} className="p-8 text-center text-zinc-500">No payment submissions yet</td></tr> : payments.map((p) => (
                                        <tr key={p.id} className="border-b border-white/5 hover:bg-white/[0.03]">
                                            <td className="p-4"><div className="font-bold text-xs">{p.user_name}</div><div className="text-[10px] text-zinc-500">{p.user_email}</div></td>
                                            <td className="p-4"><Badge color={p.plan_id === "gold" ? "amber" : "pink"}>{p.plan_id}</Badge></td>
                                            <td className="p-4 font-bold text-[#FF2A85]">{p.amount} {p.currency?.toUpperCase() || "PKR"}</td>
                                            <td className="p-4 text-zinc-400 text-xs uppercase">{p.method_id}</td>
                                            <td className="p-4 font-mono text-xs text-zinc-400">{p.transaction_id || "—"}</td>
                                            <td className="p-4">{p.screenshot_path && <a href={fileUrl(p.screenshot_path)} target="_blank" rel="noreferrer" className="text-[#FF2A85] hover:underline text-xs inline-flex items-center gap-1"><Eye className="w-3 h-3" /> View</a>}</td>
                                            <td className="p-4"><Badge color={p.status === "approved" ? "emerald" : p.status === "rejected" ? "red" : "amber"}>{p.status}</Badge></td>
                                            <td className="p-4"><div className="flex justify-end gap-2">{p.status === "pending" && <><IconBtn onClick={() => reviewPayment(p.id, "approve")} icon={Check} success /><IconBtn onClick={() => reviewPayment(p.id, "reject")} icon={X} danger /></>}</div></td>
                                        </tr>
                                    ))}
                                </DataTable>
                            </Panel>
                        )}

                        {tab === "rishtaPosts" && (
                            <Panel title="User Rishta Posts" icon={FileText}>
                                <div className="grid gap-3">
                                    {rishtaPosts.length === 0 ? <div className="text-center text-zinc-500 py-10">No rishta posts yet</div> : rishtaPosts.map((p) => (
                                        <div key={p.id} className="rounded-3xl border border-white/10 bg-white/[0.03] p-4">
                                            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
                                                <div>
                                                    <div className="flex items-center gap-2 mb-1"><h3 className="font-black text-lg">{p.title}</h3><Badge color={p.active ? "emerald" : "red"}>{p.active ? "Active" : "Hidden"}</Badge></div>
                                                    <p className="text-sm text-zinc-400">{p.description}</p>
                                                    <div className="flex flex-wrap gap-2 mt-3 text-xs text-zinc-500">
                                                        <span>By: {p.user_name || p.user_id}</span><span>•</span><span>{p.city || "Any city"}</span><span>•</span><span>{p.looking_for}</span>
                                                    </div>
                                                </div>
                                                <div className="flex gap-2">
                                                    <IconBtn onClick={() => updatePost(p.id, !p.active)} icon={p.active ? ToggleLeft : ToggleRight} />
                                                    <IconBtn onClick={() => deletePost(p.id)} icon={Trash2} danger />
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </Panel>
                        )}

                        {tab === "hero" && <AdminHeroTab />}

                        {tab === "branding" && (
                            <Panel title="Branding & Logo" icon={ImageIcon}>
                                <div className="grid lg:grid-cols-3 gap-6">
                                    <div>
                                        <div className="aspect-square rounded-3xl overflow-hidden bg-black glass-pink mb-3 flex items-center justify-center">
                                            {branding?.logo_url ? <img src={resolveLogoUrl(branding.logo_url)} alt="logo" className="w-full h-full object-cover" /> : <div className="text-zinc-500">Default logo</div>}
                                        </div>
                                        <input ref={logoFileRef} type="file" accept="image/*" onChange={uploadLogo} className="hidden" />
                                        <button onClick={() => logoFileRef.current?.click()} className="btn-primary w-full text-sm py-2.5 flex items-center justify-center gap-2"><Upload className="w-4 h-4" /> Upload New Logo</button>
                                    </div>
                                    <div className="lg:col-span-2 space-y-4">
                                        <Input label="Brand Name" value={brandForm.brand_name} onChange={v => setBrandForm({ ...brandForm, brand_name: v })} />
                                        <Input label="Tagline" value={brandForm.tagline} onChange={v => setBrandForm({ ...brandForm, tagline: v })} />
                                        <button onClick={saveBrandText} className="btn-primary text-sm inline-flex items-center gap-2"><Save className="w-4 h-4" /> Save Branding</button>
                                    </div>
                                </div>
                            </Panel>
                        )}

                        {tab === "theme" && (
                            <Panel title="Theme Manager" icon={Palette}>
                                <p className="text-sm text-zinc-400 mb-6">Choose a color palette. Changes apply instantly across the app.</p>
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                    {Object.entries(THEMES).map(([key, theme]) => (
                                        <button key={key} onClick={() => { setThemeKey(key); toast.success(`Theme: ${theme.name}`); }} className={`relative p-5 rounded-3xl border transition-all text-left ${themeKey === key ? "border-[#FF2A85]/50 shadow-xl shadow-pink-500/20 bg-white/[0.04]" : "border-white/[0.08] hover:border-white/[0.16] bg-white/[0.02]"}`}>
                                            <div className="flex gap-1.5 mb-4">{theme.gradient.map((c, i) => <div key={i} className="w-10 h-10 rounded-2xl shadow-lg" style={{ background: c, boxShadow: `0 0 20px ${c}80` }} />)}</div>
                                            <div className="font-black">{theme.emoji} {theme.name}</div>
                                            {themeKey === key && <div className="absolute top-3 right-3 w-6 h-6 rounded-full neon-gradient flex items-center justify-center"><Check className="w-3.5 h-3.5" /></div>}
                                        </button>
                                    ))}
                                </div>
                            </Panel>
                        )}

                        {tab === "popups" && (
                            <div className="space-y-6">
                                <Panel title="Create Popup" icon={Plus}>
                                    <div className="grid lg:grid-cols-2 gap-4">
                                        <Select label="Popup Type" value={popupForm.type} onChange={v => setPopupForm({ ...popupForm, type: v })} options={["success", "error", "warning", "promo"]} />
                                        <div className="flex items-end gap-4"><Toggle label="Active" checked={popupForm.active} onChange={v => setPopupForm({ ...popupForm, active: v })} /><Toggle label="Show once" checked={popupForm.show_once} onChange={v => setPopupForm({ ...popupForm, show_once: v })} /></div>
                                        <Input label="Title" value={popupForm.title} onChange={v => setPopupForm({ ...popupForm, title: v })} />
                                        <Input label="CTA Label" value={popupForm.cta_label} onChange={v => setPopupForm({ ...popupForm, cta_label: v })} />
                                        <div className="lg:col-span-2"><Input textarea label="Body" value={popupForm.body} onChange={v => setPopupForm({ ...popupForm, body: v })} /></div>
                                        <div className="lg:col-span-2"><Input label="CTA URL" value={popupForm.cta_url} onChange={v => setPopupForm({ ...popupForm, cta_url: v })} /></div>
                                    </div>
                                    <button onClick={createPopup} className="btn-primary mt-5 text-sm inline-flex items-center gap-2"><Plus className="w-4 h-4" /> Create Popup</button>
                                </Panel>
                                <Panel title="Existing Popups" icon={Bell}>
                                    <div className="space-y-3">
                                        {popups.length === 0 ? <div className="text-zinc-500 text-center py-8">No popups created</div> : popups.map(p => (
                                            <div key={p.id} className="flex items-center gap-3 p-4 rounded-2xl bg-white/[0.03] border border-white/10">
                                                <div className="w-10 h-10 rounded-xl neon-gradient flex items-center justify-center font-black">{p.type?.[0]?.toUpperCase()}</div>
                                                <div className="flex-1 min-w-0"><div className="font-bold">{p.title}</div><div className="text-sm text-zinc-400 truncate">{p.body}</div></div>
                                                {p.active && <Badge color="emerald">Active</Badge>}
                                                <IconBtn onClick={() => deletePopup(p.id)} icon={Trash2} danger />
                                            </div>
                                        ))}
                                    </div>
                                </Panel>
                            </div>
                        )}
                    </main>
                </div>
            </div>
        </AppShell>
    );
}

function StatCard({ label, value, icon: Icon, color }) {
    return (
        <div className="glass-strong rounded-3xl p-4 hover:-translate-y-1 transition-all duration-300">
            <div className={`w-10 h-10 rounded-2xl bg-gradient-to-br ${color} flex items-center justify-center mb-3 shadow-lg`}>
                <Icon className="w-5 h-5 text-white" />
            </div>
            <div className="text-2xl font-black truncate">{value}</div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-zinc-500 mt-1">{label}</div>
        </div>
    );
}

function Panel({ title, icon: Icon, children }) {
    return (
        <section className="glass-strong rounded-[2rem] p-5 lg:p-6 shadow-2xl shadow-black/20">
            <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 rounded-2xl bg-[#FF2A85]/15 border border-[#FF2A85]/25 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-[#FF2A85]" />
                </div>
                <h2 className="text-xl font-black">{title}</h2>
            </div>
            {children}
        </section>
    );
}

function QuickAction({ icon: Icon, label, onClick }) {
    return <button onClick={onClick} className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-[#FF2A85]/40 hover:bg-[#FF2A85]/10 transition-all text-left"><Icon className="w-5 h-5 text-[#FF2A85] mb-3" /><div className="font-bold">{label}</div></button>;
}

function DataTable({ headers, children }) {
    return <div className="rounded-3xl overflow-hidden border border-white/10"><div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-white/[0.03] border-b border-white/10"><tr className="text-left text-[10px] uppercase tracking-[0.2em] text-zinc-500">{headers.map(h => <th key={h} className="p-4">{h}</th>)}</tr></thead><tbody>{children}</tbody></table></div></div>;
}

function Input({ label, value, onChange, placeholder, type = "text", textarea = false, disabled = false }) {
    return <div><label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">{label}</label>{textarea ? <textarea rows={4} value={value || ""} onChange={e => onChange(e.target.value)} placeholder={placeholder} disabled={disabled} className="input-dark" /> : <input type={type} value={value ?? ""} onChange={e => onChange(e.target.value)} placeholder={placeholder} disabled={disabled} className="input-dark disabled:opacity-50" />}</div>;
}

function Select({ label, value, onChange, options }) {
    return <div><label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">{label}</label><select value={value || ""} onChange={e => onChange(e.target.value)} className="input-dark">{options.map(o => <option className="bg-zinc-900" key={o} value={o}>{o}</option>)}</select></div>;
}

function Toggle({ label, checked, onChange }) {
    return <label className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm font-bold cursor-pointer"><input type="checkbox" checked={!!checked} onChange={e => onChange(e.target.checked)} /> {label}</label>;
}

function Avatar({ name }) {
    return <div className="w-10 h-10 rounded-2xl neon-gradient flex items-center justify-center text-sm font-black">{name?.[0]?.toUpperCase() || "U"}</div>;
}

function Badge({ color, children }) {
    const colors = {
        amber: "bg-amber-500/10 border-amber-500/20 text-amber-400",
        emerald: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
        pink: "bg-[#FF2A85]/10 border-[#FF2A85]/20 text-[#FF2A85]",
        red: "bg-red-500/10 border-red-500/20 text-red-400",
    };
    return <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase tracking-wider ${colors[color] || colors.pink}`}>{children}</span>;
}

function MiniBtn({ children, onClick, color = "pink" }) {
    const colors = { pink: "bg-[#FF2A85]/10 border-[#FF2A85]/20 text-[#FF2A85]", amber: "bg-amber-500/10 border-amber-500/20 text-amber-400", emerald: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400", red: "bg-red-500/10 border-red-500/20 text-red-400" };
    return <button onClick={onClick} className={`px-3 py-1.5 rounded-full text-[10px] font-black border hover:scale-105 transition ${colors[color]}`}>{children}</button>;
}

function IconBtn({ icon: Icon, onClick, danger, success }) {
    return <button onClick={onClick} className={`w-9 h-9 rounded-full border flex items-center justify-center transition hover:scale-105 ${danger ? "bg-red-500/10 border-red-500/30 text-red-400" : success ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" : "bg-white/[0.04] border-white/10 text-zinc-300 hover:text-white"}`}><Icon className="w-4 h-4" /></button>;
}
