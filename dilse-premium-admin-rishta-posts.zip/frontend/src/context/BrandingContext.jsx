import { createContext, useContext, useState, useEffect, useCallback } from "react";
import api from "@/lib/api";

const BrandingContext = createContext();

const DEFAULT = {
    logo_url: "https://customer-assets.emergentagent.com/job_dilse-premium/artifacts/8c0kbul1_WhatsApp%20Image%202026-05-26%20at%2012.30.49%20AM.jpeg",
    brand_name: "DilSe",
    tagline: "Premium Rishta & Dating",
};

export function BrandingProvider({ children }) {
    const [branding, setBranding] = useState(() => {
        try {
            const cached = localStorage.getItem("dilse_branding");
            return cached ? JSON.parse(cached) : DEFAULT;
        } catch {
            return DEFAULT;
        }
    });

    const fetchBranding = useCallback(async () => {
        try {
            const { data } = await api.get("/branding");
            setBranding(data);
            localStorage.setItem("dilse_branding", JSON.stringify(data));
            // Update favicon dynamically
            const link = document.querySelector("link[rel='icon']") || document.createElement("link");
            link.rel = "icon";
            link.href = data.logo_url?.startsWith("/api/")
                ? `${process.env.REACT_APP_BACKEND_URL}${data.logo_url}?auth=${localStorage.getItem("dilse_token") || ""}`
                : data.logo_url;
            document.head.appendChild(link);
            // Update document title
            document.title = `${data.brand_name} — ${data.tagline}`;
        } catch (e) {
            // Use cached / default
        }
    }, []);

    useEffect(() => {
        fetchBranding();
    }, [fetchBranding]);

    return (
        <BrandingContext.Provider value={{ branding, refreshBranding: fetchBranding, setBranding }}>
            {children}
        </BrandingContext.Provider>
    );
}

export function useBranding() {
    return useContext(BrandingContext);
}

/**
 * Get the full URL for a logo (resolves /api/files/ paths properly)
 */
export function resolveLogoUrl(logoUrl) {
    if (!logoUrl) return DEFAULT.logo_url;
    if (logoUrl.startsWith("http")) return logoUrl;
    if (logoUrl.startsWith("/api/")) {
        const token = localStorage.getItem("dilse_token") || "";
        return `${process.env.REACT_APP_BACKEND_URL}${logoUrl}?auth=${token}`;
    }
    return logoUrl;
}
