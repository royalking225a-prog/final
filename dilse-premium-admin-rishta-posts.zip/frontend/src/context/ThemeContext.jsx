import { createContext, useContext, useState, useEffect } from "react";

export const THEMES = {
    "pink-purple": {
        name: "Neon Pink × Purple",
        emoji: "💖",
        gradient: ["#FF2A85", "#D946EF", "#8B5CF6"],
    },
    "rose-gold": {
        name: "Rose Gold",
        emoji: "🌹",
        gradient: ["#FFB800", "#FF6FA8", "#FF2A85"],
    },
    "midnight-blue": {
        name: "Midnight Blue",
        emoji: "🌌",
        gradient: ["#3B82F6", "#6366F1", "#8B5CF6"],
    },
    "emerald-mint": {
        name: "Emerald Mint",
        emoji: "💎",
        gradient: ["#10B981", "#06B6D4", "#3B82F6"],
    },
    "sunset-orange": {
        name: "Sunset Orange",
        emoji: "🌅",
        gradient: ["#FB923C", "#F43F5E", "#D946EF"],
    },
    "royal-purple": {
        name: "Royal Purple",
        emoji: "👑",
        gradient: ["#A855F7", "#9333EA", "#7E22CE"],
    },
};

const ThemeContext = createContext();

export function ThemeProvider({ children }) {
    const [themeKey, setThemeKey] = useState(() => localStorage.getItem("dilse_theme") || "pink-purple");

    useEffect(() => {
        const theme = THEMES[themeKey] || THEMES["pink-purple"];
        const [c1, c2, c3] = theme.gradient;
        const root = document.documentElement;
        root.style.setProperty("--brand-1", c1);
        root.style.setProperty("--brand-2", c2);
        root.style.setProperty("--brand-3", c3);
        // Update neon-gradient CSS var consumers
        const styleEl = document.getElementById("theme-vars") || document.createElement("style");
        styleEl.id = "theme-vars";
        styleEl.innerHTML = `
            .neon-gradient { background: linear-gradient(135deg, ${c1} 0%, ${c2} 50%, ${c3} 100%) !important; }
            .neon-gradient-2 { background: linear-gradient(90deg, ${c1} 0%, ${c3} 100%) !important; }
            .text-neon-gradient { background: linear-gradient(135deg, ${c1} 0%, ${c2} 50%, ${c3} 100%) !important; -webkit-background-clip: text !important; background-clip: text !important; -webkit-text-fill-color: transparent !important; color: transparent !important; }
            .glow-pink { box-shadow: 0 0 40px ${c1}59 !important; }
            .glass-pink { background: ${c1}14 !important; border-color: ${c1}40 !important; }
        `;
        if (!styleEl.parentNode) document.head.appendChild(styleEl);
        localStorage.setItem("dilse_theme", themeKey);
    }, [themeKey]);

    return (
        <ThemeContext.Provider value={{ themeKey, setThemeKey, themes: THEMES }}>
            {children}
        </ThemeContext.Provider>
    );
}

export function useTheme() {
    return useContext(ThemeContext);
}
