import { createContext, useContext, useState, useEffect } from "react";
import { translations } from "@/i18n/translations";

const LanguageContext = createContext();

export function LanguageProvider({ children }) {
    const [lang, setLang] = useState(() => localStorage.getItem("dilse_lang") || "en");

    useEffect(() => {
        localStorage.setItem("dilse_lang", lang);
        // Set lang attribute on html element for accessibility / fonts
        document.documentElement.lang = lang;
        // RTL direction for Urdu
        document.documentElement.dir = lang === "ur" ? "rtl" : "ltr";
    }, [lang]);

    const t = (path) => {
        const keys = path.split(".");
        let value = translations[lang];
        for (const k of keys) {
            value = value?.[k];
            if (value === undefined) return path;
        }
        return value;
    };

    const toggleLang = () => setLang(lang === "en" ? "ur" : "en");

    return (
        <LanguageContext.Provider value={{ lang, setLang, toggleLang, t, isRtl: lang === "ur" }}>
            {children}
        </LanguageContext.Provider>
    );
}

export function useLang() {
    return useContext(LanguageContext);
}
