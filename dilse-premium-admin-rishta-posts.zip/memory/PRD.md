# DilSe - Premium Rishta & Dating App - PRD

## Original Problem Statement
Build a full premium Rishta + Dating web application called "DilSe" with luxury dark UI (neon pink, purple, orange glow), glassmorphism cards, premium animations. Includes authentication, user profiles with photos/voice intros, dual modes (Dating + Rishta), AI matchmaking, premium membership, chat with voice notes, admin dashboard.

## Architecture
- **Frontend**: React 19 + Tailwind CSS + Framer Motion + Lucide Icons (built on CRA template)
- **Backend**: FastAPI (Python) + Motor (async MongoDB) + JWT (HS256) + bcrypt
- **Database**: MongoDB
- **Integrations**:
  - OpenAI GPT-5.4-mini via Emergent Universal Key (AI compatibility insights)
  - Emergent Object Storage (photos, voice intros, voice messages)
  - Stripe Checkout (Premium subscriptions: $9.99/mo, $24.99/quarter, $79.99/year)
- **Auth**: JWT with httpOnly cookie + Bearer header fallback

## User Personas
1. **Dating User**: Modern South Asian singles, swipe-focused, casual dating
2. **Rishta User**: Marriage-minded, family-involved, traditional values (Wali approval)
3. **Premium Member**: Wants unlimited likes, see who liked them, advanced filters
4. **Admin**: Manages platform, verifies users, handles reports

## What's Been Implemented (Feb 2026 - v1.0)
### Backend (all under /api)
- Auth: register, login, logout, me, forgot-password, reset-password
- Profile: get/put profile, photo upload/delete, voice intro upload
- Discover: filtered profile discovery, swipe (like/pass/superlike), match creation, daily like limit (20 for free)
- Likes/Visitors: who liked you (blurred for free), profile visitors (skips when invisible_browsing)
- Matches: list with last message preview
- Messages: text + voice notes, polling-based 3s refresh, read receipts
- AI: compatibility scoring (interests/education/religion/lifestyle/personality) + GPT insight, AI recommendations ranked by compatibility
- Rishta Requests: send, list incoming/outgoing, accept/reject (creates match)
- Premium: list plans, Stripe checkout session, status polling, webhook
- Admin: stats, user list+search, verify/ban/unban/grant_premium actions, RBAC

### Frontend Pages
- LandingPage (hero, features, testimonials, CTA)
- LoginPage, RegisterPage, ForgotPasswordPage, ResetPasswordPage
- DashboardPage (hero, quick actions, recommendations, profile completeness, activity)
- DiscoverPage (swipe cards with framer-motion drag, dating/rishta mode toggle, filters)
- AIMatchPage (recommendations grid with compatibility breakdown + AI insight modal)
- ProfileDetailPage (photo gallery, voice intro player, info, action buttons)
- MyProfilePage (edit info, photo gallery upload, voice intro recording, interests picker)
- ChatListPage, ChatPage (text + voice messages, polling)
- LikesPage (blurred for free, full for premium)
- VisitorsPage
- RishtaRequestsPage (incoming/outgoing tabs, accept/reject)
- PremiumPage (3 plans, checkout flow)
- PremiumSuccessPage (Stripe success polling)
- AdminPage (stats grid, user management table)

### Design
- Luxury dark theme: #09090b base
- Neon pink (#FF2A85), purple (#8B5CF6), orange (#FF7A00) gradients
- Glassmorphism (backdrop-blur-2xl, bg-white/5)
- Outfit (headings) + Manrope (body) fonts
- Framer Motion page transitions and card animations
- Mobile responsive with bottom nav

## Test Status
- Backend tests: 26/26 PASSED (100%) - includes auth, profile, discover, swipe, matches, messages, AI, rishta requests, premium checkout, admin RBAC, daily like limit, banned user blocking
- Frontend: rendered successfully, login flow verified

## Test Credentials
- Admin: `admin@dilse.app` / `DilSeAdmin@2026`
- Register new test users via `/register`

## Backlog (P1 - Next Phase)
- WebSocket-based real-time chat (currently polls every 3s)
- Email service integration (Resend/SendGrid) for verification + password reset emails
- Push notifications for new matches/messages
- Profile boost scheduling (premium feature)
- Photo verification flow
- Family details deep form (Rishta mode)
- Stripe subscription management (cancel, resume)
- Voice intro playback in chat (currently shows waveform only)

## Backlog (P2)
- Multi-language support (Urdu, Hindi, English)
- Compatibility horoscope (if culturally appropriate)
- Event meetups
- Story sharing (24h photos)
- Block & report flow with admin moderation queue

## Deployment Notes
See `/app/DEPLOYMENT.md` for Hostinger Business deployment guide.
