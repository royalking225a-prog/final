import os
import pytest
import requests
import uuid

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://dilse-premium.preview.emergentagent.com").rstrip("/")

ADMIN_EMAIL = "admin@dilse.app"
ADMIN_PASSWORD = "DilSeAdmin@2026"


@pytest.fixture(scope="session")
def base_url():
    return BASE_URL


@pytest.fixture()
def api_client():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


def _register(client, email, password, name, age, gender):
    return client.post(f"{BASE_URL}/api/auth/register", json={
        "email": email, "password": password, "name": name, "age": age, "gender": gender
    })


@pytest.fixture(scope="session")
def male_user():
    """Create or use a persistent male test user for the session."""
    email = f"test_male_{uuid.uuid4().hex[:8]}@dilse.app"
    password = "TestUser@2026"
    s = requests.Session()
    r = s.post(f"{BASE_URL}/api/auth/register", json={
        "email": email, "password": password, "name": "Aman Male", "age": 28, "gender": "male"
    })
    assert r.status_code == 200, r.text
    data = r.json()
    return {"email": email, "password": password, "token": data["token"], "user": data["user"]}


@pytest.fixture(scope="session")
def female_user():
    email = f"test_female_{uuid.uuid4().hex[:8]}@dilse.app"
    password = "TestUser@2026"
    s = requests.Session()
    r = s.post(f"{BASE_URL}/api/auth/register", json={
        "email": email, "password": password, "name": "Sara Female", "age": 26, "gender": "female"
    })
    assert r.status_code == 200, r.text
    data = r.json()
    return {"email": email, "password": password, "token": data["token"], "user": data["user"]}


@pytest.fixture()
def male_client(male_user):
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json", "Authorization": f"Bearer {male_user['token']}"})
    return s


@pytest.fixture()
def female_client(female_user):
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json", "Authorization": f"Bearer {female_user['token']}"})
    return s


@pytest.fixture(scope="session")
def admin_token():
    s = requests.Session()
    r = s.post(f"{BASE_URL}/api/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    assert r.status_code == 200, f"Admin login failed: {r.text}"
    return r.json()["token"]


@pytest.fixture()
def admin_client(admin_token):
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json", "Authorization": f"Bearer {admin_token}"})
    return s
