"""DilSe Backend API tests covering all endpoints in scope."""
import os
import uuid
import requests
import pytest

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://dilse-premium.preview.emergentagent.com").rstrip("/")


# ============ ROOT / HEALTH ============
class TestRoot:
    def test_root(self, api_client):
        r = api_client.get(f"{BASE_URL}/api/")
        assert r.status_code == 200
        assert r.json().get("app") == "DilSe"


# ============ AUTH ============
class TestAuth:
    def test_register_login_me_logout(self, api_client):
        email = f"test_auth_{uuid.uuid4().hex[:8]}@dilse.app"
        pwd = "Pass@1234"
        r = api_client.post(f"{BASE_URL}/api/auth/register", json={
            "email": email, "password": pwd, "name": "Auth User", "age": 25, "gender": "male"
        })
        assert r.status_code == 200, r.text
        body = r.json()
        assert "token" in body and "user" in body
        assert body["user"]["email"] == email
        token = body["token"]

        # duplicate register
        r2 = api_client.post(f"{BASE_URL}/api/auth/register", json={
            "email": email, "password": pwd, "name": "Dup", "age": 25, "gender": "male"
        })
        assert r2.status_code == 400

        # login
        r3 = api_client.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": pwd})
        assert r3.status_code == 200
        new_token = r3.json()["token"]

        # me with Bearer
        r4 = requests.get(f"{BASE_URL}/api/auth/me", headers={"Authorization": f"Bearer {new_token}"})
        assert r4.status_code == 200
        assert r4.json()["user"]["email"] == email

        # invalid login
        r5 = api_client.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": "wrong"})
        assert r5.status_code == 401

        # logout
        r6 = requests.post(f"{BASE_URL}/api/auth/logout", headers={"Authorization": f"Bearer {new_token}"})
        assert r6.status_code == 200

        # me without token
        r7 = requests.get(f"{BASE_URL}/api/auth/me")
        assert r7.status_code == 401

    def test_forgot_and_reset_password(self, api_client):
        # forgot for nonexistent → still ok (no enumeration)
        r = api_client.post(f"{BASE_URL}/api/auth/forgot-password", json={"email": "nobody_xyz@dilse.app"})
        assert r.status_code == 200
        # reset with bad token
        r2 = api_client.post(f"{BASE_URL}/api/auth/reset-password", json={"token": "bad", "new_password": "x"})
        assert r2.status_code == 400


# ============ PROFILE ============
class TestProfile:
    def test_update_profile(self, male_client, male_user):
        r = male_client.put(f"{BASE_URL}/api/profile", json={
            "city": "Karachi", "profession": "Engineer", "education": "MS",
            "interests": ["cricket", "music"], "bio": "Love tech", "mode": "rishta",
            "looking_for": "rishta", "religion": "Islam"
        })
        assert r.status_code == 200
        user = r.json()["user"]
        assert user["city"] == "Karachi"
        assert user["profession"] == "Engineer"
        assert user["mode"] == "rishta"
        assert "cricket" in user["interests"]

    def test_get_profile_with_match_flags(self, female_client, male_user):
        r = female_client.get(f"{BASE_URL}/api/profile/{male_user['user']['id']}")
        assert r.status_code == 200
        body = r.json()
        assert body["id"] == male_user["user"]["id"]
        assert "is_matched" in body and "i_liked" in body

    def test_get_profile_not_found(self, male_client):
        r = male_client.get(f"{BASE_URL}/api/profile/{uuid.uuid4()}")
        assert r.status_code == 404


# ============ FILES (auth check only - skip actual upload to avoid storage dependency) ============
class TestFiles:
    def test_files_requires_auth(self, api_client):
        r = api_client.get(f"{BASE_URL}/api/files/some/path")
        assert r.status_code == 401


# ============ DISCOVER / SWIPE / MATCH ============
class TestDiscoverSwipeMatch:
    def test_discover(self, male_client):
        r = male_client.get(f"{BASE_URL}/api/discover", params={"mode": "dating", "min_age": 18, "max_age": 99})
        assert r.status_code == 200
        assert "profiles" in r.json()
        assert isinstance(r.json()["profiles"], list)

    def test_swipe_and_match(self, male_client, female_client, male_user, female_user):
        # male likes female
        r1 = male_client.post(f"{BASE_URL}/api/swipe", json={
            "target_user_id": female_user["user"]["id"], "action": "like"
        })
        assert r1.status_code == 200, r1.text
        assert r1.json()["is_match"] is False

        # female likes male back → match
        r2 = female_client.post(f"{BASE_URL}/api/swipe", json={
            "target_user_id": male_user["user"]["id"], "action": "like"
        })
        assert r2.status_code == 200, r2.text
        assert r2.json()["is_match"] is True
        assert r2.json()["match_id"]

    def test_likes_received_non_premium(self, female_client):
        r = female_client.get(f"{BASE_URL}/api/likes/received")
        assert r.status_code == 200
        body = r.json()
        assert body["blurred"] is True
        assert isinstance(body["count"], int)

    def test_visitors(self, male_client):
        r = male_client.get(f"{BASE_URL}/api/visitors")
        assert r.status_code == 200
        assert "profiles" in r.json()

    def test_matches_list(self, male_client):
        r = male_client.get(f"{BASE_URL}/api/matches")
        assert r.status_code == 200
        assert "matches" in r.json()


# ============ MESSAGES ============
class TestMessages:
    def test_send_and_get_messages(self, male_client, female_client):
        # Get match id
        r = male_client.get(f"{BASE_URL}/api/matches")
        matches = r.json()["matches"]
        assert len(matches) >= 1, "Need an active match (run swipe test first)"
        match_id = matches[0]["match_id"]
        # send msg
        r2 = male_client.post(f"{BASE_URL}/api/messages", json={
            "match_id": match_id, "text": "Hello!", "type": "text"
        })
        assert r2.status_code == 200, r2.text
        assert r2.json()["text"] == "Hello!"

        # get messages
        r3 = female_client.get(f"{BASE_URL}/api/messages/{match_id}")
        assert r3.status_code == 200
        msgs = r3.json()["messages"]
        assert any(m["text"] == "Hello!" for m in msgs)

    def test_message_unauthorized(self, male_client):
        r = male_client.post(f"{BASE_URL}/api/messages", json={
            "match_id": str(uuid.uuid4()), "text": "x", "type": "text"
        })
        assert r.status_code == 403


# ============ AI MATCHMAKING ============
class TestAI:
    def test_compatibility(self, male_client, female_user):
        r = male_client.post(f"{BASE_URL}/api/ai/compatibility", json={
            "target_user_id": female_user["user"]["id"]
        })
        assert r.status_code == 200, r.text
        body = r.json()
        assert "compatibility" in body
        assert "overall" in body["compatibility"]
        assert "breakdown" in body["compatibility"]
        assert body["insight"]  # may be AI or fallback

    def test_recommendations(self, male_client):
        r = male_client.get(f"{BASE_URL}/api/ai/recommendations")
        assert r.status_code == 200
        assert "recommendations" in r.json()


# ============ RISHTA REQUESTS ============
class TestRishta:
    def test_rishta_flow(self, api_client):
        # Use fresh users so we don't conflict with existing match
        em1 = f"test_rishta_a_{uuid.uuid4().hex[:8]}@dilse.app"
        em2 = f"test_rishta_b_{uuid.uuid4().hex[:8]}@dilse.app"
        u1 = api_client.post(f"{BASE_URL}/api/auth/register", json={
            "email": em1, "password": "Pass@1234", "name": "Rishta A", "age": 30, "gender": "male"
        }).json()
        u2 = api_client.post(f"{BASE_URL}/api/auth/register", json={
            "email": em2, "password": "Pass@1234", "name": "Rishta B", "age": 27, "gender": "female"
        }).json()
        h1 = {"Authorization": f"Bearer {u1['token']}"}
        h2 = {"Authorization": f"Bearer {u2['token']}"}

        # send request
        r = requests.post(f"{BASE_URL}/api/rishta/request",
                          headers=h1,
                          json={"target_user_id": u2["user"]["id"], "message": "Marriage proposal"})
        assert r.status_code == 200, r.text
        req_id = r.json()["id"]

        # duplicate → 400
        r_dup = requests.post(f"{BASE_URL}/api/rishta/request",
                              headers=h1,
                              json={"target_user_id": u2["user"]["id"]})
        assert r_dup.status_code == 400

        # list
        r2 = requests.get(f"{BASE_URL}/api/rishta/requests", headers=h2)
        assert r2.status_code == 200
        assert any(x["id"] == req_id for x in r2.json()["incoming"])

        # accept
        r3 = requests.put(f"{BASE_URL}/api/rishta/request/{req_id}?status=accepted", headers=h2)
        assert r3.status_code == 200

        # invalid status
        r4 = requests.put(f"{BASE_URL}/api/rishta/request/{req_id}?status=foo", headers=h2)
        assert r4.status_code == 400


# ============ PREMIUM ============
class TestPremium:
    def test_plans(self, api_client):
        r = api_client.get(f"{BASE_URL}/api/premium/plans")
        assert r.status_code == 200
        plans = r.json()["plans"]
        ids = [p["id"] for p in plans]
        assert "monthly" in ids and "yearly" in ids

    def test_checkout_invalid_plan(self, male_client):
        r = male_client.post(f"{BASE_URL}/api/premium/checkout", json={
            "plan_id": "bogus", "origin_url": "https://dilse-premium.preview.emergentagent.com"
        })
        assert r.status_code == 400

    def test_checkout_creates_session(self, male_client):
        r = male_client.post(f"{BASE_URL}/api/premium/checkout", json={
            "plan_id": "monthly", "origin_url": "https://dilse-premium.preview.emergentagent.com"
        })
        # Accept either valid 200 or 500 (test stripe key may fail)
        if r.status_code != 200:
            pytest.skip(f"Stripe checkout failed (likely test key): {r.text}")
        body = r.json()
        assert "url" in body and "session_id" in body


# ============ ADMIN ============
class TestAdmin:
    def test_admin_login(self, admin_token):
        assert admin_token

    def test_admin_stats(self, admin_client):
        r = admin_client.get(f"{BASE_URL}/api/admin/stats")
        assert r.status_code == 200
        body = r.json()
        for k in ["total_users", "premium_users", "total_matches", "total_messages", "total_revenue"]:
            assert k in body

    def test_admin_users(self, admin_client):
        r = admin_client.get(f"{BASE_URL}/api/admin/users", params={"q": "test"})
        assert r.status_code == 200
        assert "users" in r.json()

    def test_admin_actions(self, admin_client, api_client):
        # Create a user to act on
        em = f"test_admin_target_{uuid.uuid4().hex[:8]}@dilse.app"
        u = api_client.post(f"{BASE_URL}/api/auth/register", json={
            "email": em, "password": "Pass@1234", "name": "Admin Target", "age": 25, "gender": "male"
        }).json()
        uid = u["user"]["id"]

        # verify
        r1 = admin_client.put(f"{BASE_URL}/api/admin/users/{uid}?action=verify")
        assert r1.status_code == 200
        # ban
        r2 = admin_client.put(f"{BASE_URL}/api/admin/users/{uid}?action=ban")
        assert r2.status_code == 200
        # banned login should be 403
        r_login = api_client.post(f"{BASE_URL}/api/auth/login", json={"email": em, "password": "Pass@1234"})
        assert r_login.status_code == 403
        # unban
        r3 = admin_client.put(f"{BASE_URL}/api/admin/users/{uid}?action=unban")
        assert r3.status_code == 200
        # grant premium
        r4 = admin_client.put(f"{BASE_URL}/api/admin/users/{uid}?action=grant_premium")
        assert r4.status_code == 200
        # invalid action
        r5 = admin_client.put(f"{BASE_URL}/api/admin/users/{uid}?action=invalid")
        assert r5.status_code == 400

    def test_admin_route_forbidden_for_regular_user(self, male_client):
        r = male_client.get(f"{BASE_URL}/api/admin/stats")
        assert r.status_code == 403


# ============ DAILY LIKE LIMIT ============
class TestRateLimit:
    def test_like_limit_for_non_premium(self, api_client):
        # Create a fresh non-premium user
        em = f"test_limit_{uuid.uuid4().hex[:8]}@dilse.app"
        u = api_client.post(f"{BASE_URL}/api/auth/register", json={
            "email": em, "password": "Pass@1234", "name": "Limit User", "age": 28, "gender": "male"
        }).json()
        h = {"Authorization": f"Bearer {u['token']}"}

        # Hit 20 likes against random ids, then expect 403
        last_status = None
        for i in range(21):
            tid = str(uuid.uuid4())
            rr = requests.post(f"{BASE_URL}/api/swipe", headers=h,
                               json={"target_user_id": tid, "action": "like"})
            last_status = rr.status_code
            if rr.status_code == 403:
                break
        assert last_status == 403, "Daily like limit not enforced for non-premium"
