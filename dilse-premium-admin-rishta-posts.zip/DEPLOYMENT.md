# DilSe Deployment Guide - Hostinger Business Hosting

## Stack
- Backend: FastAPI (Python 3.11) on port 8001
- Frontend: React build (static files served by web server)
- Database: MongoDB (local or MongoDB Atlas)

## Pre-Deployment Checklist
1. Get a MongoDB instance (Atlas free tier works great): https://cloud.mongodb.com
2. Get a Stripe live API key (replace test key)
3. Choose a domain (e.g., dilse.app)
4. Get SSL certificate (Hostinger provides free Let's Encrypt)

## Backend Deployment (Hostinger Business Node.js / Python VPS)

### Option A: Hostinger VPS (Recommended)
1. SSH into your Hostinger VPS
2. Install Python 3.11 and pip:
   ```bash
   sudo apt update && sudo apt install python3.11 python3.11-venv python3-pip nginx -y
   ```
3. Clone your repo:
   ```bash
   git clone <your-repo> /var/www/dilse
   cd /var/www/dilse/backend
   python3.11 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
4. Create `/var/www/dilse/backend/.env`:
   ```
   MONGO_URL="mongodb+srv://user:pass@cluster.mongodb.net"
   DB_NAME="dilse_production"
   CORS_ORIGINS="https://dilse.app"
   JWT_SECRET="<generate-64-char-hex>"
   ADMIN_EMAIL="admin@dilse.app"
   ADMIN_PASSWORD="<strong-password>"
   EMERGENT_LLM_KEY="<your-key>"
   STRIPE_API_KEY="sk_live_..."
   APP_NAME="dilse"
   ```
5. Create systemd service `/etc/systemd/system/dilse-backend.service`:
   ```ini
   [Unit]
   Description=DilSe FastAPI Backend
   After=network.target
   
   [Service]
   User=www-data
   WorkingDirectory=/var/www/dilse/backend
   Environment="PATH=/var/www/dilse/backend/venv/bin"
   ExecStart=/var/www/dilse/backend/venv/bin/uvicorn server:app --host 0.0.0.0 --port 8001 --workers 4
   Restart=always
   
   [Install]
   WantedBy=multi-user.target
   ```
6. Start: `sudo systemctl enable --now dilse-backend`

### Option B: Hostinger Business Hosting (cPanel/Python App)
1. Create new Python application in cPanel
2. Set Python version to 3.11
3. Upload backend files
4. Set startup file: `server.py` and application entry: `app`
5. Install requirements via cPanel UI
6. Add environment variables (same as Option A)

## Frontend Deployment (Static Files)
1. Build production:
   ```bash
   cd /var/www/dilse/frontend
   # Edit .env: REACT_APP_BACKEND_URL=https://api.dilse.app
   yarn install
   yarn build
   ```
2. Copy `build/` contents to your web root (e.g., `/var/www/html/`)
3. Configure nginx for SPA routing:
   ```nginx
   server {
     listen 443 ssl http2;
     server_name dilse.app www.dilse.app;
     root /var/www/html;
     index index.html;
     
     # SSL config (Let's Encrypt managed by Hostinger)
     ssl_certificate /etc/letsencrypt/live/dilse.app/fullchain.pem;
     ssl_certificate_key /etc/letsencrypt/live/dilse.app/privkey.pem;
     
     # SPA fallback
     location / {
       try_files $uri $uri/ /index.html;
     }
     
     # API proxy to backend
     location /api/ {
       proxy_pass http://localhost:8001;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
     }
   }
   ```
4. Test config: `sudo nginx -t && sudo systemctl reload nginx`

## DNS Setup
- A record: `dilse.app` → your VPS IP
- A record: `www.dilse.app` → your VPS IP
- (optional) A record: `api.dilse.app` → your VPS IP if you separate API subdomain

## Stripe Webhook
1. In Stripe dashboard: Developers → Webhooks → Add endpoint
2. URL: `https://dilse.app/api/webhook/stripe`
3. Select events: `checkout.session.completed`, `checkout.session.expired`

## MongoDB Indexes (auto-created on startup)
- users.email (unique)
- users.id (unique)
- swipes (user_id, target_user_id)
- matches (user_a, user_b)
- messages (match_id, created_at)

## Post-Deployment Smoke Test
```bash
curl https://dilse.app/api/
curl -X POST https://dilse.app/api/auth/login -H "Content-Type: application/json" -d '{"email":"admin@dilse.app","password":"<your-pw>"}'
```

## Maintenance
- Logs: `sudo journalctl -u dilse-backend -f`
- Restart backend: `sudo systemctl restart dilse-backend`
- Update code: `git pull && sudo systemctl restart dilse-backend`
- Frontend rebuild: `cd frontend && yarn build && cp -r build/* /var/www/html/`

## Security Notes
- Use strong JWT_SECRET (64+ random hex chars)
- Use Stripe live keys only in production
- Enable HTTPS only (HSTS recommended)
- Set strong ADMIN_PASSWORD
- Backup MongoDB regularly (mongodump or Atlas automated backups)
- Rotate JWT secret periodically (forces re-login)
