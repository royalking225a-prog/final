import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { LanguageProvider } from "@/context/LanguageContext";
import { BrandingProvider } from "@/context/BrandingContext";
import { ThemeProvider } from "@/context/ThemeContext";
import PopupRenderer from "@/components/PopupRenderer";
import { Toaster } from "sonner";

import LandingPage from "@/pages/LandingPage";
import LoginPage from "@/pages/LoginPage";
import RegisterPage from "@/pages/RegisterPage";
import ForgotPasswordPage from "@/pages/ForgotPasswordPage";
import ResetPasswordPage from "@/pages/ResetPasswordPage";
import DashboardPage from "@/pages/DashboardPage";
import DiscoverPage from "@/pages/DiscoverPage";
import AIMatchPage from "@/pages/AIMatchPage";
import ProfileDetailPage from "@/pages/ProfileDetailPage";
import MyProfilePage from "@/pages/MyProfilePage";
import ChatListPage from "@/pages/ChatListPage";
import ChatPage from "@/pages/ChatPage";
import PremiumPage from "@/pages/PremiumPage";
import PremiumSuccessPage from "@/pages/PremiumSuccessPage";
import AdminPage from "@/pages/AdminPage";
import LikesPage from "@/pages/LikesPage";
import VisitorsPage from "@/pages/VisitorsPage";
import RishtaRequestsPage from "@/pages/RishtaRequestsPage";

function ProtectedRoute({ children, adminOnly = false }) {
    const { user, loading } = useAuth();
    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-[#09090b]">
                <div className="w-12 h-12 rounded-full border-2 border-[#FF2A85] border-t-transparent animate-spin" />
            </div>
        );
    }
    if (!user) return <Navigate to="/login" replace />;
    if (adminOnly && user.role !== "admin") return <Navigate to="/dashboard" replace />;
    return children;
}

function App() {
    return (
        <div className="App">
            <LanguageProvider>
                <BrandingProvider>
                <ThemeProvider>
                <AuthProvider>
                <BrowserRouter>
                    <Toaster position="top-center" theme="dark" richColors />
                    <PopupRenderer />
                    <Routes>
                        <Route path="/" element={<LandingPage />} />
                        <Route path="/login" element={<LoginPage />} />
                        <Route path="/register" element={<RegisterPage />} />
                        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
                        <Route path="/reset-password" element={<ResetPasswordPage />} />
                        <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
                        <Route path="/discover" element={<ProtectedRoute><DiscoverPage /></ProtectedRoute>} />
                        <Route path="/ai-match" element={<ProtectedRoute><AIMatchPage /></ProtectedRoute>} />
                        <Route path="/profile/me" element={<ProtectedRoute><MyProfilePage /></ProtectedRoute>} />
                        <Route path="/profile/:userId" element={<ProtectedRoute><ProfileDetailPage /></ProtectedRoute>} />
                        <Route path="/messages" element={<ProtectedRoute><ChatListPage /></ProtectedRoute>} />
                        <Route path="/messages/:matchId" element={<ProtectedRoute><ChatPage /></ProtectedRoute>} />
                        <Route path="/likes" element={<ProtectedRoute><LikesPage /></ProtectedRoute>} />
                        <Route path="/visitors" element={<ProtectedRoute><VisitorsPage /></ProtectedRoute>} />
                        <Route path="/rishta-requests" element={<ProtectedRoute><RishtaRequestsPage /></ProtectedRoute>} />
                        <Route path="/premium" element={<ProtectedRoute><PremiumPage /></ProtectedRoute>} />
                        <Route path="/premium/success" element={<ProtectedRoute><PremiumSuccessPage /></ProtectedRoute>} />
                        <Route path="/admin" element={<ProtectedRoute adminOnly><AdminPage /></ProtectedRoute>} />
                    </Routes>
                </BrowserRouter>
            </AuthProvider>
            </ThemeProvider>
            </BrandingProvider>
            </LanguageProvider>
        </div>
    );
}

export default App;
