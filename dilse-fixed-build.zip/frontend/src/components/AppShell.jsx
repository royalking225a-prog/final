import { Link, useLocation, useNavigate } from "react-router-dom";
import { Heart, Compass, Sparkles, MessageCircle, Users, Eye, Crown, Settings, LogOut, Shield, Home, Mic, Calendar, Bookmark, Bell } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { fileUrl } from "@/lib/api";
import { motion } from "framer-motion";
import BrandLogo from "@/components/BrandLogo";

const navItems = [
    { to: "/dashboard", label: "Dashboard", icon: Home, testid: "nav-dashboard" },
    { to: "/discover", label: "Discover", icon: Compass, testid: "nav-discover" },
    { to: "/ai-match", label: "AI Matchmaker", icon: Sparkles, testid: "nav-ai-match", badge: "New" },
    { to: "/likes", label: "Likes", icon: Heart, testid: "nav-likes" },
    { to: "/messages", label: "Messages", icon: MessageCircle, testid: "nav-messages" },
    { to: "/visitors", label: "Visitors", icon: Eye, testid: "nav-visitors" },
    { to: "/rishta-requests", label: "Rishta Requests", icon: Users, testid: "nav-rishta" },
    { to: "/premium", label: "Premium", icon: Crown, testid: "nav-premium" },
];

export default function AppShell({ children, hideSidebar = false }) {
    const location = useLocation();
    const navigate = useNavigate();
    const { user, logout } = useAuth();

    const handleLogout = async () => {
        await logout();
        navigate("/");
    };

    return (
        <div className="min-h-screen flex bg-[#09090b] text-white">
            {/* Sidebar */}
            {!hideSidebar && (
                <aside data-testid="app-sidebar" className="hidden lg:flex flex-col w-72 border-r border-white/5 p-4 sticky top-0 h-screen overflow-y-auto">
                    <Link to="/dashboard" data-testid="sidebar-logo" className="block mb-2 px-3 py-4">
                        <BrandLogo size="md" />
                    </Link>

                    <nav className="flex-1 mt-4 space-y-1">
                        {navItems.map((item) => {
                            const isActive = location.pathname === item.to || (item.to !== "/dashboard" && location.pathname.startsWith(item.to));
                            return (
                                <Link
                                    key={item.to}
                                    to={item.to}
                                    data-testid={item.testid}
                                    className={`flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-200 group ${
                                        isActive
                                            ? "bg-gradient-to-r from-[#FF2A85]/20 to-[#8B5CF6]/10 border border-[#FF2A85]/30 text-white"
                                            : "text-zinc-400 hover:text-white hover:bg-white/5"
                                    }`}
                                >
                                    <item.icon className={`w-5 h-5 ${isActive ? "text-[#FF2A85]" : ""}`} />
                                    <span className="font-medium text-sm flex-1">{item.label}</span>
                                    {item.badge && (
                                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#FF2A85] text-white">
                                            {item.badge}
                                        </span>
                                    )}
                                </Link>
                            );
                        })}
                        {user?.role === "admin" && (
                            <Link to="/admin" data-testid="nav-admin" className="flex items-center gap-3 px-4 py-3 rounded-2xl text-zinc-400 hover:text-white hover:bg-white/5 transition-all">
                                <Shield className="w-5 h-5" />
                                <span className="font-medium text-sm">Admin</span>
                            </Link>
                        )}
                    </nav>

                    {/* Upgrade Card */}
                    {!user?.premium && (
                        <motion.div
                            data-testid="sidebar-upgrade-card"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="mt-4 p-5 rounded-3xl bg-gradient-to-br from-[#FF2A85]/15 via-[#8B5CF6]/10 to-transparent border border-[#FF2A85]/25 relative overflow-hidden"
                        >
                            <div className="flex items-center gap-2 mb-2">
                                <Crown className="w-5 h-5 text-[#FFB800]" />
                                <span className="font-['Outfit'] font-bold text-base">Upgrade to Premium</span>
                            </div>
                            <p className="text-xs text-zinc-400 mb-3">Unlock all premium features</p>
                            <ul className="space-y-1.5 mb-4">
                                {["Unlimited Likes", "See Who Likes You", "Advanced Filters", "Private Photos"].map((f) => (
                                    <li key={f} className="flex items-center gap-2 text-xs text-zinc-300">
                                        <div className="w-1.5 h-1.5 rounded-full bg-[#FF2A85]" />
                                        {f}
                                    </li>
                                ))}
                            </ul>
                            <Link to="/premium" data-testid="sidebar-upgrade-btn" className="block text-center btn-primary text-sm py-2.5">
                                Upgrade Now
                            </Link>
                        </motion.div>
                    )}

                    {/* User Block */}
                    <button
                        onClick={handleLogout}
                        data-testid="logout-btn"
                        className="mt-4 flex items-center gap-3 px-4 py-3 rounded-2xl text-zinc-500 hover:text-red-400 hover:bg-red-500/5 transition-all text-sm"
                    >
                        <LogOut className="w-4 h-4" />
                        <span>Logout</span>
                    </button>
                </aside>
            )}

            {/* Main Content */}
            <main className="flex-1 min-h-screen overflow-x-hidden">
                {/* Top Bar */}
                <header data-testid="app-topbar" className="sticky top-0 z-30 backdrop-blur-xl bg-[#09090b]/70 border-b border-white/5 px-4 sm:px-8 py-4 flex items-center justify-between">
                    <div className="flex items-center gap-3 lg:hidden">
                        <Link to="/dashboard" className="block">
                            <BrandLogo size="sm" showText={true} />
                        </Link>
                    </div>

                    <div className="hidden lg:flex flex-1 max-w-lg">
                        <div className="relative w-full">
                            <input
                                data-testid="topbar-search"
                                type="text"
                                placeholder="Search by name, city, education..."
                                className="input-dark pl-12"
                            />
                            <Compass className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" />
                        </div>
                    </div>

                    <div className="flex items-center gap-3">
                        {!user?.premium && (
                            <Link to="/premium" data-testid="topbar-upgrade-btn" className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-full neon-gradient text-white text-sm font-semibold hover:shadow-lg hover:shadow-pink-500/30 transition-all">
                                <Crown className="w-4 h-4" />
                                Upgrade Premium
                            </Link>
                        )}
                        <button data-testid="topbar-notifications" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-white/10 transition-colors">
                            <Bell className="w-4 h-4 text-zinc-300" />
                        </button>
                        <Link to="/profile/me" data-testid="topbar-profile-link" className="flex items-center gap-2.5 pl-1 pr-3 py-1 rounded-full glass hover:bg-white/10 transition-colors">
                            <div className="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-br from-[#FF2A85] to-[#8B5CF6] flex items-center justify-center font-bold text-sm">
                                {user?.photos?.[0]?.path ? (
                                    <img src={fileUrl(user.photos[0].path)} alt="me" className="w-full h-full object-cover" />
                                ) : (
                                    (user?.name || "U")[0].toUpperCase()
                                )}
                            </div>
                            <div className="hidden sm:block text-left">
                                <div className="text-sm font-semibold leading-tight">{user?.name}</div>
                                <div className="text-[10px] text-zinc-500">{user?.premium ? "Premium" : "Member"}</div>
                            </div>
                        </Link>
                    </div>
                </header>

                {/* Page Content */}
                <div className="px-4 sm:px-6 lg:px-8 py-6 lg:py-8">{children}</div>

                {/* Mobile Bottom Nav */}
                <nav data-testid="mobile-bottom-nav" className="lg:hidden fixed bottom-0 left-0 right-0 z-30 backdrop-blur-xl bg-[#09090b]/80 border-t border-white/5 flex items-center justify-around py-2.5">
                    {[
                        { to: "/dashboard", icon: Home, label: "Home" },
                        { to: "/discover", icon: Compass, label: "Discover" },
                        { to: "/ai-match", icon: Sparkles, label: "AI" },
                        { to: "/messages", icon: MessageCircle, label: "Chat" },
                        { to: "/profile/me", icon: Heart, label: "Me" },
                    ].map((item) => {
                        const isActive = location.pathname === item.to;
                        return (
                            <Link key={item.to} to={item.to} data-testid={`mobile-nav-${item.label.toLowerCase()}`} className={`flex flex-col items-center gap-1 px-3 py-1 ${isActive ? "text-[#FF2A85]" : "text-zinc-500"}`}>
                                <item.icon className="w-5 h-5" />
                                <span className="text-[10px] font-medium">{item.label}</span>
                            </Link>
                        );
                    })}
                </nav>
                <div className="lg:hidden h-16" />
            </main>
        </div>
    );
}
