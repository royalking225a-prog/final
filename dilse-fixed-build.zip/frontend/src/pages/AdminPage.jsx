import AdminHeroTab from "@/pages/AdminHeroTab";
import { useEffect, useState, useRef } from "react";
import AppShell from "@/components/AppShell";
import api, { fileUrl } from "@/lib/api";
import { Users, Crown, Shield, Ban, MessageCircle, DollarSign, Heart, Search, Upload, Image as ImageIcon, Save, Palette, Bell, CreditCard, Check, X, Trash2, Plus, AlertCircle, AlertTriangle, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { useBranding, resolveLogoUrl } from "@/context/BrandingContext";
import { useTheme, THEMES } from "@/context/ThemeContext";

const TABS = [
    { id: "overview", label: "Overview", icon: Users },
       { id: "hero", label: "Hero Slider", icon: ImageIcon },
    { id: "users", label: "Users", icon: Shield },
    { id: "payments", label: "Payments", icon: CreditCard },
    { id: "branding", label: "Branding", icon: ImageIcon },
    { id: "theme", label: "Theme", icon: Palette },
    { id: "popups", label: "Popups", icon: Bell },
];

export default function AdminPage() {
    const { branding, refreshBranding } = useBranding();
    const { themeKey, setThemeKey } = useTheme();
    const [tab, setTab] = useState("overview");
    const [stats, setStats] = useState(null);
    const [users, setUsers] = useState([]);
    const [payments, setPayments] = useState([]);
    const [popups, setPopups] = useState([]);
    const [q, setQ] = useState("");
    const [brandForm, setBrandForm] = useState({ brand_name: "", tagline: "" });
    const [popupForm, setPopupForm] = useState({ type: "promo", title: "", body: "", cta_label: "", cta_url: "", active: true, show_once: true });
    const logoFileRef = useRef();

    const loadOverview = async () => {
        const { data } = await api.get("/admin/stats");
        setStats(data);
    };
    const loadUsers = async () => {
        const { data } = await api.get(`/admin/users${q ? `?q=${encodeURIComponent(q)}` : ""}`);
        setUsers(data.users || []);
    };
    const loadPayments = async () => {
        const { data } = await api.get("/admin/payments");
        setPayments(data.submissions || []);
    };
    const loadPopups = async () => {
        const { data } = await api.get("/admin/popups");
        setPopups(data.popups || []);
    };

    useEffect(() => {
        loadOverview();
        loadUsers();
        loadPayments();
        loadPopups();
        // eslint-disable-next-line
    }, []);

    useEffect(() => {
        if (branding) setBrandForm({ brand_name: branding.brand_name || "", tagline: branding.tagline || "" });
    }, [branding]);

    const userAction = async (userId, act) => {
        try { await api.put(`/admin/users/${userId}?action=${act}`); toast.success("Updated"); await loadUsers(); } catch { toast.error("Failed"); }
    };
    const reviewPayment = async (id, act) => {
        try { await api.put(`/admin/payments/${id}?action=${act}`); toast.success(`${act === "approve" ? "Approved" : "Rejected"}`); await loadPayments(); await loadOverview(); } catch { toast.error("Failed"); }
    };
    const saveBrandText = async () => {
        try { await api.put("/admin/branding", brandForm); await refreshBranding(); toast.success("Saved"); } catch { toast.error("Failed"); }
    };
    const uploadLogo = async (e) => {
        const file = e.target.files?.[0]; if (!file) return;
        const fd = new FormData(); fd.append("file", file);
        try { await api.post("/admin/branding/upload", fd, { headers: { "Content-Type": "multipart/form-data" } }); await refreshBranding(); toast.success("Logo updated"); } catch { toast.error("Upload failed"); }
    };
    const createPopup = async () => {
        if (!popupForm.title || !popupForm.body) return toast.error("Title and body required");
        try { await api.post("/admin/popups", popupForm); toast.success("Popup created"); setPopupForm({ type: "promo", title: "", body: "", cta_label: "", cta_url: "", active: true, show_once: true }); await loadPopups(); } catch { toast.error("Failed"); }
    };
    const deletePopup = async (id) => {
        try { await api.delete(`/admin/popups/${id}`); toast.success("Deleted"); await loadPopups(); } catch { toast.error("Failed"); }
    };

    return (
        <AppShell>
            <div className="max-w-7xl mx-auto">
                <div className="mb-6">
                    <h1 className="font-['Outfit'] text-3xl font-bold mb-1">Admin Dashboard</h1>
                    <p className="text-sm text-zinc-400">Manage users, payments, branding, and platform health</p>
                </div>

                {/* Tabs */}
                <div className="flex items-center gap-1 mb-6 overflow-x-auto glass rounded-2xl p-1.5 w-fit">
                    {TABS.map((t) => (
                        <button key={t.id} data-testid={`admin-tab-${t.id}`} onClick={() => setTab(t.id)} className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${tab === t.id ? "neon-gradient text-white shadow-lg" : "text-zinc-400 hover:text-white"}`}>
                            <t.icon className="w-3.5 h-3.5" /> {t.label}
                        </button>
                    ))}
                </div>

                {/* OVERVIEW */}
                {tab === "hero" && <AdminHeroTab />}
          {tab === "overview" && stats && (
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
                        {[
                            { label: "Total Users", value: stats.total_users, icon: Users, color: "from-[#FF2A85] to-[#8B5CF6]" },
                            { label: "Verified", value: stats.verified_users, icon: Shield, color: "from-emerald-500 to-cyan-500" },
                            { label: "Premium", value: stats.premium_users, icon: Crown, color: "from-amber-500 to-orange-500" },
                            { label: "Banned", value: stats.banned_users, icon: Ban, color: "from-red-500 to-rose-500" },
                            { label: "Matches", value: stats.total_matches, icon: Heart, color: "from-pink-500 to-fuchsia-500" },
                            { label: "Messages", value: stats.total_messages, icon: MessageCircle, color: "from-violet-500 to-purple-500" },
                            { label: "Revenue", value: `$${stats.total_revenue}`, icon: DollarSign, color: "from-emerald-400 to-green-500" },
                        ].map((s) => (
                            <div key={s.label} data-testid={`stat-${s.label.toLowerCase().replace(/\s/g, "-")}`} className="glass rounded-2xl p-4">
                                <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${s.color} flex items-center justify-center mb-3`}>
                                    <s.icon className="w-4 h-4 text-white" />
                                </div>
                                <div className="text-2xl font-bold">{s.value}</div>
                                <div className="text-[10px] uppercase tracking-wider text-zinc-500 mt-0.5">{s.label}</div>
                            </div>
                        ))}
                    </div>
                )}

                {/* USERS */}
                {tab === "users" && (
                    <div>
                        <div className="flex items-center gap-3 mb-4">
                            <div className="relative flex-1 max-w-md">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                                <input data-testid="admin-search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or email..." className="input-dark pl-11" />
                            </div>
                            <button onClick={loadUsers} className="btn-primary text-sm">Search</button>
                        </div>
                        <div className="glass rounded-3xl overflow-hidden">
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead className="border-b border-white/5">
                                        <tr className="text-left text-[10px] uppercase tracking-[0.2em] text-zinc-500">
                                            <th className="p-4">User</th><th className="p-4">Email</th><th className="p-4">Age</th><th className="p-4">Status</th><th className="p-4 text-right">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {users.map((u) => (
                                            <tr key={u.id} className="border-b border-white/5 hover:bg-white/[0.02]">
                                                <td className="p-4"><div className="flex items-center gap-3"><div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#FF2A85] to-[#8B5CF6] flex items-center justify-center text-sm font-bold">{u.name?.[0]}</div><div><div className="font-bold">{u.name}</div><div className="text-[10px] text-zinc-500">{u.city || "—"}</div></div></div></td>
                                                <td className="p-4 text-zinc-400">{u.email}</td>
                                                <td className="p-4 text-zinc-400">{u.age}</td>
                                                <td className="p-4"><div className="flex flex-wrap gap-1">{u.role === "admin" && <Badge color="amber">Admin</Badge>}{u.verified && <Badge color="emerald">Verified</Badge>}{u.premium && <Badge color="pink">{u.premium_tier?.toUpperCase() || "Premium"}</Badge>}{u.banned && <Badge color="red">Banned</Badge>}</div></td>
                                                <td className="p-4"><div className="flex items-center justify-end gap-1.5">{!u.verified ? <button onClick={() => userAction(u.id, "verify")} className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">Verify</button> : <button onClick={() => userAction(u.id, "unverify")} className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-zinc-500/10 border border-zinc-500/20 text-zinc-400">Unverify</button>}{!u.premium && <button onClick={() => userAction(u.id, "grant_premium")} className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/10 border border-amber-500/20 text-amber-400">+Premium</button>}{!u.banned ? <button onClick={() => userAction(u.id, "ban")} className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-red-500/10 border border-red-500/20 text-red-400">Ban</button> : <button onClick={() => userAction(u.id, "unban")} className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">Unban</button>}</div></td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                )}

                {/* PAYMENTS */}
                {tab === "payments" && (
                    <div className="glass rounded-3xl overflow-hidden">
                        <div className="p-4 border-b border-white/5 flex items-center gap-2">
                            <CreditCard className="w-5 h-5 text-[#FF2A85]" />
                            <h2 className="font-['Outfit'] font-bold">Payment Verifications ({payments.filter(p => p.status === "pending").length} pending)</h2>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead className="border-b border-white/5">
                                    <tr className="text-left text-[10px] uppercase tracking-[0.2em] text-zinc-500">
                                        <th className="p-4">User</th><th className="p-4">Plan</th><th className="p-4">Amount</th><th className="p-4">Method</th><th className="p-4">Txn ID</th><th className="p-4">Proof</th><th className="p-4">Status</th><th className="p-4 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {payments.length === 0 ? <tr><td colSpan={8} className="p-8 text-center text-zinc-500">No payment submissions yet</td></tr> : payments.map((p) => (
                                        <tr key={p.id} data-testid={`payment-row-${p.id}`} className="border-b border-white/5 hover:bg-white/[0.02]">
                                            <td className="p-4"><div className="font-bold text-xs">{p.user_name}</div><div className="text-[10px] text-zinc-500">{p.user_email}</div></td>
                                            <td className="p-4"><span className={`text-[10px] font-bold px-2 py-1 rounded-full ${p.plan_id === "gold" ? "bg-amber-500/10 text-amber-400" : "bg-zinc-500/10 text-zinc-300"}`}>{p.plan_id?.toUpperCase()}</span></td>
                                            <td className="p-4 font-bold text-[#FF2A85]">{p.amount} PKR</td>
                                            <td className="p-4 text-zinc-400 text-xs uppercase">{p.method_id}</td>
                                            <td className="p-4 font-mono text-xs text-zinc-400">{p.transaction_id || "—"}</td>
                                            <td className="p-4">{p.screenshot_path && <a href={fileUrl(p.screenshot_path)} target="_blank" rel="noreferrer" className="text-[#FF2A85] hover:underline text-xs">View</a>}</td>
                                            <td className="p-4"><Badge color={p.status === "approved" ? "emerald" : p.status === "rejected" ? "red" : "amber"}>{p.status}</Badge></td>
                                            <td className="p-4"><div className="flex items-center justify-end gap-1.5">{p.status === "pending" && <><button data-testid={`approve-payment-${p.id}`} onClick={() => reviewPayment(p.id, "approve")} className="w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center hover:bg-emerald-500/30"><Check className="w-3.5 h-3.5 text-emerald-400" /></button><button data-testid={`reject-payment-${p.id}`} onClick={() => reviewPayment(p.id, "reject")} className="w-8 h-8 rounded-full bg-red-500/20 border border-red-500/40 flex items-center justify-center hover:bg-red-500/30"><X className="w-3.5 h-3.5 text-red-400" /></button></>}</div></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                {/* BRANDING */}
                {tab === "branding" && (
                    <div className="glass-strong rounded-3xl p-6 lg:p-8" data-testid="branding-section">
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            <div>
                                <label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-3 block">Current Logo</label>
                                <div className="aspect-square rounded-3xl overflow-hidden bg-black glass-pink relative mb-3 flex items-center justify-center">
                                    {branding?.logo_url ? <img src={resolveLogoUrl(branding.logo_url)} alt="logo" className="w-full h-full object-cover" /> : <div className="text-zinc-500">Default logo</div>}
                                </div>
                                <input ref={logoFileRef} type="file" accept="image/*" onChange={uploadLogo} className="hidden" data-testid="admin-logo-file" />
                                <button onClick={() => logoFileRef.current?.click()} data-testid="admin-upload-logo-btn" className="btn-primary w-full text-sm py-2.5 flex items-center justify-center gap-2"><Upload className="w-4 h-4" /> Upload New Logo</button>
                                <p className="text-[10px] text-zinc-500 mt-2">Square (1:1) ratio works best. Applies to header, sidebar, footer, login, and favicon.</p>
                            </div>
                            <div className="lg:col-span-2 space-y-4">
                                <div>
                                    <label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">Brand Name</label>
                                    <input data-testid="admin-brand-name" value={brandForm.brand_name} onChange={(e) => setBrandForm({ ...brandForm, brand_name: e.target.value })} className="input-dark" />
                                </div>
                                <div>
                                    <label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">Tagline</label>
                                    <input data-testid="admin-brand-tagline" value={brandForm.tagline} onChange={(e) => setBrandForm({ ...brandForm, tagline: e.target.value })} className="input-dark" />
                                </div>
                                <button onClick={saveBrandText} className="btn-primary text-sm py-2.5 inline-flex items-center gap-2"><Save className="w-4 h-4" /> Save Branding</button>
                            </div>
                        </div>
                    </div>
                )}

                {/* THEME */}
                {tab === "theme" && (
                    <div className="glass-strong rounded-3xl p-6 lg:p-8">
                        <div className="flex items-center gap-2 mb-6">
                            <Palette className="w-5 h-5 text-[#FF2A85]" />
                            <h2 className="font-['Outfit'] text-xl font-bold">Color Theme</h2>
                        </div>
                        <p className="text-sm text-zinc-400 mb-6">Choose a theme color palette. Changes apply instantly across the entire app.</p>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                            {Object.entries(THEMES).map(([key, theme]) => (
                                <button
                                    key={key}
                                    data-testid={`theme-${key}`}
                                    onClick={() => { setThemeKey(key); toast.success(`Theme: ${theme.name}`); }}
                                    className={`relative p-5 rounded-3xl border transition-all text-left ${themeKey === key ? "border-[#FF2A85]/50 shadow-xl shadow-pink-500/20 bg-white/[0.04]" : "border-white/[0.08] hover:border-white/[0.16] bg-white/[0.02]"}`}
                                >
                                    <div className="flex gap-1.5 mb-4">
                                        {theme.gradient.map((c, i) => (
                                            <div key={i} className="w-10 h-10 rounded-2xl shadow-lg" style={{ background: c, boxShadow: `0 0 20px ${c}80` }} />
                                        ))}
                                    </div>
                                    <div className="font-['Outfit'] font-bold flex items-center gap-1.5">{theme.emoji} {theme.name}</div>
                                    {themeKey === key && <div className="absolute top-3 right-3 w-6 h-6 rounded-full neon-gradient flex items-center justify-center"><Check className="w-3.5 h-3.5" /></div>}
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                {/* POPUPS */}
                {tab === "popups" && (
                    <div className="space-y-6">
                        <div className="glass-strong rounded-3xl p-6">
                            <div className="flex items-center gap-2 mb-5">
                                <Plus className="w-5 h-5 text-[#FF2A85]" />
                                <h2 className="font-['Outfit'] text-lg font-bold">Create New Popup</h2>
                            </div>
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                                <div>
                                    <label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">Type</label>
                                    <div className="grid grid-cols-4 gap-2">
                                        {[
                                            { id: "success", label: "Success", icon: Check, color: "emerald" },
                                            { id: "error", label: "Error", icon: AlertCircle, color: "red" },
                                            { id: "warning", label: "Warning", icon: AlertTriangle, color: "amber" },
                                            { id: "promo", label: "Promo", icon: Sparkles, color: "pink" },
                                        ].map((t) => (
                                            <button key={t.id} data-testid={`popup-type-${t.id}`} onClick={() => setPopupForm({ ...popupForm, type: t.id })} className={`p-3 rounded-xl border transition-all flex flex-col items-center gap-1.5 ${popupForm.type === t.id ? "neon-gradient text-white" : "glass text-zinc-400"}`}>
                                                <t.icon className="w-4 h-4" />
                                                <span className="text-[10px] font-bold">{t.label}</span>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div className="flex items-end gap-3">
                                    <label className="flex items-center gap-2 text-xs">
                                        <input type="checkbox" checked={popupForm.active} onChange={(e) => setPopupForm({ ...popupForm, active: e.target.checked })} /> Active
                                    </label>
                                    <label className="flex items-center gap-2 text-xs">
                                        <input type="checkbox" checked={popupForm.show_once} onChange={(e) => setPopupForm({ ...popupForm, show_once: e.target.checked })} /> Show once per user
                                    </label>
                                </div>
                                <div className="lg:col-span-2">
                                    <label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">Title</label>
                                    <input data-testid="popup-title-input" value={popupForm.title} onChange={(e) => setPopupForm({ ...popupForm, title: e.target.value })} className="input-dark" placeholder="e.g. Welcome to DilSe!" />
                                </div>
                                <div className="lg:col-span-2">
                                    <label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">Body</label>
                                    <textarea data-testid="popup-body-input" rows={3} value={popupForm.body} onChange={(e) => setPopupForm({ ...popupForm, body: e.target.value })} className="input-dark" placeholder="Your message..." />
                                </div>
                                <div>
                                    <label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">CTA Label (optional)</label>
                                    <input value={popupForm.cta_label} onChange={(e) => setPopupForm({ ...popupForm, cta_label: e.target.value })} className="input-dark" placeholder="e.g. Get Started" />
                                </div>
                                <div>
                                    <label className="text-[10px] uppercase tracking-[0.15em] text-zinc-500 font-bold mb-1.5 block">CTA URL (optional)</label>
                                    <input value={popupForm.cta_url} onChange={(e) => setPopupForm({ ...popupForm, cta_url: e.target.value })} className="input-dark" placeholder="e.g. /premium" />
                                </div>
                            </div>
                            <button data-testid="create-popup-btn" onClick={createPopup} className="btn-primary mt-5 text-sm py-2.5 inline-flex items-center gap-2"><Plus className="w-4 h-4" /> Create Popup</button>
                        </div>

                        {/* Popups list */}
                        <div className="glass rounded-3xl p-6">
                            <h3 className="font-['Outfit'] font-bold mb-4">Existing Popups</h3>
                            {popups.length === 0 ? <div className="text-center text-zinc-500 py-8">No popups created</div> : (
                                <div className="space-y-2">
                                    {popups.map((p) => (
                                        <div key={p.id} className="flex items-center gap-3 p-3 rounded-2xl bg-white/[0.02]">
                                            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold ${p.type === "success" ? "bg-emerald-500/20 text-emerald-400" : p.type === "error" ? "bg-red-500/20 text-red-400" : p.type === "warning" ? "bg-amber-500/20 text-amber-400" : "bg-[#FF2A85]/20 text-[#FF2A85]"}`}>{p.type[0].toUpperCase()}</div>
                                            <div className="flex-1 min-w-0">
                                                <div className="font-bold text-sm">{p.title}</div>
                                                <div className="text-xs text-zinc-400 truncate">{p.body}</div>
                                            </div>
                                            {p.active && <Badge color="emerald">Active</Badge>}
                                            <button data-testid={`delete-popup-${p.id}`} onClick={() => deletePopup(p.id)} className="w-8 h-8 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center hover:bg-red-500/20"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </AppShell>
    );
}

function Badge({ color, children }) {
    const colors = {
        amber: "bg-amber-500/10 border-amber-500/20 text-amber-400",
        emerald: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
        pink: "bg-[#FF2A85]/10 border-[#FF2A85]/20 text-[#FF2A85]",
        red: "bg-red-500/10 border-red-500/20 text-red-400",
    };
    return <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase tracking-wider ${colors[color]}`}>{children}</span>;
}
